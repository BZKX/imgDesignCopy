import{a as p,i as L,D,L as M}from"./messages-5iolYRK2.js";import{W as B,b as J,c as F,g as O,i as W,l as G}from"./config-COkQTA7L.js";import{l as H,g as K,r as $,c as j,a as Y}from"./storage-CVKh_Pss.js";const q=`You are a reverse-prompt expert. Given an image, produce a JSON object with THREE prompts that, when used in their respective models, would generate an image with a similar VISUAL STYLE (not identical content). Focus on: medium, lighting, composition, color palette, texture, mood, camera / render style. Avoid naming specific IPs or real people.

Return strictly valid JSON matching this schema:
{
  "midjourney": "natural-language description ending with parameters like --ar W:H --style raw --v 6",
  "stable_diffusion": {
    "positive": "comma-separated keyword stack with optional (token:weight) syntax",
    "negative": "comma-separated negative keywords",
    "weights_explained": "one short sentence explaining why you chose the weights"
  },
  "dalle": "natural-language paragraph of roughly 60 words"
}

Rules:
- Output JSON only. No prose, no markdown fences.
- Midjourney prompt MUST end with --ar and --v 6 (add --style raw when the look is photographic/realistic).
- Stable Diffusion positive uses keyword-stack style (not full sentences) and may include weights.
- DALL·E is a single ~60-word paragraph in natural English.`,V=`你是反向提示词（reverse prompt）专家。给定一张图片，请输出一个 JSON 对象，包含 THREE 条提示词，使其在各自模型里生成风格（不是完全相同的内容）接近的图片。聚焦：媒介、光线、构图、色板、质感、氛围、相机/渲染风格。不要出现具体 IP 或真实人物姓名。

严格按照以下 schema 返回 JSON：
{
  "midjourney": "自然语言描述，结尾附 --ar 宽:高 --style raw --v 6 等参数",
  "stable_diffusion": {
    "positive": "逗号分隔的关键词堆叠，可用 (token:weight) 权重语法",
    "negative": "逗号分隔的负向关键词",
    "weights_explained": "一句话解释为何如此设定权重"
  },
  "dalle": "约 60 词的自然语言段落"
}

规则：
- 仅输出 JSON，不要任何解释性文字或 markdown 代码块。
- Midjourney 结尾必须带 --ar 与 --v 6；若画面偏写实摄影，再追加 --style raw。
- Stable Diffusion positive 使用关键词堆叠风格（不是整句），可附权重。
- DALL·E 为约 60 词的自然语言段落（英文输出即可）。`,z=`You are a product-design analyst. Given a product photograph, extract its visual style as a JSON object suitable for downstream design search and prompt generation.

Return strictly valid JSON matching this schema:
{
  "palette": ["#hex or css color name", ...3-8 entries, ordered by visual dominance],
  "materials": ["brushed aluminum", "matte plastic", ...],
  "lighting": "short phrase, e.g. 'soft studio key + rim light'",
  "mood": ["premium", "minimal", ...],
  "camera": "e.g. 'three-quarter front, 50mm, shallow DOF'",
  "tags": ["searchable", "keywords", ...3+ entries]
}

Examples:
1) Sleek black wireless earbuds case →
{"palette":["#0a0a0a","#1f1f1f","#9b9b9b"],"materials":["soft-touch matte plastic","polished metal hinge"],"lighting":"soft top key with subtle rim","mood":["premium","minimal","tech"],"camera":"three-quarter front, 50mm, shallow DOF","tags":["earbuds","case","minimal","matte black","tech"]}
2) Pastel ceramic mug on linen →
{"palette":["#f3d9d2","#e8c0b3","#fdf6f1","#7a5b50"],"materials":["glazed ceramic","raw linen"],"lighting":"diffused window light from left","mood":["warm","artisanal","cozy"],"camera":"top-down 35mm, soft shadow","tags":["mug","ceramic","pastel","lifestyle","kinfolk"]}
3) Industrial stainless thermos →
{"palette":["#c0c4c8","#5e6469","#1c1f22"],"materials":["brushed stainless steel","silicone grip"],"lighting":"hard key + bounce fill","mood":["rugged","utilitarian","outdoor"],"camera":"front elevation, 85mm","tags":["thermos","stainless","industrial","outdoor","durable"]}

Rules:
- Output JSON only. No prose, no markdown fences.
- Use lowercase color hex when possible; otherwise CSS color keyword.
- Be concise — each phrase under ~6 words.`,Z=`你是产品设计分析师。给定一张产品图，请以 JSON 形式提取其视觉风格，便于后续做设计检索与生成。

严格按以下 schema 输出 JSON：
{
  "palette": ["#hex 或 CSS 颜色关键字", ...3-8 项，按主导程度排序],
  "materials": ["磨砂铝", "哑光塑料", ...],
  "lighting": "短语，例如 '柔和顶光 + 轮廓光'",
  "mood": ["高端", "极简", ...],
  "camera": "例如 '三分之二正面，50mm，浅景深'",
  "tags": ["可检索", "关键词", ...至少 3 项]
}

示例：
1) 黑色无线耳机充电盒 →
{"palette":["#0a0a0a","#1f1f1f","#9b9b9b"],"materials":["软触哑光塑料","抛光金属转轴"],"lighting":"柔顶光 + 轻微轮廓光","mood":["高端","极简","科技感"],"camera":"三分之二正面，50mm，浅景深","tags":["耳机","充电盒","极简","哑光黑","科技"]}
2) 亚麻布上的莫兰迪陶瓷马克杯 →
{"palette":["#f3d9d2","#e8c0b3","#fdf6f1","#7a5b50"],"materials":["釉面陶瓷","原色亚麻"],"lighting":"左侧柔和窗光","mood":["温暖","手作感","治愈"],"camera":"俯拍 35mm，柔阴影","tags":["马克杯","陶瓷","莫兰迪","生活方式","kinfolk"]}
3) 工业风不锈钢保温杯 →
{"palette":["#c0c4c8","#5e6469","#1c1f22"],"materials":["拉丝不锈钢","硅胶握把"],"lighting":"硬主光 + 反光板补光","mood":["硬朗","实用主义","户外"],"camera":"正立面，85mm","tags":["保温杯","不锈钢","工业风","户外","耐用"]}

规则：
- 仅输出 JSON，不要任何说明文字或 markdown 代码块。
- 颜色尽量用小写 hex；否则用 CSS 关键字。
- 每个短语保持精炼（约 6 个词以内）。`,Q=`You are a senior web/UI design analyst. Given a webpage screenshot, extract its design language as JSON suitable for design system reuse.

Return strictly valid JSON matching this schema:
{
  "layout": "e.g. '12-col centered hero, split feature rows, 3-card grid'",
  "typography": {
    "heading": "e.g. 'geometric sans, tight tracking, 56-72px display'",
    "body": "e.g. 'humanist sans, 16px, 1.6 line-height'"
  },
  "colors": {
    "primary": "#hex",
    "accents": ["#hex", ...]
  },
  "components": ["sticky nav with translucent blur", "primary CTA button", "feature card", ...at least 2],
  "interactions": ["scroll-reveal feature rows", "subtle hover lift on cards", ...at least 1],
  "tone": "e.g. 'confident, enterprise, productivity-focused'"
}

Rules:
- Output JSON only. No prose, no markdown fences.
- Concise phrases, no full sentences except where natural (heading/body specs, tone).
- Prefer concrete UI vocabulary (hero, nav, card, CTA, grid, modal, tabs, accordion).`,X=`你是资深 Web/UI 设计分析师。给定一张网页截图，请以 JSON 形式提取其设计语言，便于设计体系复用。

严格按以下 schema 输出 JSON：
{
  "layout": "例如 '12 栅格居中 hero、左右分栏特性区、三卡网格'",
  "typography": {
    "heading": "例如 '几何无衬线，紧字距，56-72px display'",
    "body": "例如 '人文无衬线，16px，行高 1.6'"
  },
  "colors": {
    "primary": "#hex",
    "accents": ["#hex", ...]
  },
  "components": ["半透模糊吸顶导航", "主 CTA 按钮", "特性卡片", ...至少 2 项],
  "interactions": ["滚动入场的特性区", "卡片轻微悬浮抬起", ...至少 1 项],
  "tone": "例如 '自信、企业级、效率导向'"
}

规则：
- 仅输出 JSON，不要任何说明文字或 markdown 代码块。
- 短语精炼，仅 typography/tone 等可使用自然短句。
- 优先使用具体 UI 术语（hero、nav、card、CTA、grid、modal、tabs、accordion 等）。`;function ee(e){const{mode:a,language:t}=e,o=t==="zh";switch(a){case"image_to_prompt":return o?V:q;case"product_style":return o?Z:z;case"webpage_style":return o?X:Q}}const te={image_to_prompt:F,product_style:J,webpage_style:B};class k extends Error{constructor(a="Unauthorized (401). Check your API key."){super(a),this.name="AuthError"}}class v extends Error{constructor(a="Rate limited (429). Please retry later."){super(a),this.name="RateLimitError"}}class b extends Error{constructor(a){super(a),this.name="NetworkError"}}class C extends Error{constructor(a="Model response did not match expected schema."){super(a),this.name="SchemaError"}}const N="Produce a JSON response per the schema.",re=e=>`Your previous response failed schema validation for mode '${e}'. Return strictly valid JSON matching the schema.`;async function ae(e,a){const t=ee({mode:e,language:a.language}),o=te[e],r=await R(a,t,N),n=I(r,o);if(n.ok)return n.value;const i=await R(a,t,N,{priorRaw:r,correctiveSystem:re(e)}),l=I(i,o);if(l.ok)return l.value;throw new C(l.error)}async function R(e,a,t,o){const r=e.provider??"openai",n=O(r),{url:i,init:l}=n.buildRequest({baseURL:e.baseURL,apiKey:e.apiKey,model:e.model,systemPrompt:a,userText:t,imageBase64:e.imageBase64,mime:e.mime??"image/jpeg",signal:e.signal,temperature:.4,maxTokens:800,retry:o});let s;try{s=await fetch(i,l)}catch(c){throw c instanceof Error&&c.name==="AbortError"?c:new b(c instanceof Error?c.message:String(c))}const u=n.classifyStatus(s.status);if(u==="auth")throw new k;if(u==="rate")throw new v;if(u!=="ok"){const c=await s.text().catch(()=>"");throw new b(`HTTP ${s.status}: ${c||s.statusText}`)}let g;try{g=await s.json()}catch(c){throw new b(`Failed to read response: ${c instanceof Error?c.message:String(c)}`)}const y=n.extractContent(g);if(!y)throw new b("Empty response content from API.");return y}function I(e,a){let t;try{t=JSON.parse(e)}catch(r){return{ok:!1,error:`Invalid JSON: ${r instanceof Error?r.message:String(r)}`}}const o=a.safeParse(t);return o.success?{ok:!0,value:o.data}:{ok:!1,error:o.error.issues[0]?.message??"schema mismatch"}}function oe(e){const a=e.indexOf(",");return a<0?e:e.slice(a+1)}async function ne(e){if(typeof FileReader<"u")try{return await new Promise((i,l)=>{const s=new FileReader;s.onload=()=>{const u=s.result;if(typeof u!="string"){l(new Error("FileReader did not return string"));return}i(oe(u))},s.onerror=()=>l(s.error??new Error("FileReader failed")),s.readAsDataURL(e)})}catch{}const t=await ie(e),o=new Uint8Array(t);let r="";const n=32768;for(let i=0;i<o.length;i+=n)r+=String.fromCharCode(...o.subarray(i,i+n));return btoa(r)}function ie(e){const a=e;return typeof a.arrayBuffer=="function"?a.arrayBuffer():new Promise((t,o)=>{const r=new FileReader;r.onload=()=>t(r.result),r.onerror=()=>o(r.error??new Error("FileReader failed")),r.readAsArrayBuffer(e)})}const se=1280,ce=.85;async function le(e,a,t){const r=await(await fetch(e)).blob(),n=await createImageBitmap(r),i=Math.max(1,Math.round(a.w*t)),l=Math.max(1,Math.round(a.h*t)),s=Math.min(1,se/Math.max(i,l)),u=Math.max(1,Math.round(i*s)),g=Math.max(1,Math.round(l*s)),y=new OffscreenCanvas(u,g),c=y.getContext("2d");if(!c)throw new Error("Failed to acquire 2d context on OffscreenCanvas.");c.drawImage(n,a.x*t,a.y*t,i,l,0,0,u,g),n.close?.();const f=await y.convertToBlob({type:"image/jpeg",quality:ce});return{base64:await ne(f),blob:f,mime:"image/jpeg"}}chrome.runtime.onInstalled.addListener(()=>{console.log("[img2prompt] installed")});chrome.action.onClicked.addListener(async e=>{if(!(!e?.id||!e.url)){if(U(e.url)){await h(e.id,"RESTRICTED_PAGE","此页面浏览器不允许扩展操作，换一个普通网页即可。");return}try{await chrome.tabs.sendMessage(e.id,{type:p.PANEL_OPEN})}catch(a){await h(e.id,"RESTRICTED_PAGE",`Content script 未加载，请刷新页面。${m(a)}`)}}});chrome.commands.onCommand.addListener(async e=>{if(e==="start-selection")try{await _()}catch(a){console.error("[img2prompt] start-selection failed",a),await h(null,"UNKNOWN",m(a))}});chrome.runtime.onMessage.addListener((e,a,t)=>{const o=e;if(!o||typeof o!="object")return!1;if(o.type===p.SELECTION_COMPLETE){const r=a.tab?.id??null;return de(e,r).catch(async n=>{console.error("[img2prompt] selection handler failed",n),await h(r,"UNKNOWN",m(n))}),t({ack:!0}),!1}if(o.type===p.SELECTION_CANCEL)return t({ack:!0}),!1;if(o.type===p.RPC_START_SELECTION)return _().then(()=>t({ok:!0})).catch(r=>t({ok:!1,error:m(r)})),!0;if(o.type===p.RPC_HISTORY_LIST)return(async()=>{try{const n=(await H(100)).map(i=>({id:i.id,createdAt:i.createdAt,pageUrl:i.pageUrl,mode:i.mode,insight:i.insight}));t({ok:!0,entries:n})}catch(r){t({ok:!1,error:m(r)})}})(),!0;if(o.type===p.RPC_HISTORY_THUMB){const r=e.id;return(async()=>{try{if(!r)throw new Error("Missing id");const n=await K(r);if(!n){t({ok:!1,error:"not found"});return}const i=await pe(n.thumbnailBlob);t({ok:!0,thumbnailB64:i})}catch(n){t({ok:!1,error:m(n)})}})(),!0}if(o.type===p.RPC_HISTORY_DELETE){const r=e.id;return(async()=>{try{if(!r)throw new Error("Missing id");await $(r),t({ok:!0})}catch(n){t({ok:!1,error:m(n)})}})(),!0}if(o.type===p.RPC_HISTORY_CLEAR)return(async()=>{try{await j(),t({ok:!0})}catch(r){t({ok:!1,error:m(r)})}})(),!0;if(o.type===p.RPC_TEST_CONNECTION){const r=e.config;return(async()=>{try{if(!r)throw new Error("Missing config");const n=W(r.provider)?r.provider:"openai",i=O(n),l="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNgAAIAAAUAAen63NgAAAAASUVORK5CYII=",{url:s,init:u}=i.buildRequest({baseURL:r.baseURL,apiKey:r.apiKey,model:r.model,systemPrompt:"ping",userText:"ping",imageBase64:l,mime:"image/png",temperature:0,maxTokens:1}),g=await fetch(s,u);t({ok:g.ok,status:g.status})}catch(n){t({ok:!1,error:m(n)})}})(),!0}return!1});async function _(){const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e?.id||!e.url){await h(null,"RESTRICTED_PAGE","No active tab available.");return}if(U(e.url)){await h(e.id,"RESTRICTED_PAGE","此页面浏览器不允许扩展截图，换一个普通网页即可。");return}try{await chrome.tabs.sendMessage(e.id,{type:p.START_SELECTION})}catch(a){await h(e.id,"RESTRICTED_PAGE",`Content script 未加载，请刷新页面。${m(a)}`)}}async function w(e,a,t,o,r,n){r.current+=1;const i={type:p.LOADING,seq:r.current,startedAt:o,step:t,elapsedMs:Date.now()-o,mode:a,...n??{}};console.log("[progress]",t,`${i.elapsedMs}ms`,n??""),await S(e,i),await T(i)}async function de(e,a){const t=Date.now(),o={current:0},r=e.mode,n=L(r)?r:(console.warn("[img2prompt] unknown mode, falling back",r),D);let i;const[l]=await chrome.tabs.query({active:!0,currentWindow:!0}),s=a??l?.id??null;if(console.log("[img2prompt] selection received",{tabId:s,rect:e.rect,mode:n}),!l?.windowId){await h(s,"CAPTURE_FAILED","No active window to capture.");return}const u=chrome.tabs.captureVisibleTab(l.windowId,{format:"jpeg",quality:88}).catch(d=>{throw console.error("[img2prompt] captureVisibleTab FAILED",d),d}),g=G();let y;try{y=await u}catch(d){await w(s,n,"failed",t,o,{failedAt:i,errorCode:"CAPTURE_FAILED"}),await h(s,"CAPTURE_FAILED",`captureVisibleTab failed: ${m(d)}`);return}await w(s,n,"captured",t,o),i="captured";let c;try{c=await le(y,e.rect,e.dpr)}catch(d){console.error("[img2prompt] crop FAILED",d),await w(s,n,"failed",t,o,{failedAt:i,errorCode:"CAPTURE_FAILED"}),await h(s,"CAPTURE_FAILED",`Crop failed: ${m(d)}`);return}await w(s,n,"cropped",t,o),i="cropped";const f=await g;if(!f.apiKey&&f.provider!=="ollama"){console.warn("[img2prompt] no api key configured"),await w(s,n,"failed",t,o,{failedAt:i,errorCode:"NO_CONFIG"}),await h(s,"NO_CONFIG","API key 尚未配置，请打开设置填写。");return}await w(s,n,"inferring",t,o),i="inferring";try{const d=Date.now(),E=await ae(n,{provider:f.provider,baseURL:f.baseURL,apiKey:f.apiKey,model:f.model,language:f.language,imageBase64:c.base64,mime:c.mime});console.log("[img2prompt] vision ok",`${Date.now()-d}ms`),await w(s,n,"parsing",t,o),i="parsing";const A={thumbnailB64:c.base64,mode:n,insight:E,pageUrl:e.pageUrl,createdAt:Date.now()};try{await Y({id:ue(),createdAt:A.createdAt,thumbnailBlob:c.blob,pageUrl:e.pageUrl,mode:n,insight:E},f.maxHistory)}catch(x){console.warn("[img2prompt] history write failed",x)}const P={type:p.RESULT,payload:A};await T(A),await w(s,n,"done",t,o),await S(s,P),console.log("[img2prompt] RESULT sent to tab",s,`total ${Date.now()-t}ms`)}catch(d){const E=me(d);console.error("[img2prompt] vision FAILED",E,d),await w(s,n,"failed",t,o,{failedAt:i,errorCode:E}),await h(s,E,m(d))}}async function S(e,a){if(e==null){console.warn("[img2prompt] sendToTab: no tabId",a.type);return}try{await chrome.tabs.sendMessage(e,a)}catch(t){console.warn("[img2prompt] sendToTab failed",a.type,e,m(t))}}async function T(e){try{await chrome.storage.session.set({[M]:e})}catch{}}function me(e){return e instanceof k?"UNAUTHORIZED":e instanceof v?"RATE_LIMITED":e instanceof C?"INVALID_RESPONSE":e instanceof b?"NETWORK_ERROR":e instanceof Error&&e.name==="AbortError"?"TIMEOUT":"UNKNOWN"}async function h(e,a,t){const o={type:p.ERROR,code:a,message:t};await T(o),await S(e,o)}function U(e){return e.startsWith("chrome://")||e.startsWith("chrome-extension://")||e.startsWith("edge://")||e.startsWith("about:")||e.startsWith("view-source:")||e.startsWith("https://chrome.google.com/webstore")||e.startsWith("https://chromewebstore.google.com")}function m(e){return e instanceof Error?e.message:String(e)}function ue(){return typeof crypto<"u"&&"randomUUID"in crypto?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2)}`}async function pe(e){const a=await e.arrayBuffer();let t="";const o=new Uint8Array(a);for(let r=0;r<o.length;r++)t+=String.fromCharCode(o[r]);return btoa(t)}export{de as handleSelectionComplete,w as reportStep};
