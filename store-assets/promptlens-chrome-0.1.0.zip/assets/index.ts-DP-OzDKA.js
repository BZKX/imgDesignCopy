import{j as e,r as d,c as ae}from"./client-CNRN5RT9.js";import{M as I,a as u,D as se,i as oe,b as be}from"./messages-5iolYRK2.js";import{D as ye,l as ie,C as ke,P as O,a as je,s as ve}from"./config-COkQTA7L.js";function G(t,r,a,n){const s=Math.min(t,a),c=Math.min(r,n),o=Math.abs(a-t),l=Math.abs(n-r);return{x:s,y:c,w:o,h:l}}function X(t,r,a){const n=Math.max(0,Math.min(t.x,r)),s=Math.max(0,Math.min(t.y,a)),c=Math.max(0,Math.min(t.w,r-n)),o=Math.max(0,Math.min(t.h,a-s));return{x:n,y:s,w:c,h:o}}function we(t,r=4){return t.w<r||t.h<r}function R({children:t}){return e.jsx("kbd",{className:"kbd",children:t})}function Ne(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.75",strokeLinecap:"round",children:e.jsx("path",{d:"M3 3l10 10M13 3L3 13"})})}function Ce(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[e.jsx("circle",{cx:"8",cy:"8",r:"2"}),e.jsx("path",{d:"M8 1.5v2M8 12.5v2M14.5 8h-2M3.5 8h-2M12.6 3.4l-1.4 1.4M4.8 11.2l-1.4 1.4M12.6 12.6l-1.4-1.4M4.8 4.8L3.4 3.4",strokeLinecap:"round"})]})}function Me(){return e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",style:{width:20,height:20},children:[e.jsx("path",{d:"M12 8v5M12 16.5v.01"}),e.jsx("circle",{cx:"12",cy:"12",r:"9.5"})]})}function Se(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M10 3L5 8l5 5"})})}function le(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("path",{d:"M2.8 7.5a5.3 5.3 0 11.7 3"}),e.jsx("path",{d:"M1.5 10.6l2 .1.1-2"}),e.jsx("path",{d:"M8 5.2v3.1l2 1.2"})]})}function Ee(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",children:[e.jsx("circle",{cx:"8",cy:"8",r:"2.8"}),e.jsx("path",{d:"M8 1.5v1.8M8 12.7v1.8M14.5 8h-1.8M3.3 8H1.5M12.6 3.4l-1.3 1.3M4.7 11.3l-1.3 1.3M12.6 12.6l-1.3-1.3M4.7 4.7L3.4 3.4"})]})}function Le(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M13.2 9.4A5.5 5.5 0 016.6 2.8a5.5 5.5 0 106.6 6.6z"})})}function Re(){return e.jsx("svg",{viewBox:"0 0 1024 1024",fill:"currentColor","aria-hidden":!0,children:e.jsx("path",{d:"M512 170.666667a341.333333 341.333333 0 1 1 0 682.666666c-55.722667 0-21.930667-39.552-83.925333-103.253333C368.170667 688.64 170.666667 725.12 170.666667 512a341.333333 341.333333 0 0 1 341.333333-341.333333z m74.666667 413.866666a64 64 0 1 0 0 128 64 64 0 0 0 0-128z m117.333333-136.533333a42.666667 42.666667 0 1 0 0 85.333333 42.666667 42.666667 0 0 0 0-85.333333zM640 341.333333a42.666667 42.666667 0 1 0 0 85.333334 42.666667 42.666667 0 0 0 0-85.333334z m-245.333333-12.8a42.666667 42.666667 0 1 0 0 85.333334 42.666667 42.666667 0 0 0 0-85.333334z m128-40.533333a42.666667 42.666667 0 1 0 0 85.333333 42.666667 42.666667 0 0 0 0-85.333333z"})})}function ze(){return e.jsxs("svg",{viewBox:"0 0 1024 1024",fill:"currentColor","aria-hidden":!0,children:[e.jsx("path",{d:"M832 736l-249.6 153.6c-19.2 12.8-38.4 0-38.4-25.6L544 505.6c0-6.4 6.4-19.2 12.8-25.6l249.6-153.6c19.2-12.8 38.4 0 38.4 25.6l0 364.8C844.8 723.2 838.4 736 832 736z"}),e.jsx("path",{d:"M192 736l249.6 153.6c19.2 12.8 38.4 0 38.4-25.6L480 505.6c0-6.4-6.4-19.2-12.8-25.6L217.6 326.4C204.8 320 179.2 332.8 179.2 352l0 364.8C179.2 723.2 185.6 736 192 736z"}),e.jsx("path",{d:"M505.6 128 217.6 236.8c-12.8 6.4-12.8 25.6 0 32L505.6 448C512 448 518.4 448 518.4 448l294.4-179.2c12.8-6.4 12.8-25.6 0-32L518.4 128C512 128 512 128 505.6 128z"})]})}function Te(){return e.jsx("svg",{viewBox:"0 0 1024 1024",fill:"currentColor","aria-hidden":!0,children:e.jsx("path",{d:"M853.333333 170.666667 170.666667 170.666667C123.733333 170.666667 85.333333 209.066667 85.333333 256l0 512c0 46.933333 38.4 85.333333 85.333333 85.333333l682.666667 0c46.933333 0 85.333333-38.4 85.333333-85.333333L938.666667 256C938.666667 209.066667 900.266667 170.666667 853.333333 170.666667zM640 768 170.666667 768l0-170.666667 469.333333 0L640 768zM640 554.666667 170.666667 554.666667 170.666667 384l469.333333 0L640 554.666667zM853.333333 768l-170.666667 0L682.666667 384l170.666667 0L853.333333 768z"})})}function D({mode:t}){return t==="product_style"?e.jsx(ze,{}):t==="webpage_style"?e.jsx(Te,{}):e.jsx(Re,{})}function F(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round",style:{width:14,height:14},children:[e.jsx("circle",{cx:"4",cy:"5",r:"1.75"}),e.jsx("circle",{cx:"4",cy:"11",r:"1.75"}),e.jsx("path",{d:"M5.5 6.2L14 13M5.5 9.8L14 3"})]})}function Ie({onComplete:t,onCancel:r,excludeHost:a,mode:n}){const[s,c]=d.useState("element"),[o,l]=d.useState(null),[g,b]=d.useState(null),[j,m]=d.useState(null),[L,M]=d.useState(""),E=d.useRef(null);d.useEffect(()=>{const x=N=>{N.key==="Escape"&&(N.preventDefault(),N.stopPropagation(),r()),(N.key==="e"||N.key==="E")&&(N.preventDefault(),c(S=>S==="rect"?"element":"rect"),l(null),b(null),m(null))};return window.addEventListener("keydown",x,!0),()=>window.removeEventListener("keydown",x,!0)},[r]);const w=x=>{s==="rect"&&x.button===0&&(l({x:x.clientX,y:x.clientY}),b({x:x.clientX,y:x.clientY}))},y=x=>{if(s==="rect"){if(!o)return;b({x:x.clientX,y:x.clientY});return}const S=document.elementsFromPoint(x.clientX,x.clientY).find(f=>!(!f||a&&(f===a||a.contains(f))||f===document.documentElement||f===document.body));if(!S){m(null);return}const i=S.getBoundingClientRect();if(i.width<4||i.height<4){m(null);return}m({x:Math.max(0,Math.floor(i.left)),y:Math.max(0,Math.floor(i.top)),w:Math.min(window.innerWidth-Math.max(0,Math.floor(i.left)),Math.ceil(i.width)),h:Math.min(window.innerHeight-Math.max(0,Math.floor(i.top)),Math.ceil(i.height))}),M(Pe(S))},h=x=>{if(s!=="rect"||!o)return;const N=G(o.x,o.y,x.clientX,x.clientY),S=X(N,window.innerWidth,window.innerHeight);if(l(null),b(null),we(S)){r();return}t(S)},k=x=>{s==="element"&&j&&(x.preventDefault(),x.stopPropagation(),t(j))},p=s==="rect"?o&&g?X(G(o.x,o.y,g.x,g.y),window.innerWidth,window.innerHeight):null:j;return e.jsxs("div",{ref:E,onMouseDown:w,onMouseMove:y,onMouseUp:h,onClick:k,className:`overlay-root ${s==="element"?"mode-element":"mode-rect"}`,children:[p?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"overlay-rect",style:{left:p.x,top:p.y,width:p.w,height:p.h}}),e.jsx("div",{className:"overlay-dim-mask",style:{clipPath:`polygon(
                0 0, 100% 0, 100% 100%, 0 100%, 0 0,
                ${p.x}px ${p.y}px,
                ${p.x}px ${p.y+p.h}px,
                ${p.x+p.w}px ${p.y+p.h}px,
                ${p.x+p.w}px ${p.y}px,
                ${p.x}px ${p.y}px
              )`}}),e.jsx("div",{className:"overlay-badge",style:{left:Math.min(p.x+p.w-100,window.innerWidth-110),top:Math.min(p.y+p.h+10,window.innerHeight-32)},children:s==="element"&&L?`${L} · ${p.w} × ${p.h}`:`${p.w} × ${p.h}`})]}):e.jsx("div",{className:"overlay-dim-mask overlay-dim-full"}),e.jsxs("div",{className:"overlay-toolbar",onMouseDown:U,onMouseUp:U,onMouseMove:U,onClick:U,children:[e.jsxs("span",{className:"overlay-mode-badge",title:I[n].description,children:[e.jsx("span",{className:"overlay-mode-icon",children:e.jsx(D,{mode:n})}),I[n].label]}),e.jsxs("div",{className:"overlay-segment",role:"tablist",children:[e.jsxs("button",{type:"button",className:s==="element"?"active":"",onClick:x=>{x.stopPropagation(),c("element"),l(null),b(null)},children:[e.jsx($e,{})," 元素"]}),e.jsxs("button",{type:"button",className:s==="rect"?"active":"",onClick:x=>{x.stopPropagation(),c("rect"),m(null)},children:[e.jsx(_e,{})," 框选"]})]}),e.jsxs("div",{className:"overlay-hint",children:[s==="rect"?"拖动选择任意区域":"移动鼠标高亮元素，点击确认",e.jsx("span",{className:"overlay-hint-sep"}),e.jsx("kbd",{children:"E"})," 切换模式",e.jsx("span",{className:"overlay-hint-sep"}),e.jsx("kbd",{children:"Esc"})," 取消"]})]})]})}function U(t){t.stopPropagation()}function Pe(t){const r=t.tagName.toLowerCase(),a=t.id?`#${t.id}`:"",n=t.classList.length?"."+Array.from(t.classList).slice(0,2).join("."):"";return`${r}${a}${n}`.slice(0,48)}function _e(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",style:{width:12,height:12},children:e.jsx("rect",{x:"2.5",y:"2.5",width:"11",height:"11",rx:"1.5",strokeDasharray:"2 1.5"})})}function $e(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",style:{width:12,height:12},children:e.jsx("path",{d:"M3 3l4.5 10 1.7-4 4-1.7z"})})}const De=`
:host, :root { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', 'Helvetica Neue', system-ui, sans-serif; letter-spacing: -0.003em; }
button { background: transparent; border: none; cursor: pointer; color: inherit; font: inherit; }

.overlay-root {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  user-select: none;
}
.mode-rect { cursor: crosshair; }
.mode-element { cursor: pointer; }
.overlay-dim-mask {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.42);
  pointer-events: none;
}
.overlay-dim-full { background: rgba(0, 0, 0, 0.28); }
.overlay-rect {
  position: absolute;
  border: 1.5px solid #ffffff;
  border-radius: 4px;
  box-shadow: 0 0 0 1px rgba(0,0,0,0.3), 0 8px 24px rgba(0,0,0,0.35);
  pointer-events: none;
}
.overlay-badge {
  position: absolute;
  padding: 5px 12px;
  background: rgba(28, 28, 30, 0.85);
  -webkit-backdrop-filter: blur(16px) saturate(180%);
  backdrop-filter: blur(16px) saturate(180%);
  color: #ffffff;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  font-weight: 500;
  border-radius: 980px;
  letter-spacing: -0.005em;
  pointer-events: none;
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.overlay-toolbar {
  position: absolute;
  left: 50%;
  top: 28px;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 8px 6px 6px;
  background: rgba(28, 28, 30, 0.78);
  -webkit-backdrop-filter: blur(20px) saturate(180%);
  backdrop-filter: blur(20px) saturate(180%);
  color: #ffffff;
  border-radius: 980px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.25);
}
.overlay-mode-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  background: rgba(255,255,255,0.12);
  color: #ffffff;
  border-radius: 980px;
  font-size: 11.5px;
  font-weight: 500;
  letter-spacing: -0.005em;
}
.overlay-segment {
  display: flex;
  gap: 2px;
  padding: 2px;
  background: rgba(255,255,255,0.08);
  border-radius: 980px;
}
.overlay-segment button {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 12px;
  font-size: 12px;
  font-weight: 500;
  color: rgba(255,255,255,0.7);
  border-radius: 980px;
  transition: background 160ms ease, color 160ms ease;
}
.overlay-segment button:hover { color: #ffffff; }
.overlay-segment button.active {
  background: rgba(255,255,255,0.18);
  color: #ffffff;
}
.overlay-hint {
  font-size: 12px;
  color: rgba(255,255,255,0.85);
  display: flex;
  align-items: center;
  gap: 8px;
  padding-right: 8px;
}
.overlay-hint kbd {
  display: inline-block;
  background: rgba(255,255,255,0.16);
  padding: 2px 7px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
}
.overlay-hint-sep {
  width: 1px; height: 11px;
  background: rgba(255,255,255,0.25);
  display: inline-block;
}
`,Z=[{key:"captured",label:"截图",active:"正在截图…"},{key:"cropped",label:"压缩上传",active:"正在压缩上传…"},{key:"inferring",label:"风格识别",active:"正在识别风格…"},{key:"parsing",label:"结构解析",active:"正在解析结构…"},{key:"done",label:"完成",active:"完成"}],W={captured:0,cropped:1,inferring:2,parsing:3,done:4,failed:-1};function Ae({currentStep:t,failedAt:r,errorCode:a}){const n=W[t],s=r?W[r]:-1;return e.jsx("div",{className:"stepper",role:"status","aria-live":"polite",children:Z.map((c,o)=>{const l=W[c.key],g=t==="failed"&&s===l,b=!g&&t!=="failed"&&l===n,j=!b&&!g&&(t==="failed"?l<s:l<n);let m="stepper-step";return b?m+=" stepper-step--current":j?m+=" stepper-step--done":g?m+=" stepper-step--failed":m+=" stepper-step--pending",e.jsxs("div",{className:m,children:[e.jsxs("div",{className:"stepper-rail",children:[e.jsx("span",{className:"stepper-dot","aria-hidden":!0}),o<Z.length-1&&e.jsx("span",{className:"stepper-line","aria-hidden":!0})]}),e.jsxs("div",{className:"stepper-body",children:[e.jsxs("div",{className:"stepper-label",children:[b?c.active:c.label,g&&a&&e.jsxs("span",{className:"stepper-error",children:[" · ",a]})]}),b&&t!=="done"&&e.jsx("div",{className:"stepper-elapsed",children:"loading…"})]})]},c.key)})})}const Oe=[{key:"midjourney",label:"Midjourney"},{key:"stable_diffusion",label:"SD / Flux"},{key:"dalle",label:"DALL·E"}];function de({result:t}){const[r,a]=d.useState("midjourney");return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"segment",role:"tablist",children:Oe.map(n=>e.jsx("button",{type:"button",role:"tab","aria-selected":r===n.key,className:r===n.key?"active":"",onClick:()=>a(n.key),children:n.label},n.key))}),r==="midjourney"&&e.jsx(J,{label:"Midjourney prompt",text:t.midjourney}),r==="dalle"&&e.jsx(J,{label:"DALL·E / GPT-4o prompt",text:t.dalle}),r==="stable_diffusion"&&e.jsx(Ue,{sd:t.stable_diffusion})]})}function J({label:t,text:r}){const[a,n]=d.useState(!1);async function s(){try{await navigator.clipboard.writeText(r),n(!0),setTimeout(()=>n(!1),1500)}catch{}}return e.jsxs("div",{className:"prompt-card",children:[e.jsx("div",{className:"prompt-card-label",children:t}),e.jsx("div",{className:"prompt-text",children:r}),e.jsxs("div",{className:"actions",children:[e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:s,children:[e.jsx(ce,{}),"Copy"]}),e.jsx("span",{className:`toast ${a?"visible":""}`,children:"已复制"})]})]})}function Ue({sd:t}){const[r,a]=d.useState(!1),[n,s]=d.useState(!1),c=`Positive: ${t.positive}`+(t.negative?`

Negative: ${t.negative}`:"")+(t.weights_explained?`

Weights: ${t.weights_explained}`:"");async function o(l){try{await navigator.clipboard.writeText(l),s(!0),setTimeout(()=>s(!1),1500)}catch{}}return e.jsxs("div",{className:"prompt-card",children:[e.jsx("div",{className:"prompt-card-label",children:"Stable Diffusion / Flux — Positive"}),e.jsx("div",{className:"prompt-text",children:t.positive}),e.jsxs("div",{className:"actions",children:[e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:()=>o(c),children:[e.jsx(ce,{}),"Copy 全部"]}),e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:()=>o(t.positive),children:"仅 Positive"}),e.jsx("span",{className:`toast ${n?"visible":""}`,children:"已复制"})]}),(t.negative||t.weights_explained)&&e.jsx("button",{type:"button",className:"collapse-trigger",onClick:()=>a(l=>!l),"aria-expanded":r,children:r?"收起 negative / weights":"展开 negative / weights"}),r&&e.jsxs(e.Fragment,{children:[t.negative&&e.jsxs("div",{className:"sub-card",children:[e.jsx("div",{className:"sub-card-label",children:"Negative"}),e.jsx("pre",{children:t.negative})]}),t.weights_explained&&e.jsxs("div",{className:"sub-card",children:[e.jsx("div",{className:"sub-card-label",children:"Weights"}),e.jsx("pre",{children:t.weights_explained})]})]})]})}function ce(){return e.jsxs("svg",{viewBox:"0 0 14 14",fill:"none",stroke:"currentColor",strokeWidth:"1.5",style:{width:13,height:13},children:[e.jsx("rect",{x:"3.5",y:"3.5",width:"8",height:"9",rx:"1.5"}),e.jsx("path",{d:"M6 3.5V2.5a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-.5"})]})}function pe({result:t}){return e.jsxs("div",{className:"renderer",children:[e.jsx(B,{title:"配色",children:e.jsx("div",{className:"renderer-palette",children:t.palette.map((r,a)=>e.jsx(Be,{color:r},`${r}-${a}`))})}),e.jsx(B,{title:"材质",children:e.jsx(K,{items:t.materials})}),e.jsx(B,{title:"情绪",children:e.jsx(K,{items:t.mood,tone:"accent"})}),e.jsx(B,{title:"标签",children:e.jsx(K,{items:t.tags})}),e.jsx(Q,{label:"光照",value:t.lighting}),e.jsx(Q,{label:"镜头",value:t.camera})]})}function B({title:t,children:r}){return e.jsxs("div",{className:"renderer-section",children:[e.jsx("div",{className:"renderer-section-title",children:t}),r]})}function K({items:t,tone:r}){return e.jsx("div",{className:"renderer-chips",children:t.map((a,n)=>e.jsx("span",{className:`renderer-chip${r?` renderer-chip--${r}`:""}`,children:a},`${a}-${n}`))})}function Q({label:t,value:r}){return e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:t}),e.jsx("span",{className:"renderer-row-value",children:r})]})}function Be({color:t}){const r=/^#?[0-9a-fA-F]{3,8}$|^rgb|^hsl/.test(t)?t.startsWith("#")||t.startsWith("rgb")||t.startsWith("hsl")?t:`#${t}`:t;return e.jsxs("span",{className:"palette-swatch",title:t,children:[e.jsx("span",{className:"palette-chip",style:{background:r}}),e.jsx("span",{className:"palette-code",children:t})]})}function xe({result:t}){return e.jsxs("div",{className:"renderer",children:[e.jsx(z,{title:"布局",children:e.jsx("div",{className:"renderer-block",children:t.layout})}),e.jsxs(z,{title:"字体",children:[e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:"Heading"}),e.jsx("span",{className:"renderer-row-value",children:t.typography.heading})]}),e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:"Body"}),e.jsx("span",{className:"renderer-row-value",children:t.typography.body})]})]}),e.jsx(z,{title:"配色",children:e.jsxs("div",{className:"renderer-palette",children:[e.jsx(te,{color:t.colors.primary,primary:!0}),t.colors.accents.map((r,a)=>e.jsx(te,{color:r},`${r}-${a}`))]})}),e.jsx(z,{title:"组件",children:e.jsx(ee,{items:t.components})}),e.jsx(z,{title:"交互",children:e.jsx(ee,{items:t.interactions,tone:"accent"})}),e.jsx(z,{title:"调性",children:e.jsx("div",{className:"renderer-block",children:t.tone})})]})}function z({title:t,children:r}){return e.jsxs("div",{className:"renderer-section",children:[e.jsx("div",{className:"renderer-section-title",children:t}),r]})}function ee({items:t,tone:r}){return e.jsx("div",{className:"renderer-chips",children:t.map((a,n)=>e.jsx("span",{className:`renderer-chip${r?` renderer-chip--${r}`:""}`,children:a},`${a}-${n}`))})}function te({color:t,primary:r}){return e.jsxs("span",{className:`palette-swatch${r?" palette-swatch--primary":""}`,title:t,children:[e.jsx("span",{className:"palette-chip",style:{background:t}}),e.jsx("span",{className:"palette-code",children:t})]})}function fe(t){const r=new Date(t),a=new Date;return r.getFullYear()===a.getFullYear()&&r.getMonth()===a.getMonth()&&r.getDate()===a.getDate()?r.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):r.toLocaleDateString([],{month:"short",day:"numeric"})}async function $(t){try{return await chrome.runtime.sendMessage(t)}catch{return null}}function He({onOpen:t}){const[r,a]=d.useState(null),[n,s]=d.useState(!1);async function c(){const l=await $({type:u.RPC_HISTORY_LIST});a(l?.entries??[])}d.useEffect(()=>{c()},[]);async function o(){await $({type:u.RPC_HISTORY_CLEAR}),s(!1),await c()}return r===null?e.jsx("div",{className:"loading-state",children:e.jsx("div",{className:"spinner"})}):r.length===0?e.jsxs("div",{className:"empty-state",children:[e.jsx("div",{className:"empty-title",children:"还没有记录"}),e.jsx("div",{className:"empty-desc",children:"按 ⌘⇧Y 开始第一次识别"})]}):e.jsxs(e.Fragment,{children:[n?e.jsxs("div",{className:"inline-confirm",children:[e.jsx("span",{children:"确定清空全部历史？"}),e.jsxs("div",{className:"inline-confirm-actions",children:[e.jsx("button",{type:"button",className:"btn btn-danger",onClick:o,children:"清空"}),e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:()=>s(!1),children:"取消"})]})]}):e.jsxs("div",{className:"history-toolbar",children:[e.jsxs("span",{className:"history-count",children:[r.length," 条"]}),e.jsx("button",{type:"button",className:"link-danger",onClick:()=>s(!0),children:"清空"})]}),e.jsx("div",{className:"history-grid",children:r.map(l=>e.jsxs("button",{type:"button",className:"history-item",onClick:()=>t(l),children:[e.jsxs("div",{className:"history-thumb",children:[e.jsx(he,{id:l.id}),e.jsx("span",{className:"history-mode",title:I[l.mode]?.label??l.mode,children:e.jsx(D,{mode:l.mode})})]}),e.jsx("div",{className:"history-time",children:fe(l.createdAt)})]},l.id))})]})}function he({id:t}){const[r,a]=d.useState(null);return d.useEffect(()=>{let n=!1;return $({type:u.RPC_HISTORY_THUMB,id:t}).then(s=>{n||s?.ok&&s.thumbnailB64&&a(`data:image/jpeg;base64,${s.thumbnailB64}`)}),()=>{n=!0}},[t]),r?e.jsx("img",{src:r,alt:""}):e.jsx("div",{className:"thumb-skeleton"})}function Fe({entry:t,onDeleted:r}){const[a,n]=d.useState(!1),s=t.mode;async function c(){await $({type:u.RPC_HISTORY_DELETE,id:t.id}),r()}return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"hero",children:e.jsx(he,{id:t.id})}),e.jsxs("div",{className:"history-meta",children:[e.jsxs("span",{children:[e.jsx("span",{className:"history-mode-inline",children:e.jsx(D,{mode:s})})," ",I[s]?.label??s," · ",fe(t.createdAt)]}),a?e.jsxs("span",{className:"inline-confirm-mini",children:[e.jsx("button",{type:"button",className:"btn btn-danger btn-sm",onClick:c,children:"确认删除"}),e.jsx("button",{type:"button",className:"btn btn-secondary btn-sm",onClick:()=>n(!1),children:"取消"})]}):e.jsx("button",{type:"button",className:"link-danger",onClick:()=>n(!0),children:"删除"})]}),s==="image_to_prompt"&&e.jsx(de,{result:t.insight}),s==="product_style"&&e.jsx(pe,{result:t.insight}),s==="webpage_style"&&e.jsx(xe,{result:t.insight}),t.pageUrl&&e.jsxs("a",{className:"link-source",href:t.pageUrl,target:"_blank",rel:"noreferrer",children:["来源：",t.pageUrl]})]})}function We({onSaved:t}){const[r,a]=d.useState(ye),[n,s]=d.useState(!1),[c,o]=d.useState(!1),[l,g]=d.useState(!1),[b,j]=d.useState(!1),[m,L]=d.useState(!1),[M,E]=d.useState(null);d.useEffect(()=>{ie().then(i=>{a(i),s(!0)}).catch(()=>s(!0))},[]);const w=ke.safeParse(r),y={};if(!w.success)for(const i of w.error.issues){const f=i.path[0];f&&!y[f]&&(y[f]=i.message)}const h=(i,f)=>{a(A=>({...A,[i]:f})),j(!1),E(null)},k=i=>{a(f=>{const A=O[f.provider],V=O[i],ue=!f.baseURL||f.baseURL===A.defaultBaseURL?V.defaultBaseURL:f.baseURL,ge=!f.model||f.model===A.defaultModel?V.defaultModel:f.model;return{...f,provider:i,baseURL:ue,model:ge}}),j(!1),E(null)},p=O[r.provider],x=r.provider==="ollama";async function N(i){if(i.preventDefault(),!!w.success){g(!0);try{await ve(w.data),j(!0),setTimeout(()=>t(),700)}finally{g(!1)}}}async function S(){if(w.success){L(!0),E(null);try{const i=await $({type:u.RPC_TEST_CONNECTION,config:{provider:r.provider,baseURL:r.baseURL,apiKey:r.apiKey,model:r.model}});i?.ok?E({ok:!0,msg:`连接成功 (${i.status??200})`}):E({ok:!1,msg:i?.error||`失败 (${i?.status??"?"})`})}finally{L(!1)}}}return n?e.jsxs("form",{onSubmit:N,className:"settings-form",children:[e.jsxs("div",{className:"settings-section",children:[e.jsx("div",{className:"settings-section-title",children:"API 连接"}),e.jsx("div",{className:"settings-section-desc",children:"API Key 只保存在本地 chrome.storage.sync，仅发送到你配置的 Base URL。"}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:"Provider"}),e.jsx("select",{className:"settings-input",value:r.provider,onChange:i=>k(i.target.value),children:je.map(i=>e.jsx("option",{value:i,children:O[i].label},i))}),e.jsx("span",{className:"settings-section-desc",children:p.helpText})]}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:"Base URL"}),e.jsx("input",{type:"url",className:"settings-input",value:r.baseURL,onChange:i=>h("baseURL",i.target.value),placeholder:"https://api.openai.com/v1",required:!0}),y.baseURL&&e.jsx("span",{className:"settings-error",children:y.baseURL})]}),!x&&e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:"API Key"}),e.jsxs("div",{className:"settings-input-row",children:[e.jsx("input",{type:c?"text":"password",className:"settings-input",value:r.apiKey,onChange:i=>h("apiKey",i.target.value),placeholder:"sk-…",required:!0,autoComplete:"off",spellCheck:!1}),e.jsx("button",{type:"button",className:"btn btn-secondary btn-sm",onClick:()=>o(i=>!i),children:c?"隐藏":"显示"})]}),y.apiKey&&e.jsx("span",{className:"settings-error",children:y.apiKey})]}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:"Model"}),e.jsx("input",{type:"text",className:"settings-input",value:r.model,onChange:i=>h("model",i.target.value),placeholder:"gpt-4o",required:!0}),y.model&&e.jsx("span",{className:"settings-error",children:y.model})]})]}),e.jsxs("div",{className:"settings-section",children:[e.jsx("div",{className:"settings-section-title",children:"偏好"}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:"历史记录数量（10–500）"}),e.jsx("input",{type:"number",className:"settings-input",value:r.maxHistory,min:10,max:500,onChange:i=>h("maxHistory",Number.parseInt(i.target.value,10)||0),required:!0}),y.maxHistory&&e.jsx("span",{className:"settings-error",children:y.maxHistory})]}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:"语言"}),e.jsxs("select",{className:"settings-input",value:r.language,onChange:i=>h("language",i.target.value),children:[e.jsx("option",{value:"zh",children:"中文"}),e.jsx("option",{value:"en",children:"English"})]})]})]}),e.jsxs("div",{className:"settings-actions",children:[e.jsx("button",{type:"submit",className:"btn btn-primary",disabled:l||!w.success,children:l?"保存中…":b?"已保存":"保存"}),e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:S,disabled:m||!w.success,children:m?"测试中…":"测试连接"}),M&&e.jsx("span",{className:M.ok?"status-ok":"status-err",children:M.msg})]})]}):e.jsx("div",{className:"loading-state",children:e.jsx("div",{className:"spinner"})})}const me="promptlens.theme";function Ke(){try{const t=localStorage.getItem(me);if(t==="light"||t==="dark")return t}catch{}return typeof matchMedia<"u"&&matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}const re={NO_CONFIG:"请先配置 API",UNAUTHORIZED:"API Key 无效",RATE_LIMITED:"触发限流，请稍后再试",NETWORK_ERROR:"网络请求失败",TIMEOUT:"请求超时",INVALID_RESPONSE:"模型返回格式异常",CAPTURE_FAILED:"截图失败",RESTRICTED_PAGE:"该页面受浏览器限制",UNKNOWN:"出现未知错误"};function Ye(){return{currentStep:"captured",history:[],lastSeq:-1}}function qe({initialView:t,incoming:r,onClose:a,registerCloser:n}){const[s,c]=d.useState(!1),[o,l]=d.useState(t),[g,b]=d.useState(Ke),j=d.useRef(null);function m(){b(h=>{const k=h==="dark"?"light":"dark";try{localStorage.setItem(me,k)}catch{}return k})}d.useEffect(()=>{const h=requestAnimationFrame(()=>c(!0));return()=>cancelAnimationFrame(h)},[]),d.useEffect(()=>{n&&n(()=>{c(!1),setTimeout(a,320)})},[n,a]),d.useEffect(()=>{!r||r===j.current||(j.current=r,r.type===u.LOADING?l(h=>{const k=h.kind==="loading"?h.state:Ye();if(r.seq<=k.lastSeq)return h;const p=r.step!=="failed"&&r.step!==k.currentStep?[...k.history,{step:r.step,elapsedMs:r.elapsedMs}]:k.history;return{kind:"loading",state:{currentStep:r.step,history:p,failedAt:r.step==="failed"?r.failedAt:k.failedAt,errorCode:r.errorCode??k.errorCode,lastSeq:r.seq}}}):r.type===u.RESULT?l({kind:"result",payload:r.payload}):r.type===u.ERROR&&l({kind:"error",code:r.code,message:r.message}))},[r]);function L(){c(!1),setTimeout(a,320)}function M(){chrome.runtime.sendMessage({type:u.RPC_START_SELECTION}).catch(()=>{})}const E=Ve(o),w=o.kind==="history"||o.kind==="history-detail"||o.kind==="settings"||o.kind==="error";function y(){o.kind==="history-detail"?l({kind:"history"}):l({kind:"launcher"})}return e.jsxs("div",{className:`panel theme-${g} ${s?"open":""}`,role:"dialog","aria-label":"PromptLens",children:[e.jsxs("header",{className:"header",children:[e.jsxs("div",{className:"header-left",children:[w?e.jsx("button",{type:"button",className:"icon-btn",onClick:y,title:"返回","aria-label":"Back",children:e.jsx(Se,{})}):e.jsx("span",{className:"brand-dot"}),e.jsx("span",{className:"brand",children:E})]}),e.jsxs("div",{className:"header-actions",children:[e.jsx("button",{type:"button",className:"icon-btn",onClick:m,title:g==="dark"?"切换为浅色":"切换为深色","aria-label":"Toggle theme",children:g==="dark"?e.jsx(Ee,{}):e.jsx(Le,{})}),o.kind!=="history"&&o.kind!=="history-detail"&&e.jsx("button",{type:"button",className:"icon-btn",onClick:()=>l({kind:"history"}),title:"历史","aria-label":"History",children:e.jsx(le,{})}),e.jsx("button",{type:"button",className:"icon-btn",onClick:L,title:"关闭","aria-label":"Close",children:e.jsx(Ne,{})})]})]}),e.jsxs("div",{className:"body",children:[o.kind==="launcher"&&e.jsx(Ge,{onCapture:M,onHistory:()=>l({kind:"history"}),onSettings:()=>l({kind:"settings"})}),o.kind==="loading"&&e.jsxs("div",{className:"loading-state stepper-state",children:[e.jsx(Ae,{currentStep:o.state.currentStep,history:o.state.history,failedAt:o.state.failedAt,errorCode:o.state.errorCode}),o.state.currentStep==="failed"&&e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:M,children:[e.jsx(F,{})," 重试"]})]}),o.kind==="error"&&e.jsx(Ze,{code:o.code,message:o.message,onOpenSettings:()=>l({kind:"settings"}),onRetry:M}),o.kind==="result"&&e.jsx(Je,{payload:o.payload,onRecapture:()=>{l({kind:"launcher"}),M()}}),o.kind==="history"&&e.jsx(He,{onOpen:h=>l({kind:"history-detail",entry:h})}),o.kind==="history-detail"&&e.jsx(Fe,{entry:o.entry,onDeleted:()=>l({kind:"history"})}),o.kind==="settings"&&e.jsx(We,{onSaved:()=>l({kind:"launcher"})})]},o.kind),o.kind==="result"&&o.payload.pageUrl&&e.jsxs("footer",{className:"footer",children:[e.jsx("span",{children:"Source"}),e.jsx("a",{href:o.payload.pageUrl,target:"_blank",rel:"noreferrer",title:o.payload.pageUrl,children:o.payload.pageUrl})]})]})}function Ve(t){switch(t.kind){case"launcher":return"PromptLens";case"loading":return"识别中";case"result":return"识别结果";case"error":return"出错了";case"history":return"历史记录";case"history-detail":return"历史详情";case"settings":return"设置"}}function Ge({onCapture:t,onHistory:r,onSettings:a}){const[n,s]=d.useState(null);return d.useEffect(()=>{ie().then(c=>s(!!c.apiKey)).catch(()=>s(!1))},[]),e.jsxs("div",{className:"launcher",children:[e.jsx(Xe,{}),e.jsxs("div",{className:"hero-card",children:[e.jsx("div",{className:"hero-eyebrow",children:"视觉洞察工具箱"}),e.jsxs("div",{className:"hero-title",children:["把你看到的内容",e.jsx("br",{}),"变成结构化洞察"]}),e.jsxs("button",{type:"button",className:"btn btn-primary btn-lg",onClick:t,children:[e.jsx(F,{}),"开始截图"]}),e.jsxs("div",{className:"shortcut-row",children:[e.jsx(R,{children:"⌘"}),e.jsx(R,{children:"⇧"}),e.jsx(R,{children:"Y"}),e.jsx("span",{className:"shortcut-sep",children:"·"}),e.jsx(R,{children:"Ctrl"}),e.jsx(R,{children:"⇧"}),e.jsx(R,{children:"Y"}),e.jsx("span",{className:"shortcut-hint",children:"全局快捷键"})]})]}),n===!1&&e.jsxs("div",{className:"warning-banner",children:[e.jsx("span",{className:"hero-badge",children:"!"}),e.jsx("span",{children:"尚未配置 API，点「设置」填写后即可使用。"})]}),e.jsxs("div",{className:"tile-grid",children:[e.jsxs("button",{type:"button",className:"tile",onClick:r,children:[e.jsx(le,{}),e.jsx("span",{className:"tile-label",children:"历史记录"}),e.jsx("span",{className:"tile-desc",children:"浏览过往识别结果"})]}),e.jsxs("button",{type:"button",className:"tile",onClick:a,children:[e.jsx(Ce,{}),e.jsx("span",{className:"tile-label",children:"设置"}),e.jsx("span",{className:"tile-desc",children:"API、模型与偏好"})]})]})]})}function Xe(){const[t,r]=d.useState(se);d.useEffect(()=>{chrome.storage.sync.get("mode").then(n=>{const s=n.mode;oe(s)&&r(s)})},[]);function a(n){r(n),chrome.storage.sync.set({mode:n}).catch(()=>{})}return e.jsx("div",{className:"mode-segment",role:"tablist","aria-label":"识别模式",children:be.map(n=>{const s=I[n],c=t===n;return e.jsxs("button",{type:"button",role:"tab","aria-selected":c,className:`mode-segment-btn${c?" mode-segment-btn--active":""}`,onClick:()=>a(n),title:s.description,children:[e.jsx("span",{className:"mode-segment-icon",children:e.jsx(D,{mode:n})}),e.jsx("span",{className:"mode-segment-label",children:s.label})]},n)})})}function Ze({code:t,message:r,onOpenSettings:a,onRetry:n}){const s=t==="NO_CONFIG"||t==="UNAUTHORIZED";return e.jsxs("div",{className:"error-state",children:[e.jsx("div",{className:"error-icon",children:e.jsx(Me,{})}),e.jsx("div",{className:"error-title",children:re[t]??re.UNKNOWN}),e.jsx("div",{className:"error-message",children:r}),e.jsx("div",{className:"error-action",children:s?e.jsx("button",{type:"button",className:"btn btn-primary",onClick:a,children:"打开设置"}):e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:n,children:[e.jsx(F,{})," 重试"]})})]})}function Je({payload:t,onRecapture:r}){const a=t.mode,n=t.insight??t.prompts;return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"hero",children:e.jsx("img",{src:`data:image/jpeg;base64,${t.thumbnailB64}`,alt:"selection"})}),e.jsxs("div",{className:"result-mode",children:[e.jsx("span",{className:"result-mode-icon",children:e.jsx(D,{mode:a})}),e.jsx("span",{className:"result-mode-label",children:I[a]?.label??a})]}),a==="image_to_prompt"&&e.jsx(de,{result:n}),a==="product_style"&&e.jsx(pe,{result:n}),a==="webpage_style"&&e.jsx(xe,{result:n}),e.jsx("div",{className:"result-footer-actions",children:e.jsxs("button",{type:"button",className:"btn btn-primary btn-lg",onClick:r,children:[e.jsx(F,{})," 再截一张"]})})]})}const Qe=`
:host, :root { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', 'Helvetica Neue', system-ui, sans-serif; letter-spacing: -0.003em; }
input, select, button, textarea { font-family: inherit; font-size: inherit; color: inherit; }

.panel {
  position: fixed;
  top: 16px;
  right: 16px;
  bottom: 16px;
  width: 440px;
  max-width: calc(100vw - 32px);
  background: rgba(255, 255, 255, 0.86);
  -webkit-backdrop-filter: blur(24px) saturate(180%);
  backdrop-filter: blur(24px) saturate(180%);
  border-radius: 22px;
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.14), 0 2px 8px rgba(0, 0, 0, 0.04);
  border: 1px solid rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
  z-index: 2147483646;
  color: #1d1d1f;
  overflow: hidden;
  transform: translateX(calc(100% + 24px));
  opacity: 0;
  transition: transform 320ms cubic-bezier(0.22, 1, 0.36, 1), opacity 240ms ease;
}
.panel.open { transform: translateX(0); opacity: 1; }

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.06);
  min-height: 56px;
}
.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.brand {
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.015em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.brand-dot {
  display: inline-block;
  width: 10px; height: 10px;
  border-radius: 50%;
  background: linear-gradient(135deg, #0071e3, #5e5ce6);
  flex-shrink: 0;
}
.header-actions { display: flex; gap: 2px; }
.icon-btn {
  width: 30px; height: 30px;
  border-radius: 50%;
  border: none;
  background: transparent;
  color: #515154;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: background 160ms ease, color 160ms ease;
}
.icon-btn:hover { background: rgba(0,0,0,0.06); color: #1d1d1f; }
.icon-btn svg { width: 15px; height: 15px; }

.body {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  animation: fade-in 220ms ease;
}
@keyframes fade-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
.body::-webkit-scrollbar { width: 10px; }
.body::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.15); border-radius: 8px; border: 3px solid transparent; background-clip: padding-box; }
.body::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.28); border: 3px solid transparent; background-clip: padding-box; }

/* ---------- Launcher ---------- */
.launcher { display: flex; flex-direction: column; gap: 16px; }
.hero-card {
  background: linear-gradient(135deg, #f5f5f7 0%, #ebebed 100%);
  border-radius: 20px;
  padding: 28px 24px;
  text-align: center;
}
.hero-eyebrow {
  font-size: 11.5px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 12px;
}
.hero-title {
  font-size: 22px;
  line-height: 1.2;
  font-weight: 600;
  letter-spacing: -0.022em;
  color: #1d1d1f;
  margin-bottom: 20px;
}
.btn-lg { font-size: 14px; padding: 11px 22px; }
.shortcut-row {
  margin-top: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  flex-wrap: wrap;
}
.shortcut-sep { color: #c7c7cc; margin: 0 4px; }
.shortcut-hint { margin-left: 8px; font-size: 11px; color: #86868b; }
.kbd {
  display: inline-flex;
  min-width: 22px;
  justify-content: center;
  align-items: center;
  background: #ffffff;
  color: #1d1d1f;
  padding: 2px 7px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  border: 1px solid rgba(0,0,0,0.08);
  box-shadow: 0 1px 0 rgba(0,0,0,0.04);
}

.warning-banner {
  display: flex;
  gap: 10px;
  align-items: flex-start;
  background: #fff5f0;
  color: #a1501a;
  border-radius: 12px;
  padding: 10px 14px;
  font-size: 12.5px;
}

.tile-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
.tile {
  background: #f5f5f7;
  border: none;
  border-radius: 16px;
  padding: 18px 16px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 6px;
  align-items: flex-start;
  text-align: left;
  color: #1d1d1f;
  transition: background 160ms ease, transform 120ms ease;
}
.tile:hover { background: #ebebed; }
.tile:active { transform: scale(0.98); }
.tile svg { width: 18px; height: 18px; color: #0071e3; }
.tile-label { font-size: 14px; font-weight: 600; letter-spacing: -0.01em; }
.tile-desc { font-size: 11.5px; color: #86868b; }

/* ---------- Result / Hero image ---------- */
.hero {
  background: #f5f5f7;
  border-radius: 16px;
  padding: 12px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 140px;
  max-height: 220px;
  overflow: hidden;
}
.hero img {
  max-width: 100%;
  max-height: 196px;
  object-fit: contain;
  border-radius: 10px;
  display: block;
}

.segment {
  background: rgba(0,0,0,0.05);
  border-radius: 10px;
  padding: 3px;
  display: flex;
  gap: 2px;
  margin-bottom: 16px;
}
.segment button {
  flex: 1;
  background: transparent;
  border: none;
  padding: 7px 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: #515154;
  border-radius: 8px;
  cursor: pointer;
  transition: background 180ms ease, color 180ms ease, box-shadow 180ms ease;
  letter-spacing: -0.005em;
}
.segment button.active {
  background: #ffffff;
  color: #1d1d1f;
  box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 2px 6px rgba(0,0,0,0.04);
  font-weight: 600;
}

.prompt-card {
  background: #ffffff;
  border: 1px solid rgba(0,0,0,0.06);
  border-radius: 14px;
  padding: 14px 16px;
  margin-bottom: 12px;
}
.prompt-card-label {
  font-size: 11px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 8px;
}
.prompt-text {
  font-family: -apple-system, 'SF Pro Text', system-ui, sans-serif;
  font-size: 13px;
  line-height: 1.55;
  color: #1d1d1f;
  white-space: pre-wrap;
  word-break: break-word;
  max-height: 240px;
  overflow-y: auto;
}

.actions { display: flex; gap: 8px; align-items: center; margin-top: 12px; flex-wrap: wrap; }

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  border: none;
  border-radius: 980px;
  padding: 8px 16px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background 160ms ease, color 160ms ease, transform 120ms ease, opacity 160ms ease;
  letter-spacing: -0.005em;
  -webkit-tap-highlight-color: transparent;
}
.btn:active { transform: scale(0.97); }
.btn:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-primary { background: #0071e3; color: #ffffff; }
.btn-primary:hover:not(:disabled) { background: #0077ed; }
.btn-primary:active:not(:disabled) { background: #006edb; }
.btn-secondary { background: rgba(0,0,0,0.06); color: #1d1d1f; }
.btn-secondary:hover:not(:disabled) { background: rgba(0,0,0,0.09); }
.btn-danger { background: #ff3b30; color: #ffffff; }
.btn-danger:hover:not(:disabled) { filter: brightness(1.06); }
.btn-sm { font-size: 11.5px; padding: 5px 12px; }

.toast {
  font-size: 12px;
  color: #34c759;
  font-weight: 500;
  opacity: 0;
  transform: translateX(-4px);
  transition: opacity 180ms ease, transform 180ms ease;
}
.toast.visible { opacity: 1; transform: translateX(0); }

.collapse-trigger {
  background: none;
  border: none;
  color: #0071e3;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  padding: 4px 0;
  margin-top: 4px;
}
.collapse-trigger:hover { text-decoration: underline; }

.sub-card {
  background: #f5f5f7;
  border-radius: 12px;
  padding: 10px 12px;
  margin-top: 8px;
}
.sub-card-label {
  font-size: 11px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 4px;
}
.sub-card pre {
  font-family: -apple-system, 'SF Pro Text', system-ui, sans-serif;
  font-size: 12.5px;
  line-height: 1.5;
  color: #1d1d1f;
  white-space: pre-wrap;
  word-break: break-word;
}

/* ---------- Mode segment ---------- */
.mode-segment {
  display: flex;
  gap: 4px;
  padding: 4px;
  background: rgba(0,0,0,0.05);
  border-radius: 12px;
}
.mode-segment-btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  padding: 8px 6px;
  font-size: 12px;
  font-weight: 500;
  color: #515154;
  background: transparent;
  border: none;
  border-radius: 9px;
  cursor: pointer;
  transition: background 160ms ease, color 160ms ease, box-shadow 160ms ease;
  letter-spacing: -0.005em;
}
.mode-segment-btn:hover { color: #1d1d1f; }
.mode-segment-btn--active {
  background: #ffffff;
  color: #1d1d1f;
  font-weight: 600;
  box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 2px 6px rgba(0,0,0,0.04);
}
.mode-segment-icon { font-size: 14px; line-height: 1; }
.mode-segment-label { white-space: nowrap; }

/* ---------- Result mode label ---------- */
.result-mode {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  background: rgba(0,113,227,0.08);
  color: #0071e3;
  border-radius: 980px;
  font-size: 11.5px;
  font-weight: 600;
  margin-bottom: 12px;
  letter-spacing: -0.005em;
}
.result-mode-icon { font-size: 13px; line-height: 1; }

/* ---------- Stepper ---------- */
.stepper-state {
  align-items: stretch;
  padding: 32px 24px;
}
.stepper {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
  max-width: 320px;
  margin: 0 auto;
}
.stepper-step {
  display: flex;
  gap: 12px;
  align-items: flex-start;
  min-height: 36px;
}
.stepper-rail {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex-shrink: 0;
  padding-top: 4px;
}
.stepper-dot {
  width: 10px; height: 10px;
  border-radius: 50%;
  background: rgba(0,0,0,0.18);
  transition: background 200ms ease, box-shadow 200ms ease;
}
.stepper-line {
  width: 2px;
  flex: 1;
  min-height: 14px;
  background: rgba(0,0,0,0.08);
  margin-top: 4px;
}
.stepper-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding-bottom: 8px;
}
.stepper-label {
  font-size: 13px;
  font-weight: 500;
  color: #515154;
  letter-spacing: -0.005em;
}
.stepper-elapsed {
  font-size: 11.5px;
  color: #86868b;
  font-variant-numeric: tabular-nums;
}
.stepper-elapsed--done { color: #34c759; }
.stepper-step--current .stepper-dot {
  background: #0071e3;
  box-shadow: 0 0 0 4px rgba(0,113,227,0.18);
  animation: stepper-pulse 1.2s ease-in-out infinite;
}
.stepper-step--current .stepper-label { color: #1d1d1f; font-weight: 600; }
.stepper-step--done .stepper-dot {
  background: #34c759;
  box-shadow: 0 0 0 0 rgba(52,199,89,0);
}
.stepper-step--done .stepper-label { color: #1d1d1f; }
.stepper-step--failed .stepper-dot { background: #ff3b30; }
.stepper-step--failed .stepper-label { color: #ff3b30; font-weight: 600; }
.stepper-step--pending .stepper-label { color: #aeaeb2; }
.stepper-error { color: #ff3b30; font-weight: 500; }
@keyframes stepper-pulse {
  0%, 100% { box-shadow: 0 0 0 4px rgba(0,113,227,0.18); }
  50% { box-shadow: 0 0 0 7px rgba(0,113,227,0.06); }
}

/* ---------- Renderers (product / web) ---------- */
.renderer { display: flex; flex-direction: column; gap: 14px; margin-bottom : 12px;}
.renderer-section {
  background: #ffffff;
  border: 1px solid rgba(0,0,0,0.06);
  border-radius: 14px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.renderer-section-title {
  font-size: 11px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.renderer-block {
  font-size: 13px;
  line-height: 1.5;
  color: #1d1d1f;
  white-space: pre-wrap;
}
.renderer-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: 12.5px;
  padding: 4px 0;
  border-top: 1px solid rgba(0,0,0,0.04);
}
.renderer-row:first-child { border-top: none; }
.renderer-row-label { color: #86868b; flex-shrink: 0; }
.renderer-row-value { color: #1d1d1f; text-align: right; word-break: break-word; }
.renderer-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.renderer-chip {
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  background: rgba(0,0,0,0.05);
  color: #1d1d1f;
  border-radius: 980px;
  font-size: 11.5px;
  font-weight: 500;
  letter-spacing: -0.005em;
}
.renderer-chip--accent {
  background: rgba(0,113,227,0.1);
  color: #0071e3;
}
.renderer-palette {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.palette-swatch {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}
.palette-swatch--primary .palette-chip {
  box-shadow: 0 0 0 2px rgba(0,113,227,0.4);
}
.palette-chip {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: 1px solid rgba(0,0,0,0.08);
}
.palette-code {
  font-size: 10px;
  color: #86868b;
  font-variant-numeric: tabular-nums;
}

/* ---------- History mode badge ---------- */
.history-thumb { position: relative; }
.history-mode {
  position: absolute;
  top: 6px;
  left: 6px;
  width: 22px;
  height: 22px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: rgba(28,28,30,0.65);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  color: #ffffff;
  border-radius: 50%;
  font-size: 12px;
  line-height: 1;
}
.history-mode-inline { font-size: 13px; }

/* ---------- Loading ---------- */
.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 48px 24px;
  gap: 16px;
}
.spinner {
  width: 28px; height: 28px;
  border: 2.5px solid rgba(0,0,0,0.08);
  border-top-color: #0071e3;
  border-radius: 50%;
  animation: spin 720ms linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loading-label { font-size: 14px; color: #515154; font-weight: 500; letter-spacing: -0.01em; }

/* ---------- Empty ---------- */
.empty-state { padding: 60px 24px; text-align: center; }
.empty-title { font-size: 15px; font-weight: 600; color: #1d1d1f; letter-spacing: -0.01em; }
.empty-desc { font-size: 12.5px; color: #86868b; margin-top: 4px; }

/* ---------- Error ---------- */
.error-state {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 32px 12px;
}
.error-icon {
  width: 44px; height: 44px;
  border-radius: 50%;
  background: rgba(255, 59, 48, 0.1);
  color: #ff3b30;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
}
.error-title {
  font-size: 15px;
  font-weight: 600;
  text-align: center;
  color: #1d1d1f;
  letter-spacing: -0.01em;
}
.error-message {
  font-size: 12.5px;
  color: #86868b;
  text-align: center;
  line-height: 1.5;
  word-break: break-word;
}
.error-action { display: flex; justify-content: center; margin-top: 4px; }

.footer {
  padding: 12px 20px 16px;
  border-top: 1px solid rgba(0,0,0,0.06);
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  font-size: 11.5px;
  color: #86868b;
}
.footer a { color: #86868b; text-decoration: none; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 280px; }
.footer a:hover { color: #0071e3; }

/* ---------- History ---------- */
.history-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding: 0 2px;
}
.history-count { font-size: 12px; color: #86868b; font-weight: 500; }
.link-danger {
  background: none; border: none; padding: 0;
  color: #ff3b30; font-size: 12.5px; font-weight: 500; cursor: pointer;
}
.link-danger:hover { opacity: 0.75; }

.inline-confirm {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff5f0;
  color: #a1501a;
  border-radius: 12px;
  padding: 10px 14px;
  font-size: 12.5px;
  margin-bottom: 12px;
  gap: 10px;
}
.inline-confirm-actions { display: flex; gap: 6px; }
.inline-confirm-mini { display: inline-flex; gap: 6px; align-items: center; }

.history-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
.history-item {
  background: transparent;
  border: none;
  padding: 0;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 4px;
  text-align: left;
}
.history-thumb {
  overflow: hidden;
  border-radius: 12px;
  background: #f5f5f7;
  aspect-ratio: 4/3;
  transition: box-shadow 220ms ease, transform 220ms ease;
}
.history-item:hover .history-thumb {
  box-shadow: 0 6px 20px rgba(0,0,0,0.1);
  transform: translateY(-1px);
}
.history-thumb img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 300ms ease;
}
.history-item:hover .history-thumb img { transform: scale(1.03); }
.history-time { font-size: 10.5px; color: #86868b; padding: 0 2px; }
.thumb-skeleton {
  width: 100%; height: 100%;
  background: linear-gradient(100deg, #f5f5f7 30%, #ebebed 50%, #f5f5f7 70%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
@keyframes shimmer {
  0% { background-position: 100% 0; }
  100% { background-position: -100% 0; }
}

.result-footer-actions {
  display: flex;
  justify-content: center;
  padding-top: 4px;
}

.history-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  font-size: 11.5px;
  color: #86868b;
  padding: 0 2px;
}
.link-source {
  display: block;
  font-size: 11px;
  color: #86868b;
  text-decoration: none;
  margin-top: -4px;
  margin-bottom: 8px;
  padding: 0 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.link-source:hover { color: #0071e3; }

/* ---------- Settings ---------- */
.settings-form { display: flex; flex-direction: column; gap: 14px; }
.settings-section {
  background: #ffffff;
  border: 1px solid rgba(0,0,0,0.06);
  border-radius: 16px;
  padding: 16px 18px;
}
.settings-section-title {
  font-size: 13.5px;
  font-weight: 600;
  letter-spacing: -0.01em;
  margin-bottom: 4px;
}
.settings-section-desc {
  font-size: 11.5px;
  color: #86868b;
  line-height: 1.5;
  margin-bottom: 12px;
}
.settings-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px 0;
  border-top: 1px solid rgba(0,0,0,0.05);
}
.settings-field:first-of-type { border-top: none; padding-top: 4px; }
.settings-field-label {
  font-size: 12.5px;
  font-weight: 500;
  color: #1d1d1f;
}
.settings-input {
  width: 100%;
  padding: 8px 12px;
  border-radius: 10px;
  background: #f5f5f7;
  border: 1px solid transparent;
  font-size: 13px;
  color: #1d1d1f;
  outline: none;
  transition: background 160ms ease, border-color 160ms ease, box-shadow 160ms ease;
}
.settings-input:focus {
  background: #ffffff;
  border-color: #0071e3;
  box-shadow: 0 0 0 3px rgba(0, 113, 227, 0.18);
}
.settings-input-row { display: flex; gap: 8px; align-items: center; }
.settings-input-row .settings-input { flex: 1; }
.settings-error { font-size: 11.5px; color: #ff3b30; }

.settings-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-top: 4px;
  padding: 12px 16px;
  background: rgba(245, 245, 247, 0.6);
  border-radius: 14px;
  -webkit-backdrop-filter: blur(12px);
  backdrop-filter: blur(12px);
  position: sticky;
  bottom: -20px;
}
.status-ok { font-size: 12.5px; color: #34c759; font-weight: 500; }
.status-err { font-size: 12.5px; color: #ff3b30; font-weight: 500; }

/* ---------- Dark ---------- */
@media (prefers-color-scheme: dark) {
  .panel:not(.theme-light) {
    background: rgba(28, 28, 30, 0.85);
    border-color: rgba(255,255,255,0.08);
    color: #f5f5f7;
  }
  .header, .footer { border-color: rgba(255,255,255,0.08); }
  .icon-btn { color: #aeaeb2; }
  .icon-btn:hover { background: rgba(255,255,255,0.08); color: #ffffff; }
  .hero, .sub-card, .tile, .history-thumb { background: rgba(255,255,255,0.06); }
  .hero-card { background: linear-gradient(135deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02)); }
  .hero-title { color: #f5f5f7; }
  .tile:hover { background: rgba(255,255,255,0.1); }
  .segment { background: rgba(255,255,255,0.08); }
  .segment button { color: #aeaeb2; }
  .segment button.active { background: rgba(255,255,255,0.14); color: #ffffff; }
  .prompt-card, .settings-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08); }
  .prompt-card-label, .sub-card-label, .error-message, .loading-label, .footer, .history-count, .history-time, .settings-section-desc, .empty-desc, .shortcut-hint, .hero-eyebrow { color: #aeaeb2; }
  .prompt-text, .sub-card pre, .error-title, .empty-title, .settings-field-label, .settings-section-title { color: #f5f5f7; }
  .btn-secondary { background: rgba(255,255,255,0.1); color: #f5f5f7; }
  .btn-secondary:hover:not(:disabled) { background: rgba(255,255,255,0.14); }
  .btn-primary { background: #0a84ff; }
  .btn-primary:hover:not(:disabled) { background: #0a84ff; filter: brightness(1.1); }
  .kbd { background: rgba(255,255,255,0.12); color: #f5f5f7; border-color: rgba(255,255,255,0.16); box-shadow: 0 1px 0 rgba(0,0,0,0.2); }
  .settings-input { background: rgba(255,255,255,0.06); color: #f5f5f7; }
  .settings-input:focus { background: rgba(255,255,255,0.1); border-color: #0a84ff; box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.22); }
  .settings-field { border-color: rgba(255,255,255,0.06); }
  .settings-actions { background: rgba(255,255,255,0.04); }
  .warning-banner, .inline-confirm { background: rgba(255, 149, 0, 0.16); color: #ffd180; }
  .mode-segment { background: rgba(255,255,255,0.08); }
  .mode-segment-btn { color: #aeaeb2; }
  .mode-segment-btn--active { background: rgba(255,255,255,0.14); color: #ffffff; }
  .renderer-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08); }
  .renderer-block, .renderer-row-value { color: #f5f5f7; }
  .renderer-row { border-color: rgba(255,255,255,0.06); }
  .renderer-chip { background: rgba(255,255,255,0.08); color: #f5f5f7; }
  .renderer-chip--accent { background: rgba(10,132,255,0.16); color: #4aa6ff; }
  .palette-chip { border-color: rgba(255,255,255,0.12); }
  .stepper-dot { background: rgba(255,255,255,0.18); }
  .stepper-line { background: rgba(255,255,255,0.08); }
  .stepper-step--current .stepper-dot { background: #0a84ff; box-shadow: 0 0 0 4px rgba(10,132,255,0.22); }
  .stepper-step--done .stepper-dot { background: #34c759; }
  .stepper-step--pending .stepper-label { color: #6e6e72; }
  .stepper-label { color: #aeaeb2; }
  .stepper-step--current .stepper-label, .stepper-step--done .stepper-label { color: #f5f5f7; }
  .result-mode { background: rgba(10,132,255,0.16); color: #4aa6ff; }
}

/* Mode icon svg sizing */
.mode-segment-icon svg { width: 13px; height: 13px; display: block; }
.result-mode-icon svg { width: 12px; height: 12px; display: block; }
.history-mode svg { width: 11px; height: 11px; display: block; }
.history-mode-inline svg { width: 11px; height: 11px; vertical-align: -1px; }
.overlay-mode-icon { display: inline-flex; align-items: center; margin-right: 4px; }
.overlay-mode-icon svg { width: 11px; height: 11px; display: block; }

/* Extra tile override — .tile has its own color so needs dark reset */
@media (prefers-color-scheme: dark) {
  .panel:not(.theme-light) .tile { color: #f5f5f7; }
}
.panel.theme-dark .tile { color: #f5f5f7; }

/* Explicit dark theme class overrides */
.panel.theme-dark {
    background: rgba(28, 28, 30, 0.85);
    border-color: rgba(255,255,255,0.08);
    color: #f5f5f7;
   }
.panel.theme-dark .header, .panel.theme-dark .footer { border-color: rgba(255,255,255,0.08);  }
.panel.theme-dark .icon-btn { color: #aeaeb2;  }
.panel.theme-dark .icon-btn:hover { background: rgba(255,255,255,0.08); color: #ffffff;  }
.panel.theme-dark .hero, .panel.theme-dark .sub-card, .panel.theme-dark .tile, .panel.theme-dark .history-thumb { background: rgba(255,255,255,0.06);  }
.panel.theme-dark .hero-card { background: linear-gradient(135deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));  }
.panel.theme-dark .hero-title { color: #f5f5f7;  }
.panel.theme-dark .tile:hover { background: rgba(255,255,255,0.1);  }
.panel.theme-dark .segment { background: rgba(255,255,255,0.08);  }
.panel.theme-dark .segment button { color: #aeaeb2;  }
.panel.theme-dark .segment button.active { background: rgba(255,255,255,0.14); color: #ffffff;  }
.panel.theme-dark .prompt-card, .panel.theme-dark .settings-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08);  }
.panel.theme-dark .prompt-card-label, .panel.theme-dark .sub-card-label, .panel.theme-dark .error-message, .panel.theme-dark .loading-label, .panel.theme-dark .footer, .panel.theme-dark .history-count, .panel.theme-dark .history-time, .panel.theme-dark .settings-section-desc, .panel.theme-dark .empty-desc, .panel.theme-dark .shortcut-hint, .panel.theme-dark .hero-eyebrow { color: #aeaeb2;  }
.panel.theme-dark .prompt-text, .panel.theme-dark .sub-card pre, .panel.theme-dark .error-title, .panel.theme-dark .empty-title, .panel.theme-dark .settings-field-label, .panel.theme-dark .settings-section-title { color: #f5f5f7;  }
.panel.theme-dark .btn-secondary { background: rgba(255,255,255,0.1); color: #f5f5f7;  }
.panel.theme-dark .btn-secondary:hover:not(:disabled) { background: rgba(255,255,255,0.14);  }
.panel.theme-dark .btn-primary { background: #0a84ff;  }
.panel.theme-dark .btn-primary:hover:not(:disabled) { background: #0a84ff; filter: brightness(1.1);  }
.panel.theme-dark .kbd { background: rgba(255,255,255,0.12); color: #f5f5f7; border-color: rgba(255,255,255,0.16); box-shadow: 0 1px 0 rgba(0,0,0,0.2);  }
.panel.theme-dark .settings-input { background: rgba(255,255,255,0.06); color: #f5f5f7;  }
.panel.theme-dark .settings-input:focus { background: rgba(255,255,255,0.1); border-color: #0a84ff; box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.22);  }
.panel.theme-dark .settings-field { border-color: rgba(255,255,255,0.06);  }
.panel.theme-dark .settings-actions { background: rgba(255,255,255,0.04);  }
.panel.theme-dark .warning-banner, .panel.theme-dark .inline-confirm { background: rgba(255, 149, 0, 0.16); color: #ffd180;  }
.panel.theme-dark .mode-segment { background: rgba(255,255,255,0.08);  }
.panel.theme-dark .mode-segment-btn { color: #aeaeb2;  }
.panel.theme-dark .mode-segment-btn--active { background: rgba(255,255,255,0.14); color: #ffffff;  }
.panel.theme-dark .renderer-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08);  }
.panel.theme-dark .renderer-block, .panel.theme-dark .renderer-row-value { color: #f5f5f7;  }
.panel.theme-dark .renderer-row { border-color: rgba(255,255,255,0.06);  }
.panel.theme-dark .renderer-chip { background: rgba(255,255,255,0.08); color: #f5f5f7;  }
.panel.theme-dark .renderer-chip--accent { background: rgba(10,132,255,0.16); color: #4aa6ff;  }
.panel.theme-dark .palette-chip { border-color: rgba(255,255,255,0.12);  }
.panel.theme-dark .stepper-dot { background: rgba(255,255,255,0.18);  }
.panel.theme-dark .stepper-line { background: rgba(255,255,255,0.08);  }
.panel.theme-dark .stepper-step--current .stepper-dot { background: #0a84ff; box-shadow: 0 0 0 4px rgba(10,132,255,0.22);  }
.panel.theme-dark .stepper-step--done .stepper-dot { background: #34c759;  }
.panel.theme-dark .stepper-step--pending .stepper-label { color: #6e6e72;  }
.panel.theme-dark .stepper-label { color: #aeaeb2;  }
.panel.theme-dark .stepper-step--current .stepper-label, .panel.theme-dark .stepper-step--done .stepper-label { color: #f5f5f7;  }
.panel.theme-dark .result-mode { background: rgba(10,132,255,0.16); color: #4aa6ff;  }
`,et="img2prompt-overlay-host",tt="img2prompt-panel-host";let P=null,v=null,T=null,C=null,H=null,Y=null,_=null;function rt(t){if(v)return;v=document.createElement("div"),v.id=et,v.style.all="initial";const r=v.attachShadow({mode:"open"}),a=document.createElement("style");a.textContent=De,r.appendChild(a);const n=document.createElement("div");r.appendChild(n),document.documentElement.appendChild(v),P=ae(n),P.render(d.createElement(Ie,{excludeHost:v,mode:t,onComplete:s=>{chrome.runtime.sendMessage({type:u.SELECTION_COMPLETE,rect:s,dpr:window.devicePixelRatio||1,pageUrl:location.href,mode:t}),ne()},onCancel:()=>{chrome.runtime.sendMessage({type:u.SELECTION_CANCEL}),ne(),q({})}}))}function ne(){P&&(P.unmount(),P=null),v&&v.parentNode&&v.parentNode.removeChild(v),v=null}function nt(){if(C)return;C=document.createElement("div"),C.id=tt,C.style.all="initial";const t=C.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=Qe,t.appendChild(r),H=document.createElement("div"),t.appendChild(H),document.documentElement.appendChild(C),T=ae(H)}function at(){T&&(T.unmount(),T=null),C&&C.parentNode&&C.parentNode.removeChild(C),C=null,H=null,_=null,Y=null}function q(t){nt(),T&&(t.incoming!==void 0&&(Y=t.incoming),T.render(d.createElement(qe,{initialView:{kind:"launcher"},incoming:Y,onClose:at,registerCloser:r=>{_=r}})))}function st(){_&&(_(),_=null)}async function ot(){try{const r=(await chrome.storage.sync.get("mode")).mode;if(oe(r))return r}catch{}return se}async function it(){const t=await ot();st(),rt(t)}chrome.runtime.onMessage.addListener(t=>{const r=t;if(!(!r||typeof r!="object")){if(console.log("[img2prompt][content] received",r.type),r.type===u.START_SELECTION){it();return}if(r.type===u.PANEL_OPEN){q({});return}if(r.type===u.LOADING||r.type===u.RESULT||r.type===u.ERROR){q({incoming:t});return}}});export{ot as resolveModeForSelection};
