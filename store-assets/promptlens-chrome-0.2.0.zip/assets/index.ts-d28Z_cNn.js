import{a as d,i as U,D as P,L}from"./messages-Ceg1ccJ7.js";import{W as M,b as B,c as G,g as T,i as W,l as j}from"./config-C44AtlOB.js";import{l as J,g as q,r as H,c as K,a as $}from"./storage-CVKh_Pss.js";const z=`You are a reverse-prompt expert. Given an image, produce a JSON object with prompts that, when used in their respective models, would generate an image with a similar VISUAL STYLE (not identical content). Focus on: medium, lighting, composition, color palette, texture, mood, camera / render style. Avoid naming specific IPs or real people.

Return strictly valid JSON matching this schema:
{
  "style_summary": "punchy headline describing the overall vibe, <= 12 words",
  "aspect_ratio": "W:H string matching the source image aspect, e.g. \\"16:9\\"",
  "natural_language": "40-60 word generator-agnostic description of subject + style + mood, no --params",
  "tags": ["8-20 short English tags"],
  "midjourney": "natural-language description ending with parameters like --ar W:H --style raw --v 6",
  "stable_diffusion": {
    "positive": "comma-separated keyword stack with optional (token:weight) syntax",
    "negative": "comma-separated negative keywords",
    "weights_explained": "one short sentence explaining why you chose the weights"
  },
  "flux": {
    "prompt": "natural-language prompt tuned for Flux v1.1 — continuous prose emphasizing composition, subject, style"
  },
  "dalle": "natural-language paragraph of roughly 60 words"
}

Rules:
- Output JSON only. No prose, no markdown fences.
- aspect_ratio: match the source image aspect. Typical values: "1:1" | "4:5" | "3:4" | "4:3" | "16:9" | "9:16" | "2:3" | "3:2".
- style_summary: <= 12 words, punchy headline.
- natural_language: 40-60 words, generator-agnostic, describes subject + style + mood. No --params, no model-specific syntax.
- tags: 8-20 short English tags, comma-separable.
- Midjourney prompt MUST end with --ar and --v 6 (add --style raw when the look is photographic/realistic). Use the aspect_ratio value for --ar (if 1:1, still emit --ar 1:1).
- Stable Diffusion positive uses keyword-stack style (not full sentences) and may include weights.
- Flux prompt is continuous natural-language prose tuned for Flux v1.1 (emphasize composition, subject, style).
- DALL·E is a single ~60-word paragraph in natural English.`,Y=`你是反向提示词（reverse prompt）专家。给定一张图片，请输出一个 JSON 对象，其中的提示词在各自模型里能生成风格（不是完全相同的内容）接近的图片。聚焦：媒介、光线、构图、色板、质感、氛围、相机/渲染风格。不要出现具体 IP 或真实人物姓名。

严格按照以下 schema 返回 JSON：
{
  "style_summary": "一句话概括整体氛围的标题，不超过 12 词",
  "aspect_ratio": "W:H 字符串，匹配源图长宽比，例如 \\"16:9\\"",
  "natural_language": "40-60 词的通用型描述，含主体+风格+氛围，不含任何 --参数",
  "tags": ["8-20 个英文短标签"],
  "midjourney": "自然语言描述，结尾附 --ar 宽:高 --style raw --v 6 等参数",
  "stable_diffusion": {
    "positive": "逗号分隔的关键词堆叠，可用 (token:weight) 权重语法",
    "negative": "逗号分隔的负向关键词",
    "weights_explained": "一句话解释为何如此设定权重"
  },
  "flux": {
    "prompt": "为 Flux v1.1 调优的自然语言 prompt，连续散文，突出构图、主体与风格"
  },
  "dalle": "约 60 词的自然语言段落"
}

规则：
- 仅输出 JSON，不要任何解释性文字或 markdown 代码块。
- aspect_ratio：匹配源图长宽比，常见取值 "1:1" | "4:5" | "3:4" | "4:3" | "16:9" | "9:16" | "2:3" | "3:2"。
- style_summary：不超过 12 词的短标题。
- natural_language：40-60 词，通用型描述，包含主体+风格+氛围，不含任何 --参数或模型特定语法。
- tags：8-20 个英文短标签，可逗号分隔。
- Midjourney 结尾必须带 --ar 与 --v 6；若画面偏写实摄影，再追加 --style raw。--ar 的值使用 aspect_ratio（即便是 1:1 也要输出 --ar 1:1）。
- Stable Diffusion positive 使用关键词堆叠风格（不是整句），可附权重。
- Flux prompt 使用连续自然语言散文，针对 Flux v1.1 调优，强调构图、主体与风格。
- DALL·E 为约 60 词的自然语言段落（英文输出即可）。`,V=`You are a product-design analyst. Given a product photograph, extract its visual style as a JSON object suitable for downstream design search, prompt generation, and shot reproduction.

Return strictly valid JSON matching this schema:
{
  "palette": ["#hex or css color name", ...3-8 entries, ordered by visual dominance],
  "materials": ["brushed aluminum", "matte plastic", ...],
  "lighting": "short phrase, e.g. 'soft studio key + rim light'",
  "mood": ["premium", "minimal", ...],
  "camera": "short phrase, e.g. 'three-quarter front, 50mm, shallow DOF'",
  "tags": ["searchable", "keywords", ...3+ entries],
  "cmf": {
    "colors": ["#hex or name", ...],
    "materials": ["soft-touch plastic", "anodized aluminum", ...],
    "finishes": ["matte", "brushed", "anodized", ...]
  },
  "lighting_detail": {
    "key": "soft top 45°",
    "fill": "bounce from left",
    "ambient": "low, cool ambient"
  },
  "lens": {
    "focal_length": "50mm",
    "angle": "three-quarter front",
    "depth_of_field": "shallow"
  },
  "composition": "centered, rule-of-thirds, negative space top",
  "scene": {
    "setting": "seamless paper white",
    "props": ["linen cloth", "ceramic dish"]
  },
  "shot_list": {
    "camera": "50mm lens, three-quarter front, eye-level",
    "lighting": "soft key at 45° top-left, bounce fill right",
    "background": "seamless white paper sweep",
    "props": "minimal — linen cloth under product",
    "post": "clean color, subtle contrast, keep natural shadows"
  },
  "prompt": {
    "midjourney": "natural-language Midjourney prompt ending with --ar W:H --style raw --v 6 that would generate a similar product shot",
    "natural_language": "60-80 word generator-agnostic description (English) for users to paste into any image generator"
  }
}

Example — sleek black wireless earbuds case:
{"palette":["#0a0a0a","#1f1f1f","#9b9b9b"],"materials":["soft-touch matte plastic","polished metal hinge"],"lighting":"soft top key with rim","mood":["premium","minimal","tech"],"camera":"three-quarter front, 50mm, shallow DOF","tags":["earbuds","case","minimal","matte black","tech"],"cmf":{"colors":["#0a0a0a","#1f1f1f"],"materials":["soft-touch plastic","stainless hinge"],"finishes":["matte","polished"]},"lighting_detail":{"key":"soft top-left 45°","fill":"low silver bounce right","ambient":"dim cool ambient"},"lens":{"focal_length":"50mm","angle":"three-quarter front","depth_of_field":"shallow"},"composition":"centered, rule-of-thirds, negative space top","scene":{"setting":"seamless dark grey paper","props":["matte acrylic riser"]},"shot_list":{"camera":"50mm, three-quarter front, eye-level","lighting":"soft key top-left 45°, silver bounce right","background":"seamless dark grey paper sweep","props":"matte acrylic riser only","post":"keep deep blacks, preserve highlight roll-off"},"prompt":{"midjourney":"sleek matte black wireless earbuds charging case, soft top-left studio key light with silver bounce fill, seamless dark grey paper sweep, three-quarter front angle, 50mm, shallow DOF, premium minimal tech product photography --ar 4:3 --style raw --v 6","natural_language":"A sleek matte black wireless earbuds charging case photographed in a premium product studio. Soft top-left 45° key light with a silver bounce reflector on the right. Seamless dark grey paper sweep background. Three-quarter front angle, 50mm lens, shallow depth of field. Single matte acrylic riser as prop. Deep blacks preserved with subtle highlight roll-off for a premium minimal aesthetic."}}

Rules:
- Output JSON only. No prose, no markdown fences.
- Use lowercase color hex when possible; otherwise CSS color keyword.
- Keep every phrase concise — under ~8 words.
- Always populate the legacy top-level fields (palette, materials, lighting, mood, camera, tags) even when the structured fields are present — derive short summaries.
- shot_list fields must be actionable one-line instructions a photographer could follow to reproduce the shot.`,Z=`你是产品设计分析师。给定一张产品图，请以 JSON 形式提取其视觉风格，便于后续做设计检索、Prompt 生成与复刻拍摄。

严格按以下 schema 输出 JSON：
{
  "palette": ["#hex 或 CSS 颜色关键字", ...3-8 项，按主导程度排序],
  "materials": ["磨砂铝", "哑光塑料", ...],
  "lighting": "短语，例如 '柔和顶光 + 轮廓光'",
  "mood": ["高端", "极简", ...],
  "camera": "短语，例如 '三分之二正面，50mm，浅景深'",
  "tags": ["可检索", "关键词", ...至少 3 项],
  "cmf": {
    "colors": ["#hex 或颜色名", ...],
    "materials": ["软触塑料", "阳极氧化铝", ...],
    "finishes": ["哑光", "拉丝", "阳极氧化", ...]
  },
  "lighting_detail": {
    "key": "顶部 45° 柔光",
    "fill": "左侧反光板补光",
    "ambient": "低位冷调环境光"
  },
  "lens": {
    "focal_length": "50mm",
    "angle": "三分之二正面",
    "depth_of_field": "浅景深"
  },
  "composition": "居中、三分法、顶部留白",
  "scene": {
    "setting": "无缝白卡纸",
    "props": ["亚麻布", "陶瓷托盘"]
  },
  "shot_list": {
    "camera": "50mm 镜头，三分之二正面，平视高度",
    "lighting": "顶左 45° 柔光主光，右侧反光板补光",
    "background": "无缝白卡纸背景",
    "props": "极简，仅产品下方一块亚麻布",
    "post": "干净调色，轻微对比，保留自然阴影"
  },
  "prompt": {
    "midjourney": "以 --ar W:H --style raw --v 6 结尾的 Midjourney 英文提示词，能生成类似风格的产品图",
    "natural_language": "60-80 词的英文描述，适用于任意图像生成器，重点描述产品外观、风格、光线与构图"
  }
}

示例 — 黑色无线耳机充电盒：
{"palette":["#0a0a0a","#1f1f1f","#9b9b9b"],"materials":["软触哑光塑料","抛光金属转轴"],"lighting":"柔顶光 + 轻微轮廓光","mood":["高端","极简","科技感"],"camera":"三分之二正面，50mm，浅景深","tags":["耳机","充电盒","极简","哑光黑","科技"],"cmf":{"colors":["#0a0a0a","#1f1f1f"],"materials":["软触塑料","不锈钢转轴"],"finishes":["哑光","抛光"]},"lighting_detail":{"key":"顶左 45° 柔光","fill":"右侧低位银色反光板","ambient":"冷调弱环境光"},"lens":{"focal_length":"50mm","angle":"三分之二正面","depth_of_field":"浅景深"},"composition":"居中、三分法、顶部留白","scene":{"setting":"深灰无缝背景纸","props":["哑光亚克力垫块"]},"shot_list":{"camera":"50mm，三分之二正面，平视","lighting":"顶左 45° 柔主光，右侧银色反光板","background":"深灰无缝背景纸","props":"仅一块哑光亚克力垫块","post":"保留深黑，控制高光滚降"},"prompt":{"midjourney":"sleek matte black wireless earbuds charging case, soft top-left studio key light with silver bounce fill, seamless dark grey paper sweep, three-quarter front angle, 50mm, shallow DOF, premium minimal tech product photography --ar 4:3 --style raw --v 6","natural_language":"A sleek matte black wireless earbuds charging case photographed in a premium product studio. Soft top-left 45° key light with a silver bounce reflector on the right. Seamless dark grey paper sweep background. Three-quarter front angle, 50mm lens, shallow depth of field. Single matte acrylic riser as prop. Deep blacks preserved with subtle highlight roll-off for a premium minimal aesthetic."}}

规则：
- 仅输出 JSON，不要任何说明文字或 markdown 代码块。
- 颜色尽量用小写 hex；否则用 CSS 关键字。
- 每个短语保持精炼（约 8 个词以内）。
- 即使已填结构化字段，也必须同时填写顶层旧字段（palette / materials / lighting / mood / camera / tags），用简短总结。
- shot_list 中每项需为摄影师可直接执行的一行指令，便于复刻这张图。`,Q=`You are a senior web/UI design analyst. Given a webpage screenshot, extract its design language as JSON suitable for design system reuse.

Return strictly valid JSON matching this schema:
{
  "layout": "e.g. '12-col centered hero, split feature rows, 3-card grid'",
  "typography": {
    "heading": "e.g. 'geometric sans, tight tracking, 56-72px display'",
    "body": "e.g. 'humanist sans, 16px, 1.6 line-height'"
  },
  "colors": {
    "primary": "#hex",
    "accents": ["#hex", ...]
  },
  "components": ["sticky nav with translucent blur", "primary CTA button", "feature card", ...at least 2],
  "interactions": ["scroll-reveal feature rows", "subtle hover lift on cards", ...at least 1],
  "tone": "e.g. 'confident, enterprise, productivity-focused'",
  "tokens": {
    "color":   { "<semantic.name>": { "value": "#hex", "description": "optional" } },
    "font_size": { "<name>": { "value": "16px", "line_height": "1.5" } },
    "spacing": { "<name>": "16px" },
    "radius":  { "<name>": "8px" },
    "shadow":  { "<name>": "0 1px 2px rgba(0,0,0,0.06)" }
  }
}

Rules:
- Output JSON only. No prose, no markdown fences.
- Concise phrases, no full sentences except where natural (heading/body specs, tone).
- Prefer concrete UI vocabulary (hero, nav, card, CTA, grid, modal, tabs, accordion).
- "tokens" is required in addition to the legacy fields. Use SEMANTIC names (role-based), never raw "color-1".
- tokens.color: 4-10 entries. Roles like "brand.primary", "brand.accent", "text.body", "text.muted", "bg.canvas", "bg.surface", "border.subtle", "status.positive", "status.warning", "status.danger".
- tokens.font_size: 5-8 entries on a T-shirt scale (xs/sm/base/md/lg/xl/2xl/3xl) or semantic (body/h1/h2/display). Include line_height when visible.
- tokens.spacing: 6-10 entries on a consistent ratio (xs=4px, sm=8px, md=16px, lg=24px, xl=32px, 2xl=48px, 3xl=64px). Adjust to the actual rhythm.
- tokens.radius: 3-6 entries (none=0, sm, md, lg, xl, full=9999px).
- tokens.shadow: 2-5 entries (sm, md, lg, xl) with valid CSS shadow values.
- All hex colors use #RGB or #RRGGBB or #RRGGBBAA.

Worked example (landing page with a blue brand and warm accent):
{
  "layout": "12-col centered hero with split CTA, 3-up feature grid, testimonial strip",
  "typography": {
    "heading": "geometric sans, tight tracking, 56-72px display",
    "body": "humanist sans, 16px, 1.6 line-height"
  },
  "colors": { "primary": "#0A84FF", "accents": ["#FF375F", "#30D158"] },
  "components": ["translucent sticky nav", "primary CTA button", "feature card with icon"],
  "interactions": ["scroll-reveal feature rows", "hover lift on cards"],
  "tone": "confident, enterprise, productivity-focused",
  "tokens": {
    "color": {
      "brand.primary":   { "value": "#0A84FF" },
      "brand.accent":    { "value": "#FF375F" },
      "text.body":       { "value": "#1D1D1F" },
      "text.muted":      { "value": "#6E6E73" },
      "bg.canvas":       { "value": "#FFFFFF" },
      "bg.surface":      { "value": "#F5F5F7" },
      "border.subtle":   { "value": "#E5E5EA" },
      "status.positive": { "value": "#30D158" }
    },
    "font_size": {
      "xs":      { "value": "12px", "line_height": "1.4" },
      "sm":      { "value": "14px", "line_height": "1.5" },
      "base":    { "value": "16px", "line_height": "1.6" },
      "lg":      { "value": "20px", "line_height": "1.5" },
      "xl":      { "value": "28px", "line_height": "1.3" },
      "display": { "value": "56px", "line_height": "1.1" }
    },
    "spacing": { "xs": "4px", "sm": "8px", "md": "16px", "lg": "24px", "xl": "32px", "2xl": "48px", "3xl": "64px" },
    "radius":  { "none": "0", "sm": "4px", "md": "8px", "lg": "16px", "full": "9999px" },
    "shadow":  {
      "sm": "0 1px 2px rgba(0,0,0,0.06)",
      "md": "0 4px 12px rgba(0,0,0,0.08)",
      "lg": "0 12px 32px rgba(0,0,0,0.12)"
    }
  }
}`,X=`你是资深 Web/UI 设计分析师。给定一张网页截图，请以 JSON 形式提取其设计语言，便于设计体系复用。

严格按以下 schema 输出 JSON：
{
  "layout": "例如 '12 栅格居中 hero、左右分栏特性区、三卡网格'",
  "typography": {
    "heading": "例如 '几何无衬线，紧字距，56-72px display'",
    "body": "例如 '人文无衬线，16px，行高 1.6'"
  },
  "colors": {
    "primary": "#hex",
    "accents": ["#hex", ...]
  },
  "components": ["半透模糊吸顶导航", "主 CTA 按钮", "特性卡片", ...至少 2 项],
  "interactions": ["滚动入场的特性区", "卡片轻微悬浮抬起", ...至少 1 项],
  "tone": "例如 '自信、企业级、效率导向'",
  "tokens": {
    "color":   { "<语义名>": { "value": "#hex", "description": "可选" } },
    "font_size": { "<名称>": { "value": "16px", "line_height": "1.5" } },
    "spacing": { "<名称>": "16px" },
    "radius":  { "<名称>": "8px" },
    "shadow":  { "<名称>": "0 1px 2px rgba(0,0,0,0.06)" }
  }
}

规则：
- 仅输出 JSON，不要任何说明文字或 markdown 代码块。
- 短语精炼，仅 typography/tone 等可使用自然短句。
- 优先使用具体 UI 术语（hero、nav、card、CTA、grid、modal、tabs、accordion 等）。
- 除旧字段外必须输出 "tokens"。使用**语义命名**（按角色命名），禁止 "color-1" 这类无意义名字。
- tokens.color：4-10 条，如 "brand.primary"、"brand.accent"、"text.body"、"text.muted"、"bg.canvas"、"bg.surface"、"border.subtle"、"status.positive"、"status.warning"、"status.danger"。
- tokens.font_size：5-8 条，T 恤尺码制（xs/sm/base/md/lg/xl/2xl/3xl）或语义（body/h1/h2/display）。可见时附 line_height。
- tokens.spacing：6-10 条，保持一致比率（xs=4px、sm=8px、md=16px、lg=24px、xl=32px、2xl=48px、3xl=64px），按实际节奏微调。
- tokens.radius：3-6 条（none=0、sm、md、lg、xl、full=9999px）。
- tokens.shadow：2-5 条（sm、md、lg、xl），必须是合法 CSS shadow 值。
- 所有十六进制颜色用 #RGB / #RRGGBB / #RRGGBBAA 格式。

完整示例（蓝色品牌 + 暖调点缀的落地页）：
{
  "layout": "12 栅格居中 hero、分栏 CTA、三卡特性区、客户证言条",
  "typography": {
    "heading": "几何无衬线，紧字距，56-72px display",
    "body": "人文无衬线，16px，行高 1.6"
  },
  "colors": { "primary": "#0A84FF", "accents": ["#FF375F", "#30D158"] },
  "components": ["半透模糊吸顶导航", "主 CTA 按钮", "带图标的特性卡片"],
  "interactions": ["特性区滚动入场", "卡片悬浮抬起"],
  "tone": "自信、企业级、效率导向",
  "tokens": {
    "color": {
      "brand.primary":   { "value": "#0A84FF" },
      "brand.accent":    { "value": "#FF375F" },
      "text.body":       { "value": "#1D1D1F" },
      "text.muted":      { "value": "#6E6E73" },
      "bg.canvas":       { "value": "#FFFFFF" },
      "bg.surface":      { "value": "#F5F5F7" },
      "border.subtle":   { "value": "#E5E5EA" },
      "status.positive": { "value": "#30D158" }
    },
    "font_size": {
      "xs":      { "value": "12px", "line_height": "1.4" },
      "sm":      { "value": "14px", "line_height": "1.5" },
      "base":    { "value": "16px", "line_height": "1.6" },
      "lg":      { "value": "20px", "line_height": "1.5" },
      "xl":      { "value": "28px", "line_height": "1.3" },
      "display": { "value": "56px", "line_height": "1.1" }
    },
    "spacing": { "xs": "4px", "sm": "8px", "md": "16px", "lg": "24px", "xl": "32px", "2xl": "48px", "3xl": "64px" },
    "radius":  { "none": "0", "sm": "4px", "md": "8px", "lg": "16px", "full": "9999px" },
    "shadow":  {
      "sm": "0 1px 2px rgba(0,0,0,0.06)",
      "md": "0 4px 12px rgba(0,0,0,0.08)",
      "lg": "0 12px 32px rgba(0,0,0,0.12)"
    }
  }
}`;function ee(e){const{mode:r,language:t}=e,o=t==="zh";switch(r){case"image_to_prompt":return o?Y:z;case"product_style":return o?Z:V;case"webpage_style":return o?X:Q}}const te={image_to_prompt:G,product_style:B,webpage_style:M};class R extends Error{constructor(r="Unauthorized (401). Check your API key."){super(r),this.name="AuthError"}}class C extends Error{constructor(r="Rate limited (429). Please retry later."){super(r),this.name="RateLimitError"}}class x extends Error{constructor(r){super(r),this.name="NetworkError"}}class F extends Error{constructor(r="Model response did not match expected schema."){super(r),this.name="SchemaError"}}const _="Produce a JSON response per the schema.",ae=e=>`Your previous response failed schema validation for mode '${e}'. Return strictly valid JSON matching the schema.`;async function re(e,r){const t=ee({mode:e,language:r.language}),o=te[e],a=await k(r,t,_),s=S(a,o);if(s.ok)return s.value;const i=await k(r,t,_,{priorRaw:a,correctiveSystem:ae(e)}),c=S(i,o);if(c.ok)return c.value;throw new F(c.error)}async function k(e,r,t,o){const a=e.provider??"openai",s=T(a),{url:i,init:c}=s.buildRequest({baseURL:e.baseURL,apiKey:e.apiKey,model:e.model,systemPrompt:r,userText:t,imageBase64:e.imageBase64,mime:e.mime??"image/jpeg",signal:e.signal,temperature:.4,maxTokens:800,retry:o});let n;try{n=await fetch(i,c)}catch(l){throw l instanceof Error&&l.name==="AbortError"?l:new x(l instanceof Error?l.message:String(l))}const m=s.classifyStatus(n.status);if(m==="auth")throw new R;if(m==="rate")throw new C;if(m!=="ok"){const l=await n.text().catch(()=>"");throw new x(`HTTP ${n.status}: ${l||n.statusText}`)}let f;try{f=await n.json()}catch(l){throw new x(`Failed to read response: ${l instanceof Error?l.message:String(l)}`)}const w=s.extractContent(f);if(!w)throw new x("Empty response content from API.");return w}function S(e,r){let t;try{t=JSON.parse(e)}catch(a){return{ok:!1,error:`Invalid JSON: ${a instanceof Error?a.message:String(a)}`}}const o=r.safeParse(t);return o.success?{ok:!0,value:o.data}:{ok:!1,error:o.error.issues[0]?.message??"schema mismatch"}}function oe(e){const r=e.indexOf(",");return r<0?e:e.slice(r+1)}async function se(e){if(typeof FileReader<"u")try{return await new Promise((i,c)=>{const n=new FileReader;n.onload=()=>{const m=n.result;if(typeof m!="string"){c(new Error("FileReader did not return string"));return}i(oe(m))},n.onerror=()=>c(n.error??new Error("FileReader failed")),n.readAsDataURL(e)})}catch{}const t=await ie(e),o=new Uint8Array(t);let a="";const s=32768;for(let i=0;i<o.length;i+=s)a+=String.fromCharCode(...o.subarray(i,i+s));return btoa(a)}function ie(e){const r=e;return typeof r.arrayBuffer=="function"?r.arrayBuffer():new Promise((t,o)=>{const a=new FileReader;a.onload=()=>t(a.result),a.onerror=()=>o(a.error??new Error("FileReader failed")),a.readAsArrayBuffer(e)})}const ne=1280,le=.85;async function ce(e,r,t){const a=await(await fetch(e)).blob(),s=await createImageBitmap(a),i=Math.max(1,Math.round(r.w*t)),c=Math.max(1,Math.round(r.h*t)),n=Math.min(1,ne/Math.max(i,c)),m=Math.max(1,Math.round(i*n)),f=Math.max(1,Math.round(c*n)),w=new OffscreenCanvas(m,f),l=w.getContext("2d");if(!l)throw new Error("Failed to acquire 2d context on OffscreenCanvas.");l.drawImage(s,r.x*t,r.y*t,i,c,0,0,m,f),s.close?.();const g=await w.convertToBlob({type:"image/jpeg",quality:le});return{base64:await se(g),blob:g,mime:"image/jpeg"}}chrome.runtime.onInstalled.addListener(()=>{console.log("[img2prompt] installed")});chrome.action.onClicked.addListener(async e=>{if(!(!e?.id||!e.url)){if(O(e.url)){await h(e.id,"RESTRICTED_PAGE","此页面浏览器不允许扩展操作，换一个普通网页即可。");return}try{await chrome.tabs.sendMessage(e.id,{type:d.PANEL_OPEN})}catch(r){await h(e.id,"RESTRICTED_PAGE",`Content script 未加载，请刷新页面。${u(r)}`)}}});chrome.commands.onCommand.addListener(async e=>{if(e==="start-selection")try{await N()}catch(r){console.error("[img2prompt] start-selection failed",r),await h(null,"UNKNOWN",u(r))}});chrome.runtime.onMessage.addListener((e,r,t)=>{const o=e;if(!o||typeof o!="object")return!1;if(o.type===d.SELECTION_COMPLETE){const a=r.tab?.id??null;return pe(e,a).catch(async s=>{console.error("[img2prompt] selection handler failed",s),await h(a,"UNKNOWN",u(s))}),t({ack:!0}),!1}if(o.type===d.SELECTION_CANCEL)return t({ack:!0}),!1;if(o.type===d.RPC_START_SELECTION)return N().then(()=>t({ok:!0})).catch(a=>t({ok:!1,error:u(a)})),!0;if(o.type===d.RPC_HISTORY_LIST)return(async()=>{try{const s=(await J(100)).map(i=>({id:i.id,createdAt:i.createdAt,pageUrl:i.pageUrl,mode:i.mode,insight:i.insight}));t({ok:!0,entries:s})}catch(a){t({ok:!1,error:u(a)})}})(),!0;if(o.type===d.RPC_HISTORY_THUMB){const a=e.id;return(async()=>{try{if(!a)throw new Error("Missing id");const s=await q(a);if(!s){t({ok:!1,error:"not found"});return}const i=await de(s.thumbnailBlob);t({ok:!0,thumbnailB64:i})}catch(s){t({ok:!1,error:u(s)})}})(),!0}if(o.type===d.RPC_HISTORY_DELETE){const a=e.id;return(async()=>{try{if(!a)throw new Error("Missing id");await H(a),t({ok:!0})}catch(s){t({ok:!1,error:u(s)})}})(),!0}if(o.type===d.RPC_HISTORY_CLEAR)return(async()=>{try{await K(),t({ok:!0})}catch(a){t({ok:!1,error:u(a)})}})(),!0;if(o.type===d.RPC_TEST_CONNECTION){const a=e.config;return(async()=>{try{if(!a)throw new Error("Missing config");const s=W(a.provider)?a.provider:"openai",i=T(s),c="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNgAAIAAAUAAen63NgAAAAASUVORK5CYII=",{url:n,init:m}=i.buildRequest({baseURL:a.baseURL,apiKey:a.apiKey,model:a.model,systemPrompt:"ping",userText:"ping",imageBase64:c,mime:"image/png",temperature:0,maxTokens:1}),f=await fetch(n,m);t({ok:f.ok,status:f.status})}catch(s){t({ok:!1,error:u(s)})}})(),!0}return!1});async function N(){const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e?.id||!e.url){await h(null,"RESTRICTED_PAGE","No active tab available.");return}if(O(e.url)){await h(e.id,"RESTRICTED_PAGE","此页面浏览器不允许扩展截图，换一个普通网页即可。");return}try{await chrome.tabs.sendMessage(e.id,{type:d.START_SELECTION})}catch(r){await h(e.id,"RESTRICTED_PAGE",`Content script 未加载，请刷新页面。${u(r)}`)}}async function y(e,r,t,o,a,s){a.current+=1;const i={type:d.LOADING,seq:a.current,startedAt:o,step:t,elapsedMs:Date.now()-o,mode:r,...s??{}};console.log("[progress]",t,`${i.elapsedMs}ms`,s??""),await E(e,i),await A(i)}async function pe(e,r){const t=Date.now(),o={current:0},a=e.mode,s=U(a)?a:(console.warn("[img2prompt] unknown mode, falling back",a),P);let i;const[c]=await chrome.tabs.query({active:!0,currentWindow:!0}),n=r??c?.id??null;if(console.log("[img2prompt] selection received",{tabId:n,rect:e.rect,mode:s}),!c?.windowId){await h(n,"CAPTURE_FAILED","No active window to capture.");return}const m=chrome.tabs.captureVisibleTab(c.windowId,{format:"jpeg",quality:88}).catch(p=>{throw console.error("[img2prompt] captureVisibleTab FAILED",p),p}),f=j();let w;try{w=await m}catch(p){await y(n,s,"failed",t,o,{failedAt:i,errorCode:"CAPTURE_FAILED"}),await h(n,"CAPTURE_FAILED",`captureVisibleTab failed: ${u(p)}`);return}await y(n,s,"captured",t,o),i="captured";let l;try{l=await ce(w,e.rect,e.dpr)}catch(p){console.error("[img2prompt] crop FAILED",p),await y(n,s,"failed",t,o,{failedAt:i,errorCode:"CAPTURE_FAILED"}),await h(n,"CAPTURE_FAILED",`Crop failed: ${u(p)}`);return}await y(n,s,"cropped",t,o),i="cropped";const g=await f;if(!g.apiKey&&g.provider!=="ollama"){console.warn("[img2prompt] no api key configured"),await y(n,s,"failed",t,o,{failedAt:i,errorCode:"NO_CONFIG"}),await h(n,"NO_CONFIG","API key 尚未配置，请打开设置填写。");return}await y(n,s,"inferring",t,o),i="inferring";try{const p=Date.now(),b=await re(s,{provider:g.provider,baseURL:g.baseURL,apiKey:g.apiKey,model:g.model,language:g.language,imageBase64:l.base64,mime:l.mime});console.log("[img2prompt] vision ok",`${Date.now()-p}ms`),await y(n,s,"parsing",t,o),i="parsing";const v={thumbnailB64:l.base64,mode:s,insight:b,pageUrl:e.pageUrl,createdAt:Date.now()};try{await $({id:me(),createdAt:v.createdAt,thumbnailBlob:l.blob,pageUrl:e.pageUrl,mode:s,insight:b},g.maxHistory)}catch(D){console.warn("[img2prompt] history write failed",D)}const I={type:d.RESULT,payload:v};await A(v),await y(n,s,"done",t,o),await E(n,I),console.log("[img2prompt] RESULT sent to tab",n,`total ${Date.now()-t}ms`)}catch(p){const b=ue(p);console.error("[img2prompt] vision FAILED",b,p),await y(n,s,"failed",t,o,{failedAt:i,errorCode:b}),await h(n,b,u(p))}}async function E(e,r){if(e==null){console.warn("[img2prompt] sendToTab: no tabId",r.type);return}try{await chrome.tabs.sendMessage(e,r)}catch(t){console.warn("[img2prompt] sendToTab failed",r.type,e,u(t))}}async function A(e){try{await chrome.storage.session.set({[L]:e})}catch{}}function ue(e){return e instanceof R?"UNAUTHORIZED":e instanceof C?"RATE_LIMITED":e instanceof F?"INVALID_RESPONSE":e instanceof x?"NETWORK_ERROR":e instanceof Error&&e.name==="AbortError"?"TIMEOUT":"UNKNOWN"}async function h(e,r,t){const o={type:d.ERROR,code:r,message:t};await A(o),await E(e,o)}function O(e){return e.startsWith("chrome://")||e.startsWith("chrome-extension://")||e.startsWith("edge://")||e.startsWith("about:")||e.startsWith("view-source:")||e.startsWith("https://chrome.google.com/webstore")||e.startsWith("https://chromewebstore.google.com")}function u(e){return e instanceof Error?e.message:String(e)}function me(){return typeof crypto<"u"&&"randomUUID"in crypto?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2)}`}async function de(e){const r=await e.arrayBuffer();let t="";const o=new Uint8Array(r);for(let a=0;a<o.length;a++)t+=String.fromCharCode(o[a]);return btoa(t)}export{pe as handleSelectionComplete,y as reportStep};
