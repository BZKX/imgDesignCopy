import{j as e,r as c,c as ke}from"./client-CNRN5RT9.js";import{M as B,a as v,D as ve,i as we,b as De}from"./messages-Ceg1ccJ7.js";import{D as He,l as Ne,C as ce,P as H,a as Ue,s as de}from"./config-C44AtlOB.js";function pe(t,r,n,s){const a=Math.min(t,n),i=Math.min(r,s),o=Math.abs(n-t),h=Math.abs(s-r);return{x:a,y:i,w:o,h}}function he(t,r,n){const s=Math.max(0,Math.min(t.x,r)),a=Math.max(0,Math.min(t.y,n)),i=Math.max(0,Math.min(t.w,r-s)),o=Math.max(0,Math.min(t.h,n-a));return{x:s,y:a,w:i,h:o}}function Fe(t,r=4){return t.w<r||t.h<r}function U({children:t}){return e.jsx("kbd",{className:"kbd",children:t})}function Be(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.75",strokeLinecap:"round",children:e.jsx("path",{d:"M3 3l10 10M13 3L3 13"})})}function Ke(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[e.jsx("circle",{cx:"8",cy:"8",r:"2"}),e.jsx("path",{d:"M8 1.5v2M8 12.5v2M14.5 8h-2M3.5 8h-2M12.6 3.4l-1.4 1.4M4.8 11.2l-1.4 1.4M12.6 12.6l-1.4-1.4M4.8 4.8L3.4 3.4",strokeLinecap:"round"})]})}function We(){return e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",style:{width:20,height:20},children:[e.jsx("path",{d:"M12 8v5M12 16.5v.01"}),e.jsx("circle",{cx:"12",cy:"12",r:"9.5"})]})}function Ye(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M10 3L5 8l5 5"})})}function ze(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("path",{d:"M2.8 7.5a5.3 5.3 0 11.7 3"}),e.jsx("path",{d:"M1.5 10.6l2 .1.1-2"}),e.jsx("path",{d:"M8 5.2v3.1l2 1.2"})]})}function Ge(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",children:[e.jsx("circle",{cx:"8",cy:"8",r:"2.8"}),e.jsx("path",{d:"M8 1.5v1.8M8 12.7v1.8M14.5 8h-1.8M3.3 8H1.5M12.6 3.4l-1.3 1.3M4.7 11.3l-1.3 1.3M12.6 12.6l-1.3-1.3M4.7 4.7L3.4 3.4"})]})}function Ve(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M13.2 9.4A5.5 5.5 0 016.6 2.8a5.5 5.5 0 106.6 6.6z"})})}function qe(){return e.jsx("svg",{viewBox:"0 0 1024 1024",fill:"currentColor","aria-hidden":!0,children:e.jsx("path",{d:"M512 170.666667a341.333333 341.333333 0 1 1 0 682.666666c-55.722667 0-21.930667-39.552-83.925333-103.253333C368.170667 688.64 170.666667 725.12 170.666667 512a341.333333 341.333333 0 0 1 341.333333-341.333333z m74.666667 413.866666a64 64 0 1 0 0 128 64 64 0 0 0 0-128z m117.333333-136.533333a42.666667 42.666667 0 1 0 0 85.333333 42.666667 42.666667 0 0 0 0-85.333333zM640 341.333333a42.666667 42.666667 0 1 0 0 85.333334 42.666667 42.666667 0 0 0 0-85.333334z m-245.333333-12.8a42.666667 42.666667 0 1 0 0 85.333334 42.666667 42.666667 0 0 0 0-85.333334z m128-40.533333a42.666667 42.666667 0 1 0 0 85.333333 42.666667 42.666667 0 0 0 0-85.333333z"})})}function Xe(){return e.jsxs("svg",{viewBox:"0 0 1024 1024",fill:"currentColor","aria-hidden":!0,children:[e.jsx("path",{d:"M832 736l-249.6 153.6c-19.2 12.8-38.4 0-38.4-25.6L544 505.6c0-6.4 6.4-19.2 12.8-25.6l249.6-153.6c19.2-12.8 38.4 0 38.4 25.6l0 364.8C844.8 723.2 838.4 736 832 736z"}),e.jsx("path",{d:"M192 736l249.6 153.6c19.2 12.8 38.4 0 38.4-25.6L480 505.6c0-6.4-6.4-19.2-12.8-25.6L217.6 326.4C204.8 320 179.2 332.8 179.2 352l0 364.8C179.2 723.2 185.6 736 192 736z"}),e.jsx("path",{d:"M505.6 128 217.6 236.8c-12.8 6.4-12.8 25.6 0 32L505.6 448C512 448 518.4 448 518.4 448l294.4-179.2c12.8-6.4 12.8-25.6 0-32L518.4 128C512 128 512 128 505.6 128z"})]})}function Je(){return e.jsx("svg",{viewBox:"0 0 1024 1024",fill:"currentColor","aria-hidden":!0,children:e.jsx("path",{d:"M853.333333 170.666667 170.666667 170.666667C123.733333 170.666667 85.333333 209.066667 85.333333 256l0 512c0 46.933333 38.4 85.333333 85.333333 85.333333l682.666667 0c46.933333 0 85.333333-38.4 85.333333-85.333333L938.666667 256C938.666667 209.066667 900.266667 170.666667 853.333333 170.666667zM640 768 170.666667 768l0-170.666667 469.333333 0L640 768zM640 554.666667 170.666667 554.666667 170.666667 384l469.333333 0L640 554.666667zM853.333333 768l-170.666667 0L682.666667 384l170.666667 0L853.333333 768z"})})}function q({mode:t}){return t==="product_style"?e.jsx(Xe,{}):t==="webpage_style"?e.jsx(Je,{}):e.jsx(qe,{})}function Q(){return e.jsxs("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round",style:{width:14,height:14},children:[e.jsx("circle",{cx:"4",cy:"5",r:"1.75"}),e.jsx("circle",{cx:"4",cy:"11",r:"1.75"}),e.jsx("path",{d:"M5.5 6.2L14 13M5.5 9.8L14 3"})]})}const Ze={"common.cancel":{zh:"取消",en:"Cancel"},"common.confirm":{zh:"确认",en:"Confirm"},"common.copied":{zh:"已复制",en:"Copied"},"common.copy":{zh:"Copy",en:"Copy"},"common.delete":{zh:"删除",en:"Delete"},"error.hint.CAPTURE_FAILED":{zh:"截图失败",en:"Screenshot failed"},"error.hint.INVALID_RESPONSE":{zh:"模型返回格式异常",en:"Invalid model response"},"error.hint.NETWORK_ERROR":{zh:"网络请求失败",en:"Network request failed"},"error.hint.NO_CONFIG":{zh:"请先配置 API",en:"Please configure the API first"},"error.hint.RATE_LIMITED":{zh:"触发限流，请稍后再试",en:"Rate limited, please retry later"},"error.hint.RESTRICTED_PAGE":{zh:"该页面受浏览器限制",en:"This page is restricted by the browser"},"error.hint.TIMEOUT":{zh:"请求超时",en:"Request timed out"},"error.hint.UNAUTHORIZED":{zh:"API Key 无效",en:"Invalid API Key"},"error.hint.UNKNOWN":{zh:"出现未知错误",en:"An unknown error occurred"},"error.retry":{zh:"重试",en:"Retry"},"error.openSettings":{zh:"打开设置",en:"Open Settings"},"error.stale":{zh:"PromptLens 已更新，请刷新页面后重试",en:"PromptLens was updated — please refresh the page and retry"},"header.back":{zh:"返回",en:"Back"},"header.close":{zh:"关闭",en:"Close"},"header.history":{zh:"历史",en:"History"},"header.theme.dark":{zh:"切换为深色",en:"Switch to dark mode"},"header.theme.light":{zh:"切换为浅色",en:"Switch to light mode"},"header.title.error":{zh:"出错了",en:"Something went wrong"},"header.title.history":{zh:"历史记录",en:"History"},"header.title.historyDetail":{zh:"历史详情",en:"History Detail"},"header.title.loading":{zh:"识别中",en:"Analyzing"},"header.title.result":{zh:"识别结果",en:"Result"},"header.title.settings":{zh:"设置",en:"Settings"},"history.confirmClearDetail":{zh:"确认删除",en:"Confirm delete"},"history.confirmClearPrompt":{zh:"确定清空全部历史？",en:"Clear all history?"},"history.clear":{zh:"清空",en:"Clear"},"history.count":{zh:"条",en:"items"},"history.empty.desc":{zh:"按 ⌘⇧Y 开始第一次识别",en:"Press ⌘⇧Y to start your first capture"},"history.empty.title":{zh:"还没有记录",en:"No history yet"},"history.source":{zh:"来源",en:"Source"},"launcher.capture":{zh:"开始截图",en:"Start Capture"},"launcher.mode.aria":{zh:"识别模式",en:"Recognition mode"},"launcher.noApiWarning":{zh:"尚未配置 API，点「设置」填写后即可使用。",en:"API not configured yet. Open Settings to fill it in."},"launcher.shortcut.hint":{zh:"全局快捷键",en:"Global shortcut"},"launcher.tile.history.desc":{zh:"浏览过往识别结果",en:"Browse past results"},"launcher.tile.history.label":{zh:"历史记录",en:"History"},"launcher.tile.settings.desc":{zh:"API、模型与偏好",en:"API, model, and preferences"},"launcher.tile.settings.label":{zh:"设置",en:"Settings"},"overlay.hint.element":{zh:"移动鼠标高亮元素，点击确认",en:"Hover to highlight an element, click to confirm"},"overlay.hint.rect":{zh:"拖动选择任意区域",en:"Drag to select any region"},"overlay.hint.switch":{zh:"切换模式",en:"Switch mode"},"overlay.hint.cancel":{zh:"取消",en:"Cancel"},"overlay.mode.element":{zh:"元素",en:"Element"},"overlay.mode.rect":{zh:"框选",en:"Region"},"prompt.copyAll":{zh:"Copy 全部",en:"Copy all"},"prompt.copyAllTags":{zh:"Copy all tags",en:"Copy all tags"},"prompt.copyPositive":{zh:"仅 Positive",en:"Positive only"},"prompt.naturalLanguage":{zh:"自然语言描述",en:"Natural language description"},"prompt.sd.collapseNegWeights":{zh:"收起 negative / weights",en:"Hide negative / weights"},"prompt.sd.expandNegWeights":{zh:"展开 negative / weights",en:"Show negative / weights"},"prompt.section.collapse":{zh:"收起",en:"Hide"},"prompt.section.expand":{zh:"展开",en:"Show"},"prompt.structuredTags":{zh:"结构化标签",en:"Structured tags"},"prompt.flux.fallback":{zh:"已使用 DALL·E 回退 — 重新运行以获得 Flux 优化输出",en:"Auto-filled from DALL·E — re-run for Flux-optimized output"},"renderer.product.cmf":{zh:"CMF",en:"CMF"},"renderer.product.cmf.colors":{zh:"色",en:"Colors"},"renderer.product.cmf.finishes":{zh:"饰",en:"Finishes"},"renderer.product.cmf.materials":{zh:"材",en:"Materials"},"renderer.product.composition":{zh:"构图",en:"Composition"},"renderer.product.copyShotList":{zh:"复制清单",en:"Copy list"},"renderer.product.lens":{zh:"镜头",en:"Lens"},"renderer.product.lens.angle":{zh:"角度",en:"Angle"},"renderer.product.lens.depth":{zh:"景深",en:"Depth of field"},"renderer.product.lens.focal":{zh:"焦段",en:"Focal length"},"renderer.product.lens.lens":{zh:"镜头",en:"Lens"},"renderer.product.lighting":{zh:"光线",en:"Lighting"},"renderer.product.lighting.ambient":{zh:"氛围",en:"Ambient"},"renderer.product.lighting.fill":{zh:"辅光",en:"Fill"},"renderer.product.lighting.key":{zh:"主光",en:"Key"},"renderer.product.lighting.overall":{zh:"光照",en:"Lighting"},"renderer.product.materials":{zh:"材质",en:"Materials"},"renderer.product.mood":{zh:"情绪",en:"Mood"},"renderer.product.palette":{zh:"配色",en:"Palette"},"renderer.product.prompt.hint":{zh:"可直接粘贴到图像生成器",en:"Paste directly into your image generator"},"renderer.product.prompt.title":{zh:"产品 Prompt",en:"Product Prompt"},"renderer.product.scene":{zh:"场景",en:"Scene"},"renderer.product.scene.props":{zh:"道具",en:"Props"},"renderer.product.scene.setting":{zh:"环境",en:"Setting"},"renderer.product.shotList.background":{zh:"背景",en:"Background"},"renderer.product.shotList.camera":{zh:"相机",en:"Camera"},"renderer.product.shotList.lighting":{zh:"光线",en:"Lighting"},"renderer.product.shotList.post":{zh:"后期",en:"Post"},"renderer.product.shotList.props":{zh:"道具",en:"Props"},"renderer.product.shotList.title":{zh:"复刻拍摄清单",en:"Shot list"},"renderer.product.tags":{zh:"标签",en:"Tags"},"renderer.web.colors":{zh:"配色",en:"Colors"},"renderer.web.components":{zh:"组件",en:"Components"},"renderer.web.interactions":{zh:"交互",en:"Interactions"},"renderer.web.layout":{zh:"布局",en:"Layout"},"renderer.web.export":{zh:"导出",en:"Export"},"renderer.web.skillHint":{zh:"保存为 skill.md，交给 AI 代理或设计工具作为可复用的设计参考",en:"Save as skill.md — feed into AI agents or design tools as a reusable design reference"},"renderer.web.tokens.figmaHint":{zh:"粘贴到 Figma 的 Tokens Studio 插件（Tools → Load from JSON）",en:"Paste into Figma's Tokens Studio plugin (Tools → Load from JSON)"},"renderer.web.tokens.overview":{zh:"设计参考 · 概览",en:"Design Reference · Overview"},"renderer.web.tone":{zh:"调性",en:"Tone"},"renderer.web.typography":{zh:"字体",en:"Typography"},"renderer.web.typography.body":{zh:"Body",en:"Body"},"renderer.web.typography.heading":{zh:"Heading",en:"Heading"},"result.home":{zh:"返回首页",en:"Back to Home"},"result.recapture":{zh:"再截一张",en:"New Capture"},"settings.api.baseUrl":{zh:"Base URL",en:"Base URL"},"settings.api.apiKey":{zh:"API Key",en:"API Key"},"settings.api.desc":{zh:"API Key 只保存在本地 chrome.storage.sync，仅发送到你配置的 Base URL。",en:"The API Key is stored locally in chrome.storage.sync and only sent to the Base URL you configured."},"settings.api.hide":{zh:"隐藏",en:"Hide"},"settings.api.model":{zh:"Model",en:"Model"},"settings.api.provider":{zh:"Provider",en:"Provider"},"settings.api.show":{zh:"显示",en:"Show"},"settings.api.title":{zh:"API 连接",en:"API Connection"},"settings.language.model.helper":{zh:"控制模型回复使用的语言。",en:"Controls the language the model uses in its responses."},"settings.language.model.label":{zh:"模型输出语言",en:"Model Output Language"},"settings.language.ui.helper":{zh:"选择扩展界面显示的语言。",en:"Choose the language for the extension's interface."},"settings.language.ui.label":{zh:"显示语言",en:"Display Language"},"settings.lang.en":{zh:"English",en:"English"},"settings.lang.zh":{zh:"中文",en:"Chinese"},"settings.pref.maxHistory":{zh:"历史记录数量（10–500）",en:"History size (10–500)"},"settings.pref.title":{zh:"偏好",en:"Preferences"},"settings.save.saved":{zh:"已保存",en:"Saved"},"settings.save.saving":{zh:"保存中…",en:"Saving…"},"settings.save.save":{zh:"保存",en:"Save"},"settings.test":{zh:"测试连接",en:"Test Connection"},"settings.test.failed":{zh:"失败",en:"Failed"},"settings.test.ok":{zh:"连接成功",en:"Connected"},"settings.test.testing":{zh:"测试中…",en:"Testing…"},"stepper.active.captured":{zh:"正在截图…",en:"Capturing…"},"stepper.active.cropped":{zh:"正在压缩上传…",en:"Compressing…"},"stepper.active.done":{zh:"完成",en:"Done"},"stepper.active.inferring":{zh:"正在识别风格…",en:"Analyzing…"},"stepper.active.parsing":{zh:"正在解析结构…",en:"Parsing…"},"stepper.label.captured":{zh:"截图",en:"Capture"},"stepper.label.cropped":{zh:"压缩上传",en:"Compress"},"stepper.label.done":{zh:"完成",en:"Done"},"stepper.label.inferring":{zh:"风格识别",en:"Analyze"},"stepper.label.parsing":{zh:"结构解析",en:"Parse"},"stepper.loading":{zh:"loading…",en:"loading…"}};function z(t,r){const n=Ze[t];return n?n[r]:t}const Z="img2prompt.config";function Ce(t){const n=t?.[Z]?.uiLanguage;return n==="zh"||n==="en"?n:null}function Qe(){const[t,r]=c.useState("zh");return c.useEffect(()=>{try{chrome.storage?.sync?.get(Z).then(s=>{const a=Ce(s);a&&r(a)}).catch(()=>{})}catch{}const n=(s,a)=>{if(a!=="sync")return;const i=s[Z];if(!i)return;const o=i.newValue?.uiLanguage;(o==="zh"||o==="en")&&r(o)};try{chrome.storage?.onChanged?.addListener(n)}catch{}return()=>{try{chrome.storage?.onChanged?.removeListener(n)}catch{}}},[]),t}const Se=c.createContext({lang:"zh",t:t=>z(t,"zh")});function et({lang:t,children:r}){const n={lang:t,t:s=>z(s,t)};return c.createElement(Se.Provider,{value:n},r)}function f(){return c.useContext(Se)}async function tt(){try{const t=await chrome.storage.sync.get(Z);return Ce(t)??"zh"}catch{return"zh"}}function rt({onComplete:t,onCancel:r,excludeHost:n,mode:s,lang:a="zh"}){const i=a==="en"?B[s].displayName.en:B[s].displayName["zh-CN"],[o,h]=c.useState("element"),[l,u]=c.useState(null),[y,g]=c.useState(null),[x,T]=c.useState(null),[_,N]=c.useState(""),S=c.useRef(null);c.useEffect(()=>{const m=b=>{b.key==="Escape"&&(b.preventDefault(),b.stopPropagation(),r()),(b.key==="e"||b.key==="E")&&(b.preventDefault(),h(E=>E==="rect"?"element":"rect"),u(null),g(null),T(null))};return window.addEventListener("keydown",m,!0),()=>window.removeEventListener("keydown",m,!0)},[r]);const w=m=>{o==="rect"&&m.button===0&&(u({x:m.clientX,y:m.clientY}),g({x:m.clientX,y:m.clientY}))},O=m=>{if(o==="rect"){if(!l)return;g({x:m.clientX,y:m.clientY});return}const E=document.elementsFromPoint(m.clientX,m.clientY).find(d=>!(!d||n&&(d===n||n.contains(d))||d===document.documentElement||d===document.body));if(!E){T(null);return}const M=E.getBoundingClientRect();if(M.width<4||M.height<4){T(null);return}T({x:Math.max(0,Math.floor(M.left)),y:Math.max(0,Math.floor(M.top)),w:Math.min(window.innerWidth-Math.max(0,Math.floor(M.left)),Math.ceil(M.width)),h:Math.min(window.innerHeight-Math.max(0,Math.floor(M.top)),Math.ceil(M.height))}),N(nt(E))},A=m=>{if(o!=="rect"||!l)return;const b=pe(l.x,l.y,m.clientX,m.clientY),E=he(b,window.innerWidth,window.innerHeight);if(u(null),g(null),Fe(E)){r();return}t(E)},k=m=>{o==="element"&&x&&(m.preventDefault(),m.stopPropagation(),t(x))},p=o==="rect"?l&&y?he(pe(l.x,l.y,y.x,y.y),window.innerWidth,window.innerHeight):null:x;return e.jsxs("div",{ref:S,onMouseDown:w,onMouseMove:O,onMouseUp:A,onClick:k,className:`overlay-root ${o==="element"?"mode-element":"mode-rect"}`,children:[p?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"overlay-rect",style:{left:p.x,top:p.y,width:p.w,height:p.h}}),e.jsx("div",{className:"overlay-dim-mask",style:{clipPath:`polygon(
                0 0, 100% 0, 100% 100%, 0 100%, 0 0,
                ${p.x}px ${p.y}px,
                ${p.x}px ${p.y+p.h}px,
                ${p.x+p.w}px ${p.y+p.h}px,
                ${p.x+p.w}px ${p.y}px,
                ${p.x}px ${p.y}px
              )`}}),e.jsx("div",{className:"overlay-badge",style:{left:Math.min(p.x+p.w-100,window.innerWidth-110),top:Math.min(p.y+p.h+10,window.innerHeight-32)},children:o==="element"&&_?`${_} · ${p.w} × ${p.h}`:`${p.w} × ${p.h}`})]}):e.jsx("div",{className:"overlay-dim-mask overlay-dim-full"}),e.jsxs("div",{className:"overlay-toolbar",onMouseDown:X,onMouseUp:X,onMouseMove:X,onClick:X,children:[e.jsxs("span",{className:"overlay-mode-badge",title:B[s].description,children:[e.jsx("span",{className:"overlay-mode-icon",children:e.jsx(q,{mode:s})}),i]}),e.jsxs("div",{className:"overlay-segment",role:"tablist",children:[e.jsxs("button",{type:"button",className:o==="element"?"active":"",onClick:m=>{m.stopPropagation(),h("element"),u(null),g(null)},children:[e.jsx(at,{})," ",z("overlay.mode.element",a)]}),e.jsxs("button",{type:"button",className:o==="rect"?"active":"",onClick:m=>{m.stopPropagation(),h("rect"),T(null)},children:[e.jsx(st,{})," ",z("overlay.mode.rect",a)]})]}),e.jsxs("div",{className:"overlay-hint",children:[z(o==="rect"?"overlay.hint.rect":"overlay.hint.element",a),e.jsx("span",{className:"overlay-hint-sep"}),e.jsx("kbd",{children:"E"})," ",z("overlay.hint.switch",a),e.jsx("span",{className:"overlay-hint-sep"}),e.jsx("kbd",{children:"Esc"})," ",z("overlay.hint.cancel",a)]})]})]})}function X(t){t.stopPropagation()}function nt(t){const r=t.tagName.toLowerCase(),n=t.id?`#${t.id}`:"",s=t.classList.length?"."+Array.from(t.classList).slice(0,2).join("."):"";return`${r}${n}${s}`.slice(0,48)}function st(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",style:{width:12,height:12},children:e.jsx("rect",{x:"2.5",y:"2.5",width:"11",height:"11",rx:"1.5",strokeDasharray:"2 1.5"})})}function at(){return e.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",style:{width:12,height:12},children:e.jsx("path",{d:"M3 3l4.5 10 1.7-4 4-1.7z"})})}const ot=`
:host, :root { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', 'Helvetica Neue', system-ui, sans-serif; letter-spacing: -0.003em; }
button { background: transparent; border: none; cursor: pointer; color: inherit; font: inherit; }

.overlay-root {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  user-select: none;
}
.mode-rect { cursor: crosshair; }
.mode-element { cursor: pointer; }
.overlay-dim-mask {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.42);
  pointer-events: none;
}
.overlay-dim-full { background: rgba(0, 0, 0, 0.28); }
.overlay-rect {
  position: absolute;
  border: 1.5px solid #ffffff;
  border-radius: 4px;
  box-shadow: 0 0 0 1px rgba(0,0,0,0.3), 0 8px 24px rgba(0,0,0,0.35);
  pointer-events: none;
  animation: overlay-rect-in 260ms cubic-bezier(0.16, 1, 0.3, 1);
  will-change: left, top, width, height;
}
@keyframes overlay-rect-in {
  from { opacity: 0; transform: scale(0.96); }
  to   { opacity: 1; transform: scale(1); }
}
.mode-element .overlay-rect,
.mode-element .overlay-dim-mask,
.mode-element .overlay-badge {
  transition:
    left 260ms cubic-bezier(0.16, 1, 0.3, 1),
    top 260ms cubic-bezier(0.16, 1, 0.3, 1),
    width 260ms cubic-bezier(0.16, 1, 0.3, 1),
    height 260ms cubic-bezier(0.16, 1, 0.3, 1),
    clip-path 260ms cubic-bezier(0.16, 1, 0.3, 1),
    -webkit-clip-path 260ms cubic-bezier(0.16, 1, 0.3, 1);
}
.mode-element .overlay-badge {
  transition-duration: 200ms;
  transition-property: opacity, transform, left, top;
  transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);
}
.overlay-badge {
  position: absolute;
  padding: 5px 12px;
  background: rgba(28, 28, 30, 0.85);
  -webkit-backdrop-filter: blur(16px) saturate(180%);
  backdrop-filter: blur(16px) saturate(180%);
  color: #ffffff;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  font-weight: 500;
  border-radius: 980px;
  letter-spacing: -0.005em;
  pointer-events: none;
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.overlay-toolbar {
  position: absolute;
  left: 50%;
  top: 28px;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 8px 6px 6px;
  background: rgba(28, 28, 30, 0.78);
  -webkit-backdrop-filter: blur(20px) saturate(180%);
  backdrop-filter: blur(20px) saturate(180%);
  color: #ffffff;
  border-radius: 980px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.25);
}
.overlay-mode-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  background: rgba(255,255,255,0.12);
  color: #ffffff;
  border-radius: 980px;
  font-size: 11.5px;
  font-weight: 500;
  letter-spacing: -0.005em;
}
.overlay-segment {
  display: flex;
  gap: 2px;
  padding: 2px;
  background: rgba(255,255,255,0.08);
  border-radius: 980px;
}
.overlay-segment button {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 12px;
  font-size: 12px;
  font-weight: 500;
  color: rgba(255,255,255,0.7);
  border-radius: 980px;
  transition: background 160ms ease, color 160ms ease;
}
.overlay-segment button:hover { color: #ffffff; }
.overlay-segment button.active {
  background: rgba(255,255,255,0.18);
  color: #ffffff;
}
.overlay-hint {
  font-size: 12px;
  color: rgba(255,255,255,0.85);
  display: flex;
  align-items: center;
  gap: 8px;
  padding-right: 8px;
}
.overlay-hint kbd {
  display: inline-block;
  background: rgba(255,255,255,0.16);
  padding: 2px 7px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
}
.overlay-hint-sep {
  width: 1px; height: 11px;
  background: rgba(255,255,255,0.25);
  display: inline-block;
}
`,ue=[{key:"captured",labelKey:"stepper.label.captured",activeKey:"stepper.active.captured"},{key:"cropped",labelKey:"stepper.label.cropped",activeKey:"stepper.active.cropped"},{key:"inferring",labelKey:"stepper.label.inferring",activeKey:"stepper.active.inferring"},{key:"parsing",labelKey:"stepper.label.parsing",activeKey:"stepper.active.parsing"},{key:"done",labelKey:"stepper.label.done",activeKey:"stepper.active.done"}],re={captured:0,cropped:1,inferring:2,parsing:3,done:4,failed:-1};function it({currentStep:t,failedAt:r,errorCode:n,lang:s="zh"}){const a=re[t],i=r?re[r]:-1;return e.jsx("div",{className:"stepper",role:"status","aria-live":"polite",children:ue.map((o,h)=>{const l=re[o.key],u=t==="failed"&&i===l,y=!u&&t!=="failed"&&l===a,g=!y&&!u&&(t==="failed"?l<i:l<a);let x="stepper-step";return y?x+=" stepper-step--current":g?x+=" stepper-step--done":u?x+=" stepper-step--failed":x+=" stepper-step--pending",e.jsxs("div",{className:x,children:[e.jsxs("div",{className:"stepper-rail",children:[e.jsx("span",{className:"stepper-dot","aria-hidden":!0}),h<ue.length-1&&e.jsx("span",{className:"stepper-line","aria-hidden":!0})]}),e.jsxs("div",{className:"stepper-body",children:[e.jsxs("div",{className:"stepper-label",children:[z(y?o.activeKey:o.labelKey,s),u&&n&&e.jsxs("span",{className:"stepper-error",children:[" · ",n]})]}),y&&t!=="done"&&e.jsx("div",{className:"stepper-elapsed",children:z("stepper.loading",s)})]})]},o.key)})})}const lt=[{key:"midjourney",label:"Midjourney"},{key:"stable_diffusion",label:"Stable Diffusion"},{key:"flux",label:"Flux"},{key:"dalle",label:"DALL·E"}];function Le({result:t}){const{t:r}=f(),[n,s]=c.useState("midjourney"),a=!t.flux?.prompt,i=t.flux?.prompt??t.dalle;return e.jsxs(e.Fragment,{children:[(t.style_summary||t.aspect_ratio)&&e.jsxs("div",{style:{display:"flex",alignItems:"center",flexWrap:"wrap",gap:8,marginBottom:10},children:[t.style_summary&&e.jsx("span",{className:"hero-eyebrow",style:{marginBottom:0,lineHeight:1.4},children:t.style_summary}),t.aspect_ratio&&e.jsxs("span",{className:"renderer-chip renderer-chip--accent",style:{lineHeight:1.4},children:["📐 ",t.aspect_ratio]})]}),e.jsx("div",{className:"segment",role:"tablist",children:lt.map(o=>e.jsx("button",{type:"button",role:"tab","aria-selected":n===o.key,className:n===o.key?"active":"",onClick:()=>s(o.key),children:o.label},o.key))}),n==="midjourney"&&e.jsx(ne,{label:"Midjourney prompt",text:t.midjourney}),n==="stable_diffusion"&&e.jsx(ct,{sd:t.stable_diffusion}),n==="flux"&&e.jsx(ne,{label:"Flux prompt",text:i,hint:a?r("prompt.flux.fallback"):void 0}),n==="dalle"&&e.jsx(ne,{label:"DALL·E / GPT-4o prompt",text:t.dalle}),t.natural_language&&e.jsx(me,{title:r("prompt.naturalLanguage"),defaultOpen:!1,children:e.jsx(dt,{text:t.natural_language})}),t.tags&&t.tags.length>0&&e.jsx(me,{title:r("prompt.structuredTags"),defaultOpen:!1,children:e.jsx(pt,{tags:t.tags})})]})}function ne({label:t,text:r,hint:n}){const{t:s}=f(),[a,i]=c.useState(!1);async function o(){try{await navigator.clipboard.writeText(r),i(!0),setTimeout(()=>i(!1),1500)}catch{}}return e.jsxs("div",{className:"prompt-card",children:[e.jsx("div",{className:"prompt-card-label",children:t}),n&&e.jsx("div",{className:"sub-card-label",style:{marginBottom:6},children:n}),e.jsx("div",{className:"prompt-text",children:r}),e.jsxs("div",{className:"actions",children:[e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:o,children:[e.jsx(ee,{}),s("common.copy")]}),e.jsx("span",{className:`toast ${a?"visible":""}`,children:s("common.copied")})]})]})}function ct({sd:t}){const{t:r}=f(),[n,s]=c.useState(!1),[a,i]=c.useState(!1),o=`Positive: ${t.positive}`+(t.negative?`

Negative: ${t.negative}`:"")+(t.weights_explained?`

Weights: ${t.weights_explained}`:"");async function h(l){try{await navigator.clipboard.writeText(l),i(!0),setTimeout(()=>i(!1),1500)}catch{}}return e.jsxs("div",{className:"prompt-card",children:[e.jsx("div",{className:"prompt-card-label",children:"Stable Diffusion — Positive"}),e.jsx("div",{className:"prompt-text",children:t.positive}),e.jsxs("div",{className:"actions",children:[e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:()=>h(o),children:[e.jsx(ee,{}),r("prompt.copyAll")]}),e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:()=>h(t.positive),children:r("prompt.copyPositive")}),e.jsx("span",{className:`toast ${a?"visible":""}`,children:r("common.copied")})]}),(t.negative||t.weights_explained)&&e.jsx("button",{type:"button",className:"collapse-trigger",onClick:()=>s(l=>!l),"aria-expanded":n,children:r(n?"prompt.sd.collapseNegWeights":"prompt.sd.expandNegWeights")}),n&&e.jsxs(e.Fragment,{children:[t.negative&&e.jsxs("div",{className:"sub-card",children:[e.jsx("div",{className:"sub-card-label",children:"Negative"}),e.jsx("pre",{children:t.negative})]}),t.weights_explained&&e.jsxs("div",{className:"sub-card",children:[e.jsx("div",{className:"sub-card-label",children:"Weights"}),e.jsx("pre",{children:t.weights_explained})]})]})]})}function me({title:t,defaultOpen:r,children:n}){const{t:s}=f(),[a,i]=c.useState(!!r);return e.jsxs("div",{className:"prompt-card",style:{marginTop:10},children:[e.jsx("button",{type:"button",className:"collapse-trigger",onClick:()=>i(o=>!o),"aria-expanded":a,style:{marginTop:0},children:a?`${s("prompt.section.collapse")} ${t}`:`${s("prompt.section.expand")} ${t}`}),a&&e.jsx("div",{style:{marginTop:8},children:n})]})}function dt({text:t}){const{t:r}=f(),[n,s]=c.useState(!1);async function a(){try{await navigator.clipboard.writeText(t),s(!0),setTimeout(()=>s(!1),1500)}catch{}}return e.jsxs("div",{className:"sub-card",children:[e.jsx("pre",{style:{whiteSpace:"pre-wrap"},children:t}),e.jsxs("div",{className:"actions",style:{marginTop:8},children:[e.jsxs("button",{type:"button",className:"btn btn-secondary",onClick:a,children:[e.jsx(ee,{}),r("common.copy")]}),e.jsx("span",{className:`toast ${n?"visible":""}`,children:r("common.copied")})]})]})}function pt({tags:t}){const{t:r}=f(),[n,s]=c.useState(!1);async function a(){try{await navigator.clipboard.writeText(t.join(", ")),s(!0),setTimeout(()=>s(!1),1500)}catch{}}return e.jsxs("div",{className:"sub-card",children:[e.jsx("div",{className:"renderer-chips",children:t.map((i,o)=>e.jsx("span",{className:"renderer-chip",children:i},`${i}-${o}`))}),e.jsxs("div",{className:"actions",style:{marginTop:8},children:[e.jsxs("button",{type:"button",className:"btn btn-secondary",onClick:a,children:[e.jsx(ee,{}),r("prompt.copyAllTags")]}),e.jsx("span",{className:`toast ${n?"visible":""}`,children:r("common.copied")})]})]})}function ee(){return e.jsxs("svg",{viewBox:"0 0 14 14",fill:"none",stroke:"currentColor",strokeWidth:"1.5",style:{width:13,height:13},children:[e.jsx("rect",{x:"3.5",y:"3.5",width:"8",height:"9",rx:"1.5"}),e.jsx("path",{d:"M6 3.5V2.5a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-.5"})]})}function Te({result:t}){const{t:r}=f();return e.jsxs("div",{className:"renderer",children:[e.jsx(P,{title:r("renderer.product.palette"),children:e.jsx("div",{className:"renderer-palette",children:t.palette.map((n,s)=>e.jsx(mt,{color:n},`${n}-${s}`))})}),t.cmf?e.jsxs(P,{title:r("renderer.product.cmf"),children:[e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:r("renderer.product.cmf.colors")}),e.jsx(D,{items:t.cmf.colors})]}),e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:r("renderer.product.cmf.materials")}),e.jsx(D,{items:t.cmf.materials})]}),e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:r("renderer.product.cmf.finishes")}),e.jsx(D,{items:t.cmf.finishes})]})]}):e.jsx(P,{title:r("renderer.product.materials"),children:e.jsx(D,{items:t.materials})}),e.jsx(P,{title:r("renderer.product.lighting"),children:t.lighting_detail?e.jsxs(e.Fragment,{children:[e.jsx(R,{label:r("renderer.product.lighting.key"),value:t.lighting_detail.key}),e.jsx(R,{label:r("renderer.product.lighting.fill"),value:t.lighting_detail.fill}),e.jsx(R,{label:r("renderer.product.lighting.ambient"),value:t.lighting_detail.ambient})]}):e.jsx(R,{label:r("renderer.product.lighting.overall"),value:t.lighting})}),e.jsx(P,{title:r("renderer.product.lens"),children:t.lens?e.jsxs(e.Fragment,{children:[e.jsx(R,{label:r("renderer.product.lens.focal"),value:t.lens.focal_length}),e.jsx(R,{label:r("renderer.product.lens.angle"),value:t.lens.angle}),e.jsx(R,{label:r("renderer.product.lens.depth"),value:t.lens.depth_of_field})]}):e.jsx(R,{label:r("renderer.product.lens.lens"),value:t.camera})}),t.composition?e.jsx(P,{title:r("renderer.product.composition"),children:e.jsx("div",{className:"renderer-block",children:t.composition})}):null,t.scene?e.jsxs(P,{title:r("renderer.product.scene"),children:[e.jsx(R,{label:r("renderer.product.scene.setting"),value:t.scene.setting}),e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:r("renderer.product.scene.props")}),e.jsx(D,{items:t.scene.props})]})]}):null,e.jsx(P,{title:r("renderer.product.mood"),children:e.jsx(D,{items:t.mood,tone:"accent"})}),t.prompt&&(t.prompt.midjourney||t.prompt.natural_language)&&e.jsx(ht,{prompt:t.prompt}),t.shot_list?e.jsx(ut,{shotList:t.shot_list}):null,e.jsx(P,{title:r("renderer.product.tags"),children:e.jsx(D,{items:t.tags})})]})}function ht({prompt:t}){const{t:r}=f(),[n,s]=c.useState(!1),[a,i]=c.useState(!1);async function o(){try{await navigator.clipboard.writeText(t.midjourney??""),s(!0),setTimeout(()=>s(!1),1500)}catch{}}async function h(){try{await navigator.clipboard.writeText(t.natural_language??""),i(!0),setTimeout(()=>i(!1),1500)}catch{}}return e.jsxs("div",{className:"prompt-card renderer-section",style:{borderLeft:"3px solid var(--accent, #4f46e5)"},children:[e.jsxs("div",{className:"renderer-section-title",children:[e.jsx("span",{children:r("renderer.product.prompt.title")}),e.jsx("span",{className:"sub-card-label",style:{fontWeight:400,marginLeft:8},children:r("renderer.product.prompt.hint")})]}),t.midjourney&&e.jsxs("div",{className:"sub-card",style:{marginTop:8},children:[e.jsx("div",{className:"sub-card-label",children:"Midjourney"}),e.jsx("div",{className:"prompt-text",children:t.midjourney}),e.jsxs("div",{className:"actions",children:[e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:o,children:[e.jsx(ge,{}),r("common.copy")]}),e.jsx("span",{className:`toast ${n?"visible":""}`,children:r("common.copied")})]})]}),t.natural_language&&e.jsxs("div",{className:"sub-card",style:{marginTop:8},children:[e.jsx("div",{className:"sub-card-label",children:r("prompt.naturalLanguage")}),e.jsx("div",{className:"prompt-text",children:t.natural_language}),e.jsxs("div",{className:"actions",children:[e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:h,children:[e.jsx(ge,{}),r("common.copy")]}),e.jsx("span",{className:`toast ${a?"visible":""}`,children:r("common.copied")})]})]})]})}function ut({shotList:t}){const{t:r}=f(),[n,s]=c.useState(!1),a=[{key:"camera",labelKey:"renderer.product.shotList.camera"},{key:"lighting",labelKey:"renderer.product.shotList.lighting"},{key:"background",labelKey:"renderer.product.shotList.background"},{key:"props",labelKey:"renderer.product.shotList.props"},{key:"post",labelKey:"renderer.product.shotList.post"}];async function i(){const o=a.map(h=>`${r(h.labelKey)}：${t[h.key]}`).join(`
`);try{await navigator.clipboard.writeText(o),s(!0),setTimeout(()=>s(!1),1500)}catch{s(!1)}}return e.jsxs("div",{className:"prompt-card renderer-section",style:{borderLeft:"3px solid var(--accent, #4f46e5)"},children:[e.jsxs("div",{className:"renderer-section-title",style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[e.jsx("span",{children:r("renderer.product.shotList.title")}),e.jsx("button",{type:"button",className:"renderer-copy-btn",onClick:i,children:r(n?"common.copied":"renderer.product.copyShotList")})]}),a.map(o=>e.jsx(R,{label:r(o.labelKey),value:t[o.key]},o.key))]})}function P({title:t,children:r}){return e.jsxs("div",{className:"renderer-section",children:[e.jsx("div",{className:"renderer-section-title",children:t}),r]})}function D({items:t,tone:r}){return e.jsx("div",{className:"renderer-chips",children:t.map((n,s)=>e.jsx("span",{className:`renderer-chip${r?` renderer-chip--${r}`:""}`,children:n},`${n}-${s}`))})}function R({label:t,value:r}){return e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:t}),e.jsx("span",{className:"renderer-row-value",children:r})]})}function mt({color:t}){const r=/^#?[0-9a-fA-F]{3,8}$|^rgb|^hsl/.test(t)?t.startsWith("#")||t.startsWith("rgb")||t.startsWith("hsl")?t:`#${t}`:t;return e.jsxs("span",{className:"palette-swatch",title:t,children:[e.jsx("span",{className:"palette-chip",style:{background:r}}),e.jsx("span",{className:"palette-code",children:t})]})}function ge(){return e.jsxs("svg",{viewBox:"0 0 14 14",fill:"none",stroke:"currentColor",strokeWidth:"1.5",style:{width:13,height:13},children:[e.jsx("rect",{x:"3.5",y:"3.5",width:"8",height:"9",rx:"1.5"}),e.jsx("path",{d:"M6 3.5V2.5a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-.5"})]})}const gt=[{key:"skill",label:"Skill.md"},{key:"figma",label:"Figma"}];function Ee({result:t}){const{t:r}=f();return e.jsxs("div",{className:"renderer",children:[e.jsx(I,{title:r("renderer.web.layout"),children:e.jsx("div",{className:"renderer-block",children:t.layout})}),e.jsxs(I,{title:r("renderer.web.typography"),children:[e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:r("renderer.web.typography.heading")}),e.jsx("span",{className:"renderer-row-value",children:t.typography.heading})]}),e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:r("renderer.web.typography.body")}),e.jsx("span",{className:"renderer-row-value",children:t.typography.body})]})]}),e.jsx(I,{title:r("renderer.web.colors"),children:e.jsxs("div",{className:"renderer-palette",children:[e.jsx(be,{color:t.colors.primary,primary:!0}),t.colors.accents.map((n,s)=>e.jsx(be,{color:n},`${n}-${s}`))]})}),e.jsx(I,{title:r("renderer.web.components"),children:e.jsx(fe,{items:t.components})}),e.jsx(I,{title:r("renderer.web.interactions"),children:e.jsx(fe,{items:t.interactions,tone:"accent"})}),e.jsx(I,{title:r("renderer.web.tone"),children:e.jsx("div",{className:"renderer-block",children:t.tone})}),t.tokens&&Me(t.tokens)&&e.jsx(ft,{tokens:t.tokens}),e.jsx(I,{title:r("renderer.web.export"),children:e.jsx(bt,{result:t})})]})}function Me(t){return!!(t.color&&Object.keys(t.color).length||t.font_size&&Object.keys(t.font_size).length||t.spacing&&Object.keys(t.spacing).length||t.radius&&Object.keys(t.radius).length||t.shadow&&Object.keys(t.shadow).length)}function ft({tokens:t}){const{t:r}=f();return e.jsx(e.Fragment,{children:e.jsxs(I,{title:r("renderer.web.tokens.overview"),children:[t.color&&Object.keys(t.color).length>0&&e.jsx(W,{label:"Color",children:e.jsx("div",{className:"renderer-palette",children:Object.entries(t.color).map(([n,s])=>e.jsx(yt,{name:n,color:s.value},n))})}),t.font_size&&Object.keys(t.font_size).length>0&&e.jsx(W,{label:"Font Size",children:Object.entries(t.font_size).map(([n,s])=>e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:n}),e.jsxs("span",{className:"renderer-row-value",children:[s.value,s.line_height?` / ${s.line_height}`:""]})]},n))}),t.spacing&&Object.keys(t.spacing).length>0&&e.jsx(W,{label:"Spacing",children:Object.entries(t.spacing).map(([n,s])=>e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:n}),e.jsx("span",{className:"renderer-row-value",children:s})]},n))}),t.radius&&Object.keys(t.radius).length>0&&e.jsx(W,{label:"Radius",children:Object.entries(t.radius).map(([n,s])=>e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:n}),e.jsx("span",{className:"renderer-row-value",children:s})]},n))}),t.shadow&&Object.keys(t.shadow).length>0&&e.jsx(W,{label:"Shadow",children:Object.entries(t.shadow).map(([n,s])=>e.jsxs("div",{className:"renderer-row",children:[e.jsx("span",{className:"renderer-row-label",children:n}),e.jsx("span",{className:"renderer-row-value",children:s})]},n))})]})})}function bt({result:t}){const{t:r}=f(),[n,s]=c.useState("skill"),i=c.useMemo(()=>wt(t),[t])[n],o=r(n==="figma"?"renderer.web.tokens.figmaHint":"renderer.web.skillHint");return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"segment",role:"tablist",children:gt.map(h=>e.jsx("button",{type:"button",role:"tab","aria-selected":n===h.key,className:n===h.key?"active":"",onClick:()=>s(h.key),children:h.label},h.key))}),e.jsx(xt,{text:i,hint:o})]})}function xt({text:t,hint:r}){const{t:n}=f(),[s,a]=c.useState(!1);async function i(){try{await navigator.clipboard.writeText(t),a(!0),setTimeout(()=>a(!1),1500)}catch{}}return e.jsxs("div",{className:"sub-card",children:[e.jsxs("div",{style:{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,marginBottom:r?8:0},children:[r?e.jsx("div",{className:"sub-card-label",style:{flex:1,margin:0},children:r}):e.jsx("span",{}),e.jsxs("button",{type:"button",className:"btn btn-secondary btn-sm",onClick:i,style:{flexShrink:0},children:[e.jsx(jt,{}),n(s?"common.copied":"common.copy")]})]}),e.jsx("pre",{children:t})]})}function I({title:t,children:r}){return e.jsxs("div",{className:"renderer-section",children:[e.jsx("div",{className:"renderer-section-title",children:t}),r]})}function W({label:t,children:r}){return e.jsxs("div",{className:"renderer-section",children:[e.jsx("div",{className:"renderer-row-label",style:{marginBottom:6},children:t}),r]})}function fe({items:t,tone:r}){return e.jsx("div",{className:"renderer-chips",children:t.map((n,s)=>e.jsx("span",{className:`renderer-chip${r?` renderer-chip--${r}`:""}`,children:n},`${n}-${s}`))})}function be({color:t,primary:r}){return e.jsxs("span",{className:`palette-swatch${r?" palette-swatch--primary":""}`,title:t,children:[e.jsx("span",{className:"palette-chip",style:{background:t}}),e.jsx("span",{className:"palette-code",children:t})]})}function yt({name:t,color:r}){return e.jsxs("span",{className:"palette-swatch",title:`${t} ${r}`,children:[e.jsx("span",{className:"palette-chip",style:{background:r}}),e.jsx("span",{className:"palette-code",children:t})]})}function jt(){return e.jsxs("svg",{viewBox:"0 0 14 14",fill:"none",stroke:"currentColor",strokeWidth:"1.5",style:{width:13,height:13},children:[e.jsx("rect",{x:"3.5",y:"3.5",width:"8",height:"9",rx:"1.5"}),e.jsx("path",{d:"M6 3.5V2.5a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-.5"})]})}function kt(t){return JSON.stringify(t,null,2)}function F(t,r,n){let s=t;for(let a=0;a<r.length-1;a++){const i=r[a];(s[i]==null||typeof s[i]!="object")&&(s[i]={}),s=s[i]}s[r[r.length-1]]=n}function vt(t){const r={};if(t.color&&Object.keys(t.color).length){const n={};for(const[s,a]of Object.entries(t.color)){const i={value:a.value,type:"color"};a.description&&(i.description=a.description),F(n,s.split("."),i)}r.color=n}if(t.font_size&&Object.keys(t.font_size).length){const n={},s={};let a=!1;for(const[i,o]of Object.entries(t.font_size))F(n,i.split("."),{value:o.value,type:"fontSizes"}),o.line_height&&(a=!0,F(s,i.split("."),{value:o.line_height,type:"lineHeights"}));r.fontSize=n,a&&(r.lineHeight=s)}if(t.spacing&&Object.keys(t.spacing).length){const n={};for(const[s,a]of Object.entries(t.spacing))F(n,s.split("."),{value:a,type:"spacing"});r.spacing=n}if(t.radius&&Object.keys(t.radius).length){const n={};for(const[s,a]of Object.entries(t.radius))F(n,s.split("."),{value:a,type:"borderRadius"});r.borderRadius=n}if(t.shadow&&Object.keys(t.shadow).length){const n={};for(const[s,a]of Object.entries(t.shadow))F(n,s.split("."),{value:a,type:"boxShadow"});r.boxShadow=n}return r}function wt(t){const r=Nt(t),n=t.tokens?kt(vt(t.tokens)):"{}";return{skill:r,figma:n}}function Nt(t){const r=[];r.push("# Design Skill"),r.push(""),r.push("Structured design reference extracted by PromptLens. Apply to Figma, code, or AI design workflows to reproduce this page's look and feel."),r.push(""),r.push("## Layout"),r.push(t.layout),r.push(""),r.push("## Typography"),r.push(`- Heading: ${t.typography.heading}`),r.push(`- Body: ${t.typography.body}`),r.push(""),r.push("## Colors"),r.push(`- Primary: \`${t.colors.primary}\``),t.colors.accents.length&&r.push(`- Accents: ${t.colors.accents.map(s=>`\`${s}\``).join(", ")}`),r.push(""),r.push("## Components");for(const s of t.components)r.push(`- ${s}`);r.push(""),r.push("## Interactions");for(const s of t.interactions)r.push(`- ${s}`);r.push(""),r.push("## Tone"),r.push(t.tone),r.push("");const n=t.tokens;if(n&&Me(n)){if(r.push("## Design Tokens"),r.push(""),n.color&&Object.keys(n.color).length){r.push("### Color"),r.push("| Name | Value |"),r.push("|------|-------|");for(const[s,a]of Object.entries(n.color))r.push(`| \`${s}\` | \`${a.value}\` |`);r.push("")}if(n.font_size&&Object.keys(n.font_size).length){r.push("### Font Size"),r.push("| Name | Size | Line Height |"),r.push("|------|------|-------------|");for(const[s,a]of Object.entries(n.font_size))r.push(`| \`${s}\` | \`${a.value}\` | ${a.line_height?`\`${a.line_height}\``:"—"} |`);r.push("")}if(n.spacing&&Object.keys(n.spacing).length){r.push("### Spacing"),r.push("| Name | Value |"),r.push("|------|-------|");for(const[s,a]of Object.entries(n.spacing))r.push(`| \`${s}\` | \`${a}\` |`);r.push("")}if(n.radius&&Object.keys(n.radius).length){r.push("### Radius"),r.push("| Name | Value |"),r.push("|------|-------|");for(const[s,a]of Object.entries(n.radius))r.push(`| \`${s}\` | \`${a}\` |`);r.push("")}if(n.shadow&&Object.keys(n.shadow).length){r.push("### Shadow"),r.push("| Name | Value |"),r.push("|------|-------|");for(const[s,a]of Object.entries(n.shadow))r.push(`| \`${s}\` | \`${a}\` |`);r.push("")}}return r.push("---"),r.push("Generated by PromptLens · promptlens.cc"),r.push(""),r.join(`
`)}function Re(t,r="zh"){const n=r==="en"?"en-US":"zh-CN",s=new Date(t),a=new Date;return s.getFullYear()===a.getFullYear()&&s.getMonth()===a.getMonth()&&s.getDate()===a.getDate()?s.toLocaleTimeString(n,{hour:"2-digit",minute:"2-digit"}):s.toLocaleDateString(n,{month:"short",day:"numeric"})}function te(){try{return!!chrome?.runtime?.id}catch{return!1}}async function V(t){if(!te())return null;try{return await chrome.runtime.sendMessage(t)}catch{return null}}function xe(t){if(!te())return!1;try{return chrome.runtime.sendMessage(t),!0}catch{return!1}}function _e(t,r){const n=B[t];return r==="en"?n.displayName.en:n.displayName["zh-CN"]}function zt({onOpen:t}){const{t:r,lang:n}=f(),[s,a]=c.useState(null),[i,o]=c.useState(!1);async function h(){const u=await V({type:v.RPC_HISTORY_LIST});a(u?.entries??[])}c.useEffect(()=>{h()},[]);async function l(){await V({type:v.RPC_HISTORY_CLEAR}),o(!1),await h()}return s===null?e.jsx("div",{className:"loading-state",children:e.jsx("div",{className:"spinner"})}):s.length===0?e.jsxs("div",{className:"empty-state",children:[e.jsx("div",{className:"empty-title",children:r("history.empty.title")}),e.jsx("div",{className:"empty-desc",children:r("history.empty.desc")})]}):e.jsxs(e.Fragment,{children:[i?e.jsxs("div",{className:"inline-confirm",children:[e.jsx("span",{children:r("history.confirmClearPrompt")}),e.jsxs("div",{className:"inline-confirm-actions",children:[e.jsx("button",{type:"button",className:"btn btn-danger",onClick:l,children:r("history.clear")}),e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:()=>o(!1),children:r("common.cancel")})]})]}):e.jsxs("div",{className:"history-toolbar",children:[e.jsxs("span",{className:"history-count",children:[s.length," ",r("history.count")]}),e.jsx("button",{type:"button",className:"link-danger",onClick:()=>o(!0),children:r("history.clear")})]}),e.jsx("div",{className:"history-grid",children:s.map(u=>e.jsxs("button",{type:"button",className:"history-item",onClick:()=>t(u),children:[e.jsxs("div",{className:"history-thumb",children:[e.jsx(Oe,{id:u.id}),e.jsx("span",{className:"history-mode",title:_e(u.mode,n),children:e.jsx(q,{mode:u.mode})})]}),e.jsx("div",{className:"history-time",children:Re(u.createdAt,n)})]},u.id))})]})}function Oe({id:t}){const[r,n]=c.useState(null);return c.useEffect(()=>{let s=!1;return V({type:v.RPC_HISTORY_THUMB,id:t}).then(a=>{s||a?.ok&&a.thumbnailB64&&n(`data:image/jpeg;base64,${a.thumbnailB64}`)}),()=>{s=!0}},[t]),r?e.jsx("img",{src:r,alt:""}):e.jsx("div",{className:"thumb-skeleton"})}function Ct({entry:t,onDeleted:r}){const{t:n,lang:s}=f(),[a,i]=c.useState(!1),o=t.mode;async function h(){await V({type:v.RPC_HISTORY_DELETE,id:t.id}),r()}return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"hero",children:e.jsx(Oe,{id:t.id})}),e.jsxs("div",{className:"history-meta",children:[e.jsxs("span",{children:[e.jsx("span",{className:"history-mode-inline",children:e.jsx(q,{mode:o})})," ",_e(o,s)," · ",Re(t.createdAt,s)]}),a?e.jsxs("span",{className:"inline-confirm-mini",children:[e.jsx("button",{type:"button",className:"btn btn-danger btn-sm",onClick:h,children:n("history.confirmClearDetail")}),e.jsx("button",{type:"button",className:"btn btn-secondary btn-sm",onClick:()=>i(!1),children:n("common.cancel")})]}):e.jsx("button",{type:"button",className:"link-danger",onClick:()=>i(!0),children:n("common.delete")})]}),o==="image_to_prompt"&&e.jsx(Le,{result:t.insight}),o==="product_style"&&e.jsx(Te,{result:t.insight}),o==="webpage_style"&&e.jsx(Ee,{result:t.insight}),t.pageUrl&&e.jsxs("a",{className:"link-source",href:t.pageUrl,target:"_blank",rel:"noreferrer",children:[n("history.source"),"：",t.pageUrl]})]})}function St({onSaved:t}){const{t:r}=f(),[n,s]=c.useState(He),[a,i]=c.useState(!1),[o,h]=c.useState(!1),[l,u]=c.useState(!1),[y,g]=c.useState(!1),[x,T]=c.useState(!1),[_,N]=c.useState(null);c.useEffect(()=>{Ne().then(d=>{s(d),i(!0)}).catch(()=>i(!0))},[]);const S=ce.safeParse(n),w={};if(!S.success)for(const d of S.error.issues){const j=d.path[0];j&&!w[j]&&(w[j]=d.message)}const O=(d,j)=>{s($=>({...$,[d]:j})),g(!1),N(null)};async function A(d){const j={...n,uiLanguage:d};s(j),g(!1),N(null);const $=ce.safeParse(j);if($.success)try{await de($.data)}catch{}}const k=d=>{s(j=>{const $=H[j.provider],le=H[d],Ae=!j.baseURL||j.baseURL===$.defaultBaseURL?le.defaultBaseURL:j.baseURL,$e=!j.model||j.model===$.defaultModel?le.defaultModel:j.model;return{...j,provider:d,baseURL:Ae,model:$e}}),g(!1),N(null)},p=H[n.provider],m=n.provider==="ollama",b=n.uiLanguage==="en"?"en":"zh";async function E(d){if(d.preventDefault(),!!S.success){u(!0);try{await de(S.data),g(!0),setTimeout(()=>t(),700)}finally{u(!1)}}}async function M(){if(S.success){T(!0),N(null);try{const d=await V({type:v.RPC_TEST_CONNECTION,config:{provider:n.provider,baseURL:n.baseURL,apiKey:n.apiKey,model:n.model}});d?.ok?N({ok:!0,msg:`${r("settings.test.ok")} (${d.status??200})`}):N({ok:!1,msg:d?.error||`${r("settings.test.failed")} (${d?.status??"?"})`})}finally{T(!1)}}}return a?e.jsxs("form",{onSubmit:E,className:"settings-form",children:[e.jsxs("div",{className:"settings-section",children:[e.jsx("div",{className:"settings-section-title",children:r("settings.language.ui.label")}),e.jsx("div",{className:"settings-section-desc",children:r("settings.language.ui.helper")}),e.jsxs("div",{className:"segment",role:"tablist",style:{marginTop:4},children:[e.jsx("button",{type:"button",role:"tab","aria-selected":b==="zh",className:b==="zh"?"active":"",onClick:()=>void A("zh"),children:"中文"}),e.jsx("button",{type:"button",role:"tab","aria-selected":b==="en",className:b==="en"?"active":"",onClick:()=>void A("en"),children:"English"})]})]}),e.jsxs("div",{className:"settings-section",children:[e.jsx("div",{className:"settings-section-title",children:r("settings.api.title")}),e.jsx("div",{className:"settings-section-desc",children:r("settings.api.desc")}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:r("settings.api.provider")}),e.jsx("select",{className:"settings-input",value:n.provider,onChange:d=>k(d.target.value),children:Ue.map(d=>e.jsx("option",{value:d,children:b==="en"?H[d].labelEn??H[d].label:H[d].label},d))}),e.jsx("span",{className:"settings-section-desc",children:b==="en"?p.helpTextEn??p.helpText:p.helpText})]}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:r("settings.api.baseUrl")}),e.jsx("input",{type:"url",className:"settings-input",value:n.baseURL,onChange:d=>O("baseURL",d.target.value),placeholder:"https://api.openai.com/v1",required:!0}),w.baseURL&&e.jsx("span",{className:"settings-error",children:w.baseURL})]}),!m&&e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:r("settings.api.apiKey")}),e.jsxs("div",{className:"settings-input-row",children:[e.jsx("input",{type:o?"text":"password",className:"settings-input",value:n.apiKey,onChange:d=>O("apiKey",d.target.value),placeholder:"sk-…",required:!0,autoComplete:"off",spellCheck:!1}),e.jsx("button",{type:"button",className:"btn btn-secondary btn-sm",onClick:()=>h(d=>!d),children:r(o?"settings.api.hide":"settings.api.show")})]}),w.apiKey&&e.jsx("span",{className:"settings-error",children:w.apiKey})]}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:r("settings.api.model")}),e.jsx("input",{type:"text",className:"settings-input",value:n.model,onChange:d=>O("model",d.target.value),placeholder:"gpt-4o",required:!0}),w.model&&e.jsx("span",{className:"settings-error",children:w.model})]})]}),e.jsxs("div",{className:"settings-section",children:[e.jsx("div",{className:"settings-section-title",children:r("settings.pref.title")}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:r("settings.pref.maxHistory")}),e.jsx("input",{type:"number",className:"settings-input",value:n.maxHistory,min:10,max:500,onChange:d=>O("maxHistory",Number.parseInt(d.target.value,10)||0),required:!0}),w.maxHistory&&e.jsx("span",{className:"settings-error",children:w.maxHistory})]}),e.jsxs("label",{className:"settings-field",children:[e.jsx("span",{className:"settings-field-label",children:r("settings.language.model.label")}),e.jsxs("select",{className:"settings-input",value:n.language,onChange:d=>O("language",d.target.value),children:[e.jsx("option",{value:"zh",children:"中文"}),e.jsx("option",{value:"en",children:"English"})]}),e.jsx("span",{className:"settings-section-desc",children:r("settings.language.model.helper")})]})]}),e.jsxs("div",{className:"settings-actions",children:[e.jsx("button",{type:"submit",className:"btn btn-primary",disabled:l||!S.success,children:r(l?"settings.save.saving":y?"settings.save.saved":"settings.save.save")}),e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:M,disabled:x||!S.success,children:r(x?"settings.test.testing":"settings.test")}),_&&e.jsx("span",{className:_.ok?"status-ok":"status-err",children:_.msg})]})]}):e.jsx("div",{className:"loading-state",children:e.jsx("div",{className:"spinner"})})}const Pe="promptlens.theme";function Lt(){try{const t=localStorage.getItem(Pe);if(t==="light"||t==="dark")return t}catch{}return typeof matchMedia<"u"&&matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}const Tt={NO_CONFIG:"error.hint.NO_CONFIG",UNAUTHORIZED:"error.hint.UNAUTHORIZED",RATE_LIMITED:"error.hint.RATE_LIMITED",NETWORK_ERROR:"error.hint.NETWORK_ERROR",TIMEOUT:"error.hint.TIMEOUT",INVALID_RESPONSE:"error.hint.INVALID_RESPONSE",CAPTURE_FAILED:"error.hint.CAPTURE_FAILED",RESTRICTED_PAGE:"error.hint.RESTRICTED_PAGE",UNKNOWN:"error.hint.UNKNOWN"};function Et(){return{currentStep:"captured",history:[],lastSeq:-1}}function Mt(t){const r=Qe();return e.jsx(et,{lang:r,children:e.jsx(Rt,{...t})})}function Rt({initialView:t,incoming:r,onClose:n,registerCloser:s}){const{t:a,lang:i}=f(),[o,h]=c.useState(!1),[l,u]=c.useState(t),[y,g]=c.useState(Lt),x=c.useRef(null);function T(){g(k=>{const p=k==="dark"?"light":"dark";try{localStorage.setItem(Pe,p)}catch{}return p})}c.useEffect(()=>{const k=requestAnimationFrame(()=>h(!0));return()=>cancelAnimationFrame(k)},[]),c.useEffect(()=>{s&&s(()=>{h(!1),setTimeout(n,320)})},[s,n]),c.useEffect(()=>{!r||r===x.current||(x.current=r,r.type===v.LOADING?u(k=>{const p=k.kind==="loading"?k.state:Et();if(r.seq<=p.lastSeq)return k;const m=r.step!=="failed"&&r.step!==p.currentStep?[...p.history,{step:r.step,elapsedMs:r.elapsedMs}]:p.history;return{kind:"loading",state:{currentStep:r.step,history:m,failedAt:r.step==="failed"?r.failedAt:p.failedAt,errorCode:r.errorCode??p.errorCode,lastSeq:r.seq}}}):r.type===v.RESULT?u({kind:"result",payload:r.payload}):r.type===v.ERROR&&u({kind:"error",code:r.code,message:r.message}))},[r]);function _(){h(!1),setTimeout(n,320)}function N(){if(!te()){u({kind:"error",code:"UNKNOWN",message:a("error.stale")});return}chrome.runtime.sendMessage({type:v.RPC_START_SELECTION}).catch(()=>{})}const S=_t(l,a),w=l.kind==="history"||l.kind==="history-detail"||l.kind==="settings"||l.kind==="error"||l.kind==="result";function O(){l.kind==="history-detail"?u({kind:"history"}):u({kind:"launcher"})}const A=c.useRef(null);return c.useEffect(()=>{if(!o)return;function k(p){if(l.kind==="loading")return;const m=p.composedPath(),b=A.current;b&&m.includes(b)||_()}return document.addEventListener("mousedown",k,!0),()=>document.removeEventListener("mousedown",k,!0)},[o,l.kind]),e.jsxs("div",{ref:A,className:`panel theme-${y} ${o?"open":""}`,role:"dialog","aria-label":"PromptLens",children:[e.jsxs("header",{className:"header",children:[e.jsxs("div",{className:"header-left",children:[w?e.jsx("button",{type:"button",className:"icon-btn",onClick:O,title:a("header.back"),"aria-label":"Back",children:e.jsx(Ye,{})}):e.jsx("img",{className:"brand-logo",src:chrome.runtime.getURL("icons/icon-48.png"),alt:"","aria-hidden":"true"}),e.jsx("span",{className:"brand",children:S})]}),e.jsxs("div",{className:"header-actions",children:[e.jsx("button",{type:"button",className:"icon-btn",onClick:T,title:a(y==="dark"?"header.theme.light":"header.theme.dark"),"aria-label":"Toggle theme",children:y==="dark"?e.jsx(Ge,{}):e.jsx(Ve,{})}),l.kind!=="history"&&l.kind!=="history-detail"&&e.jsx("button",{type:"button",className:"icon-btn",onClick:()=>u({kind:"history"}),title:a("header.history"),"aria-label":"History",children:e.jsx(ze,{})}),e.jsx("button",{type:"button",className:"icon-btn",onClick:_,title:a("header.close"),"aria-label":"Close",children:e.jsx(Be,{})})]})]}),e.jsxs("div",{className:"body",children:[l.kind==="launcher"&&e.jsx(Pt,{onCapture:N,onHistory:()=>u({kind:"history"}),onSettings:()=>u({kind:"settings"})}),l.kind==="loading"&&e.jsxs("div",{className:"loading-state stepper-state",children:[e.jsx(it,{currentStep:l.state.currentStep,history:l.state.history,failedAt:l.state.failedAt,errorCode:l.state.errorCode,lang:i}),l.state.currentStep==="failed"&&e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:N,children:[e.jsx(Q,{})," ",a("error.retry")]})]}),l.kind==="error"&&e.jsx(At,{code:l.code,message:l.message,onOpenSettings:()=>u({kind:"settings"}),onRetry:N}),l.kind==="result"&&e.jsx($t,{payload:l.payload,onRecapture:()=>{u({kind:"launcher"}),N()},onHome:()=>u({kind:"launcher"})}),l.kind==="history"&&e.jsx(zt,{onOpen:k=>u({kind:"history-detail",entry:k})}),l.kind==="history-detail"&&e.jsx(Ct,{entry:l.entry,onDeleted:()=>u({kind:"history"})}),l.kind==="settings"&&e.jsx(St,{onSaved:()=>u({kind:"launcher"})})]},l.kind),l.kind==="result"&&l.payload.pageUrl?e.jsxs("footer",{className:"footer",children:[e.jsx("span",{children:"Source"}),e.jsx("a",{href:l.payload.pageUrl,target:"_blank",rel:"noreferrer",title:l.payload.pageUrl,children:l.payload.pageUrl})]}):e.jsxs("footer",{className:"footer",children:[e.jsx("span",{children:"PromptLens"}),e.jsx("a",{href:"https://promptlens.cc",target:"_blank",rel:"noreferrer",title:"promptlens.cc",children:"promptlens.cc"})]})]})}function ie(t,r){const n=B[t];return r==="en"?n.displayName.en:n.displayName["zh-CN"]}function _t(t,r){switch(t.kind){case"launcher":return"PromptLens";case"loading":return r("header.title.loading");case"result":return r("header.title.result");case"error":return r("header.title.error");case"history":return r("header.title.history");case"history-detail":return r("header.title.historyDetail");case"settings":return r("header.title.settings")}}const Ot={image_to_prompt:{line1:{zh:"把你喜欢的图",en:"Turn any image you love"},line2:{zh:"变成能复用的 Prompt",en:"into a reusable prompt"}},product_style:{line1:{zh:"解析产品设计",en:"Analyze product design"},line2:{zh:"拆解设计语言",en:"unpack its visual language"}},webpage_style:{line1:{zh:"提取页面设计",en:"Extract page design"},line2:{zh:"与组件设计",en:"and components"}}};function Pt({onCapture:t,onHistory:r,onSettings:n}){const{t:s,lang:a}=f(),[i,o]=c.useState(null),[h,l]=c.useState(ve);c.useEffect(()=>{Ne().then(g=>o(!!g.apiKey)).catch(()=>o(!1))},[]),c.useEffect(()=>{chrome.storage.sync.get("mode").then(g=>{const x=g.mode;we(x)&&l(x)}).catch(()=>{})},[]);function u(g){l(g),chrome.storage.sync.set({mode:g}).catch(()=>{})}const y=Ot[h];return e.jsxs("div",{className:"launcher",children:[e.jsx(It,{mode:h,onPick:u}),e.jsxs("div",{className:"hero-card",children:[e.jsx("div",{className:"hero-eyebrow",children:ie(h,a)}),e.jsxs("div",{className:"hero-title",children:[y.line1[a],e.jsx("br",{}),y.line2[a]]}),e.jsxs("button",{type:"button",className:"btn btn-primary btn-lg",onClick:t,children:[e.jsx(Q,{}),s("launcher.capture")]}),e.jsxs("div",{className:"shortcut-row",children:[e.jsx(U,{children:"⌘"}),e.jsx(U,{children:"⇧"}),e.jsx(U,{children:"Y"}),e.jsx("span",{className:"shortcut-sep",children:"·"}),e.jsx(U,{children:"Ctrl"}),e.jsx(U,{children:"⇧"}),e.jsx(U,{children:"Y"}),e.jsx("span",{className:"shortcut-hint",children:s("launcher.shortcut.hint")})]})]},h),i===!1&&e.jsxs("div",{className:"warning-banner",children:[e.jsx("span",{className:"hero-badge",children:"!"}),e.jsx("span",{children:s("launcher.noApiWarning")})]}),e.jsxs("div",{className:"tile-grid",children:[e.jsxs("button",{type:"button",className:"tile",onClick:r,children:[e.jsx(ze,{}),e.jsx("span",{className:"tile-label",children:s("launcher.tile.history.label")}),e.jsx("span",{className:"tile-desc",children:s("launcher.tile.history.desc")})]}),e.jsxs("button",{type:"button",className:"tile",onClick:n,children:[e.jsx(Ke,{}),e.jsx("span",{className:"tile-label",children:s("launcher.tile.settings.label")}),e.jsx("span",{className:"tile-desc",children:s("launcher.tile.settings.desc")})]})]})]})}function It({mode:t,onPick:r}){const{t:n,lang:s}=f(),a=r;return e.jsx("div",{className:"mode-segment",role:"tablist","aria-label":n("launcher.mode.aria"),children:De.map(i=>{const o=B[i],h=t===i;return e.jsxs("button",{type:"button",role:"tab","aria-selected":h,className:`mode-segment-btn${h?" mode-segment-btn--active":""}`,onClick:()=>a(i),title:o.description,children:[e.jsx("span",{className:"mode-segment-icon",children:e.jsx(q,{mode:i})}),e.jsx("span",{className:"mode-segment-label",children:ie(i,s)})]},i)})})}function At({code:t,message:r,onOpenSettings:n,onRetry:s}){const{t:a}=f(),i=t==="NO_CONFIG"||t==="UNAUTHORIZED";return e.jsxs("div",{className:"error-state",children:[e.jsx("div",{className:"error-icon",children:e.jsx(We,{})}),e.jsx("div",{className:"error-title",children:a(Tt[t]??"error.hint.UNKNOWN")}),e.jsx("div",{className:"error-message",children:r}),e.jsx("div",{className:"error-action",children:i?e.jsx("button",{type:"button",className:"btn btn-primary",onClick:n,children:a("error.openSettings")}):e.jsxs("button",{type:"button",className:"btn btn-primary",onClick:s,children:[e.jsx(Q,{})," ",a("error.retry")]})})]})}function $t({payload:t,onRecapture:r,onHome:n}){const{t:s,lang:a}=f(),i=t.mode,o=t.insight??t.prompts;return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"hero",children:e.jsx("img",{src:`data:image/jpeg;base64,${t.thumbnailB64}`,alt:"selection"})}),e.jsxs("div",{className:"result-mode",children:[e.jsx("span",{className:"result-mode-icon",children:e.jsx(q,{mode:i})}),e.jsx("span",{className:"result-mode-label",children:ie(i,a)})]}),i==="image_to_prompt"&&e.jsx(Le,{result:o}),i==="product_style"&&e.jsx(Te,{result:o}),i==="webpage_style"&&e.jsx(Ee,{result:o}),e.jsxs("div",{className:"result-footer-actions",children:[e.jsxs("button",{type:"button",className:"btn btn-primary btn-lg",onClick:r,children:[e.jsx(Q,{})," ",s("result.recapture")]}),e.jsx("button",{type:"button",className:"btn btn-secondary btn-lg",onClick:n,children:s("result.home")})]})]})}const Dt=`
:host, :root { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', 'Helvetica Neue', system-ui, sans-serif; letter-spacing: -0.003em; }
input, select, button, textarea { font-family: inherit; font-size: inherit; color: inherit; }

.panel {
  position: fixed;
  top: 16px;
  right: 16px;
  bottom: 16px;
  width: 440px;
  max-width: calc(100vw - 32px);
  background: rgba(255, 255, 255, 0.86);
  -webkit-backdrop-filter: blur(24px) saturate(180%);
  backdrop-filter: blur(24px) saturate(180%);
  border-radius: 22px;
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.14), 0 2px 8px rgba(0, 0, 0, 0.04);
  border: 1px solid rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
  z-index: 2147483646;
  color: #1d1d1f;
  overflow: hidden;
  transform: translateX(calc(100% + 24px));
  opacity: 0;
  transition: transform 320ms cubic-bezier(0.22, 1, 0.36, 1), opacity 240ms ease;
}
.panel.open { transform: translateX(0); opacity: 1; }

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.06);
  min-height: 56px;
}
.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.brand {
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.015em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.brand-dot {
  display: inline-block;
  width: 10px; height: 10px;
  border-radius: 50%;
  background: linear-gradient(135deg, #0071e3, #5e5ce6);
  flex-shrink: 0;
}
.brand-logo {
  width: 22px;
  height: 22px;
  border-radius: 6px;
  flex-shrink: 0;
  object-fit: contain;
}
.header-actions { display: flex; gap: 2px; }
.icon-btn {
  width: 30px; height: 30px;
  border-radius: 50%;
  border: none;
  background: transparent;
  color: #515154;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: background 160ms ease, color 160ms ease;
}
.icon-btn:hover { background: rgba(0,0,0,0.06); color: #1d1d1f; }
.icon-btn svg { width: 15px; height: 15px; }

.body {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  animation: fade-in 220ms ease;
}
@keyframes fade-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
.body::-webkit-scrollbar { width: 10px; }
.body::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.15); border-radius: 8px; border: 3px solid transparent; background-clip: padding-box; }
.body::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.28); border: 3px solid transparent; background-clip: padding-box; }

/* ---------- Launcher ---------- */
.launcher { display: flex; flex-direction: column; gap: 16px; }
.hero-card {
  background: linear-gradient(135deg, #f5f5f7 0%, #ebebed 100%);
  border-radius: 20px;
  padding: 28px 24px;
  text-align: center;
  animation: hero-swap 280ms cubic-bezier(0.16, 1, 0.3, 1);
}
@keyframes hero-swap {
  from { opacity: 0; transform: translateY(6px); }
  to   { opacity: 1; transform: translateY(0); }
}
.hero-eyebrow {
  font-size: 11.5px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 12px;
}
.hero-title {
  font-size: 22px;
  line-height: 1.2;
  font-weight: 600;
  letter-spacing: -0.022em;
  color: #1d1d1f;
  margin-bottom: 20px;
}
.btn-lg { font-size: 14px; padding: 11px 22px; }
.shortcut-row {
  margin-top: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  flex-wrap: wrap;
}
.shortcut-sep { color: #c7c7cc; margin: 0 4px; }
.shortcut-hint { margin-left: 8px; font-size: 11px; color: #86868b; }
.kbd {
  display: inline-flex;
  min-width: 22px;
  justify-content: center;
  align-items: center;
  background: #ffffff;
  color: #1d1d1f;
  padding: 2px 7px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  border: 1px solid rgba(0,0,0,0.08);
  box-shadow: 0 1px 0 rgba(0,0,0,0.04);
}

.warning-banner {
  display: flex;
  gap: 10px;
  align-items: flex-start;
  background: #fff5f0;
  color: #a1501a;
  border-radius: 12px;
  padding: 10px 14px;
  font-size: 12.5px;
}

.tile-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
.tile {
  background: #f5f5f7;
  border: none;
  border-radius: 16px;
  padding: 18px 16px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 6px;
  align-items: flex-start;
  text-align: left;
  color: #1d1d1f;
  transition: background 160ms ease, transform 120ms ease;
}
.tile:hover { background: #ebebed; }
.tile:active { transform: scale(0.98); }
.tile svg { width: 18px; height: 18px; color: #0071e3; }
.tile-label { font-size: 14px; font-weight: 600; letter-spacing: -0.01em; }
.tile-desc { font-size: 11.5px; color: #86868b; }

/* ---------- Result / Hero image ---------- */
.hero {
  background: #f5f5f7;
  border-radius: 16px;
  padding: 12px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 140px;
  max-height: 220px;
  overflow: hidden;
}
.hero img {
  max-width: 100%;
  max-height: 196px;
  object-fit: contain;
  border-radius: 10px;
  display: block;
}

.segment {
  background: rgba(0,0,0,0.05);
  border-radius: 10px;
  padding: 3px;
  display: flex;
  gap: 2px;
  margin-bottom: 16px;
}
.segment button {
  flex: 1;
  background: transparent;
  border: none;
  padding: 7px 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: #515154;
  border-radius: 8px;
  cursor: pointer;
  transition: background 180ms ease, color 180ms ease, box-shadow 180ms ease;
  letter-spacing: -0.005em;
}
.segment button.active {
  background: #ffffff;
  color: #1d1d1f;
  box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 2px 6px rgba(0,0,0,0.04);
  font-weight: 600;
}

.prompt-card {
  background: #ffffff;
  border: 1px solid rgba(0,0,0,0.06);
  border-radius: 14px;
  padding: 14px 16px;
  margin-bottom: 12px;
}
.prompt-card-label {
  font-size: 11px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 8px;
}
.prompt-text {
  font-family: -apple-system, 'SF Pro Text', system-ui, sans-serif;
  font-size: 13px;
  line-height: 1.55;
  color: #1d1d1f;
  white-space: pre-wrap;
  word-break: break-word;
  max-height: 240px;
  overflow-y: auto;
}

.actions { display: flex; gap: 8px; align-items: center; margin-top: 12px; flex-wrap: wrap; }

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  border: none;
  border-radius: 980px;
  padding: 8px 16px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background 160ms ease, color 160ms ease, transform 120ms ease, opacity 160ms ease;
  letter-spacing: -0.005em;
  -webkit-tap-highlight-color: transparent;
}
.btn:active { transform: scale(0.97); }
.btn:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-primary { background: #0071e3; color: #ffffff; }
.btn-primary:hover:not(:disabled) { background: #0077ed; }
.btn-primary:active:not(:disabled) { background: #006edb; }
.btn-secondary { background: rgba(0,0,0,0.06); color: #1d1d1f; }
.btn-secondary:hover:not(:disabled) { background: rgba(0,0,0,0.09); }
.btn-danger { background: #ff3b30; color: #ffffff; }
.btn-danger:hover:not(:disabled) { filter: brightness(1.06); }
.btn-sm { font-size: 11.5px; padding: 5px 12px; }

.toast {
  font-size: 12px;
  color: #34c759;
  font-weight: 500;
  opacity: 0;
  transform: translateX(-4px);
  transition: opacity 180ms ease, transform 180ms ease;
}
.toast.visible { opacity: 1; transform: translateX(0); }

.collapse-trigger {
  background: none;
  border: none;
  color: #0071e3;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  padding: 4px 0;
  margin-top: 4px;
}
.collapse-trigger:hover { text-decoration: underline; }

.sub-card {
  background: #f5f5f7;
  border-radius: 12px;
  padding: 10px 12px;
  margin-top: 8px;
}
.sub-card-label {
  font-size: 11px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 4px;
}
.sub-card pre {
  font-family: -apple-system, 'SF Pro Text', system-ui, sans-serif;
  font-size: 12.5px;
  line-height: 1.5;
  color: #1d1d1f;
  white-space: pre-wrap;
  word-break: break-word;
}

/* ---------- Mode segment ---------- */
.mode-segment {
  display: flex;
  gap: 4px;
  padding: 4px;
  background: rgba(0,0,0,0.05);
  border-radius: 12px;
}
.mode-segment-btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  padding: 8px 6px;
  font-size: 12px;
  font-weight: 500;
  color: #515154;
  background: transparent;
  border: none;
  border-radius: 9px;
  cursor: pointer;
  transition: background 160ms ease, color 160ms ease, box-shadow 160ms ease;
  letter-spacing: -0.005em;
}
.mode-segment-btn:hover { color: #1d1d1f; }
.mode-segment-btn--active {
  background: #ffffff;
  color: #1d1d1f;
  font-weight: 600;
  box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 2px 6px rgba(0,0,0,0.04);
}
.mode-segment-icon { font-size: 14px; line-height: 1; }
.mode-segment-label { white-space: nowrap; }

/* ---------- Result mode label ---------- */
.result-mode {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  background: rgba(0,113,227,0.08);
  color: #0071e3;
  border-radius: 980px;
  font-size: 11.5px;
  font-weight: 600;
  margin-bottom: 12px;
  letter-spacing: -0.005em;
}
.result-mode-icon { font-size: 13px; line-height: 1; }

/* ---------- Stepper ---------- */
.stepper-state {
  align-items: stretch;
  padding: 32px 24px;
}
.stepper {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
  max-width: 320px;
  margin: 0 auto;
}
.stepper-step {
  display: flex;
  gap: 12px;
  align-items: flex-start;
  min-height: 36px;
}
.stepper-rail {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex-shrink: 0;
  padding-top: 4px;
}
.stepper-dot {
  width: 10px; height: 10px;
  border-radius: 50%;
  background: rgba(0,0,0,0.18);
  transition: background 200ms ease, box-shadow 200ms ease;
}
.stepper-line {
  width: 2px;
  flex: 1;
  min-height: 14px;
  background: rgba(0,0,0,0.08);
  margin-top: 4px;
}
.stepper-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding-bottom: 8px;
}
.stepper-label {
  font-size: 13px;
  font-weight: 500;
  color: #515154;
  letter-spacing: -0.005em;
}
.stepper-elapsed {
  font-size: 11.5px;
  color: #86868b;
  font-variant-numeric: tabular-nums;
}
.stepper-elapsed--done { color: #34c759; }
.stepper-step--current .stepper-dot {
  background: #0071e3;
  box-shadow: 0 0 0 4px rgba(0,113,227,0.18);
  animation: stepper-pulse 1.2s ease-in-out infinite;
}
.stepper-step--current .stepper-label { color: #1d1d1f; font-weight: 600; }
.stepper-step--done .stepper-dot {
  background: #34c759;
  box-shadow: 0 0 0 0 rgba(52,199,89,0);
}
.stepper-step--done .stepper-label { color: #1d1d1f; }
.stepper-step--failed .stepper-dot { background: #ff3b30; }
.stepper-step--failed .stepper-label { color: #ff3b30; font-weight: 600; }
.stepper-step--pending .stepper-label { color: #aeaeb2; }
.stepper-error { color: #ff3b30; font-weight: 500; }
@keyframes stepper-pulse {
  0%, 100% { box-shadow: 0 0 0 4px rgba(0,113,227,0.18); }
  50% { box-shadow: 0 0 0 7px rgba(0,113,227,0.06); }
}

/* ---------- Renderers (product / web) ---------- */
.renderer { display: flex; flex-direction: column; gap: 14px; margin-bottom : 12px;}
.renderer-section {
  background: #ffffff;
  border: 1px solid rgba(0,0,0,0.06);
  border-radius: 14px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.renderer-section-title {
  font-size: 11px;
  font-weight: 600;
  color: #86868b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.renderer-block {
  font-size: 13px;
  line-height: 1.5;
  color: #1d1d1f;
  white-space: pre-wrap;
}
.renderer-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: 12.5px;
  padding: 4px 0;
  border-top: 1px solid rgba(0,0,0,0.04);
}
.renderer-row:first-child { border-top: none; }
.renderer-row-label { color: #86868b; flex-shrink: 0; }
.renderer-row-value { color: #1d1d1f; text-align: right; word-break: break-word; }
.renderer-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.renderer-chip {
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  background: rgba(0,0,0,0.05);
  color: #1d1d1f;
  border-radius: 980px;
  font-size: 11.5px;
  font-weight: 500;
  letter-spacing: -0.005em;
}
.renderer-chip--accent {
  background: rgba(0,113,227,0.1);
  color: #0071e3;
}
.renderer-palette {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.palette-swatch {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}
.palette-swatch--primary .palette-chip {
  box-shadow: 0 0 0 2px rgba(0,113,227,0.4);
}
.palette-chip {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: 1px solid rgba(0,0,0,0.08);
}
.palette-code {
  font-size: 10px;
  color: #86868b;
  font-variant-numeric: tabular-nums;
}

/* ---------- History mode badge ---------- */
.history-thumb { position: relative; }
.history-mode {
  position: absolute;
  top: 6px;
  left: 6px;
  width: 22px;
  height: 22px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: rgba(28,28,30,0.65);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  color: #ffffff;
  border-radius: 50%;
  font-size: 12px;
  line-height: 1;
}
.history-mode-inline { font-size: 13px; }

/* ---------- Loading ---------- */
.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 48px 24px;
  gap: 16px;
}
.spinner {
  width: 28px; height: 28px;
  border: 2.5px solid rgba(0,0,0,0.08);
  border-top-color: #0071e3;
  border-radius: 50%;
  animation: spin 720ms linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loading-label { font-size: 14px; color: #515154; font-weight: 500; letter-spacing: -0.01em; }

/* ---------- Empty ---------- */
.empty-state { padding: 60px 24px; text-align: center; }
.empty-title { font-size: 15px; font-weight: 600; color: #1d1d1f; letter-spacing: -0.01em; }
.empty-desc { font-size: 12.5px; color: #86868b; margin-top: 4px; }

/* ---------- Error ---------- */
.error-state {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 32px 12px;
}
.error-icon {
  width: 44px; height: 44px;
  border-radius: 50%;
  background: rgba(255, 59, 48, 0.1);
  color: #ff3b30;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
}
.error-title {
  font-size: 15px;
  font-weight: 600;
  text-align: center;
  color: #1d1d1f;
  letter-spacing: -0.01em;
}
.error-message {
  font-size: 12.5px;
  color: #86868b;
  text-align: center;
  line-height: 1.5;
  word-break: break-word;
}
.error-action { display: flex; justify-content: center; margin-top: 4px; }

.footer {
  padding: 12px 20px 16px;
  border-top: 1px solid rgba(0,0,0,0.06);
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  font-size: 11.5px;
  color: #86868b;
}
.footer a { color: #86868b; text-decoration: none; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 280px; }
.footer a:hover { color: #0071e3; }

/* ---------- History ---------- */
.history-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding: 0 2px;
}
.history-count { font-size: 12px; color: #86868b; font-weight: 500; }
.link-danger {
  background: none; border: none; padding: 0;
  color: #ff3b30; font-size: 12.5px; font-weight: 500; cursor: pointer;
}
.link-danger:hover { opacity: 0.75; }

.inline-confirm {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff5f0;
  color: #a1501a;
  border-radius: 12px;
  padding: 10px 14px;
  font-size: 12.5px;
  margin-bottom: 12px;
  gap: 10px;
}
.inline-confirm-actions { display: flex; gap: 6px; }
.inline-confirm-mini { display: inline-flex; gap: 6px; align-items: center; }

.history-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
.history-item {
  background: transparent;
  border: none;
  padding: 0;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 4px;
  text-align: left;
}
.history-thumb {
  overflow: hidden;
  border-radius: 12px;
  background: #f5f5f7;
  aspect-ratio: 4/3;
  transition: box-shadow 220ms ease, transform 220ms ease;
}
.history-item:hover .history-thumb {
  box-shadow: 0 6px 20px rgba(0,0,0,0.1);
  transform: translateY(-1px);
}
.history-thumb img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 300ms ease;
}
.history-item:hover .history-thumb img { transform: scale(1.03); }
.history-time { font-size: 10.5px; color: #86868b; padding: 0 2px; }
.thumb-skeleton {
  width: 100%; height: 100%;
  background: linear-gradient(100deg, #f5f5f7 30%, #ebebed 50%, #f5f5f7 70%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
@keyframes shimmer {
  0% { background-position: 100% 0; }
  100% { background-position: -100% 0; }
}

.result-footer-actions {
  display: flex;
  justify-content: center;
  gap: 12px;
  padding-top: 4px;
}

.history-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  font-size: 11.5px;
  color: #86868b;
  padding: 0 2px;
}
.link-source {
  display: block;
  font-size: 11px;
  color: #86868b;
  text-decoration: none;
  margin-top: -4px;
  margin-bottom: 8px;
  padding: 0 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.link-source:hover { color: #0071e3; }

/* ---------- Settings ---------- */
.settings-form { display: flex; flex-direction: column; gap: 14px; }
.settings-section {
  background: #ffffff;
  border: 1px solid rgba(0,0,0,0.06);
  border-radius: 16px;
  padding: 16px 18px;
}
.settings-section-title {
  font-size: 13.5px;
  font-weight: 600;
  letter-spacing: -0.01em;
  margin-bottom: 4px;
}
.settings-section-desc {
  font-size: 11.5px;
  color: #86868b;
  line-height: 1.5;
  margin-bottom: 12px;
}
.settings-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px 0;
  border-top: 1px solid rgba(0,0,0,0.05);
}
.settings-field:first-of-type { border-top: none; padding-top: 4px; }
.settings-field-label {
  font-size: 12.5px;
  font-weight: 500;
  color: #1d1d1f;
}
.settings-input {
  width: 100%;
  padding: 8px 12px;
  border-radius: 10px;
  background: #f5f5f7;
  border: 1px solid transparent;
  font-size: 13px;
  color: #1d1d1f;
  outline: none;
  transition: background 160ms ease, border-color 160ms ease, box-shadow 160ms ease;
}
.settings-input:focus {
  background: #ffffff;
  border-color: #0071e3;
  box-shadow: 0 0 0 3px rgba(0, 113, 227, 0.18);
}
.settings-input-row { display: flex; gap: 8px; align-items: center; }
.settings-input-row .settings-input { flex: 1; }
.settings-error { font-size: 11.5px; color: #ff3b30; }

.settings-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-top: 4px;
  padding: 12px 16px;
  background: rgba(245, 245, 247, 0.6);
  border-radius: 14px;
  -webkit-backdrop-filter: blur(12px);
  backdrop-filter: blur(12px);
  position: sticky;
  bottom: -20px;
}
.status-ok { font-size: 12.5px; color: #34c759; font-weight: 500; }
.status-err { font-size: 12.5px; color: #ff3b30; font-weight: 500; }

/* ---------- Dark ---------- */
@media (prefers-color-scheme: dark) {
  .panel:not(.theme-light) {
    background: rgba(28, 28, 30, 0.85);
    border-color: rgba(255,255,255,0.08);
    color: #f5f5f7;
  }
  .header, .footer { border-color: rgba(255,255,255,0.08); }
  .icon-btn { color: #aeaeb2; }
  .icon-btn:hover { background: rgba(255,255,255,0.08); color: #ffffff; }
  .hero, .sub-card, .tile, .history-thumb { background: rgba(255,255,255,0.06); }
  .hero-card { background: linear-gradient(135deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02)); }
  .hero-title { color: #f5f5f7; }
  .tile:hover { background: rgba(255,255,255,0.1); }
  .segment { background: rgba(255,255,255,0.08); }
  .segment button { color: #aeaeb2; }
  .segment button.active { background: rgba(255,255,255,0.14); color: #ffffff; }
  .prompt-card, .settings-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08); }
  .prompt-card-label, .sub-card-label, .error-message, .loading-label, .footer, .history-count, .history-time, .settings-section-desc, .empty-desc, .shortcut-hint, .hero-eyebrow { color: #aeaeb2; }
  .prompt-text, .sub-card pre, .error-title, .empty-title, .settings-field-label, .settings-section-title { color: #f5f5f7; }
  .btn-secondary { background: rgba(255,255,255,0.1); color: #f5f5f7; }
  .btn-secondary:hover:not(:disabled) { background: rgba(255,255,255,0.14); }
  .btn-primary { background: #0a84ff; }
  .btn-primary:hover:not(:disabled) { background: #0a84ff; filter: brightness(1.1); }
  .kbd { background: rgba(255,255,255,0.12); color: #f5f5f7; border-color: rgba(255,255,255,0.16); box-shadow: 0 1px 0 rgba(0,0,0,0.2); }
  .settings-input { background: rgba(255,255,255,0.06); color: #f5f5f7; }
  .settings-input:focus { background: rgba(255,255,255,0.1); border-color: #0a84ff; box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.22); }
  .settings-field { border-color: rgba(255,255,255,0.06); }
  .settings-actions { background: rgba(255,255,255,0.04); }
  .warning-banner, .inline-confirm { background: rgba(255, 149, 0, 0.16); color: #ffd180; }
  .mode-segment { background: rgba(255,255,255,0.08); }
  .mode-segment-btn { color: #aeaeb2; }
  .mode-segment-btn--active { background: rgba(255,255,255,0.14); color: #ffffff; }
  .renderer-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08); }
  .renderer-block, .renderer-row-value { color: #f5f5f7; }
  .renderer-row { border-color: rgba(255,255,255,0.06); }
  .renderer-chip { background: rgba(255,255,255,0.08); color: #f5f5f7; }
  .renderer-chip--accent { background: rgba(10,132,255,0.16); color: #4aa6ff; }
  .palette-chip { border-color: rgba(255,255,255,0.12); }
  .stepper-dot { background: rgba(255,255,255,0.18); }
  .stepper-line { background: rgba(255,255,255,0.08); }
  .stepper-step--current .stepper-dot { background: #0a84ff; box-shadow: 0 0 0 4px rgba(10,132,255,0.22); }
  .stepper-step--done .stepper-dot { background: #34c759; }
  .stepper-step--pending .stepper-label { color: #6e6e72; }
  .stepper-label { color: #aeaeb2; }
  .stepper-step--current .stepper-label, .stepper-step--done .stepper-label { color: #f5f5f7; }
  .result-mode { background: rgba(10,132,255,0.16); color: #4aa6ff; }
}

/* Mode icon svg sizing */
.mode-segment-icon svg { width: 13px; height: 13px; display: block; }
.result-mode-icon svg { width: 12px; height: 12px; display: block; }
.history-mode svg { width: 11px; height: 11px; display: block; }
.history-mode-inline svg { width: 11px; height: 11px; vertical-align: -1px; }
.overlay-mode-icon { display: inline-flex; align-items: center; margin-right: 4px; }
.overlay-mode-icon svg { width: 11px; height: 11px; display: block; }

/* Extra tile override — .tile has its own color so needs dark reset */
@media (prefers-color-scheme: dark) {
  .panel:not(.theme-light) .tile { color: #f5f5f7; }
}
.panel.theme-dark .tile { color: #f5f5f7; }

/* Explicit dark theme class overrides */
.panel.theme-dark {
    background: rgba(28, 28, 30, 0.85);
    border-color: rgba(255,255,255,0.08);
    color: #f5f5f7;
   }
.panel.theme-dark .header, .panel.theme-dark .footer { border-color: rgba(255,255,255,0.08);  }
.panel.theme-dark .icon-btn { color: #aeaeb2;  }
.panel.theme-dark .icon-btn:hover { background: rgba(255,255,255,0.08); color: #ffffff;  }
.panel.theme-dark .hero, .panel.theme-dark .sub-card, .panel.theme-dark .tile, .panel.theme-dark .history-thumb { background: rgba(255,255,255,0.06);  }
.panel.theme-dark .hero-card { background: linear-gradient(135deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));  }
.panel.theme-dark .hero-title { color: #f5f5f7;  }
.panel.theme-dark .tile:hover { background: rgba(255,255,255,0.1);  }
.panel.theme-dark .segment { background: rgba(255,255,255,0.08);  }
.panel.theme-dark .segment button { color: #aeaeb2;  }
.panel.theme-dark .segment button.active { background: rgba(255,255,255,0.14); color: #ffffff;  }
.panel.theme-dark .prompt-card, .panel.theme-dark .settings-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08);  }
.panel.theme-dark .prompt-card-label, .panel.theme-dark .sub-card-label, .panel.theme-dark .error-message, .panel.theme-dark .loading-label, .panel.theme-dark .footer, .panel.theme-dark .history-count, .panel.theme-dark .history-time, .panel.theme-dark .settings-section-desc, .panel.theme-dark .empty-desc, .panel.theme-dark .shortcut-hint, .panel.theme-dark .hero-eyebrow { color: #aeaeb2;  }
.panel.theme-dark .prompt-text, .panel.theme-dark .sub-card pre, .panel.theme-dark .error-title, .panel.theme-dark .empty-title, .panel.theme-dark .settings-field-label, .panel.theme-dark .settings-section-title { color: #f5f5f7;  }
.panel.theme-dark .btn-secondary { background: rgba(255,255,255,0.1); color: #f5f5f7;  }
.panel.theme-dark .btn-secondary:hover:not(:disabled) { background: rgba(255,255,255,0.14);  }
.panel.theme-dark .btn-primary { background: #0a84ff;  }
.panel.theme-dark .btn-primary:hover:not(:disabled) { background: #0a84ff; filter: brightness(1.1);  }
.panel.theme-dark .kbd { background: rgba(255,255,255,0.12); color: #f5f5f7; border-color: rgba(255,255,255,0.16); box-shadow: 0 1px 0 rgba(0,0,0,0.2);  }
.panel.theme-dark .settings-input { background: rgba(255,255,255,0.06); color: #f5f5f7;  }
.panel.theme-dark .settings-input:focus { background: rgba(255,255,255,0.1); border-color: #0a84ff; box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.22);  }
.panel.theme-dark .settings-field { border-color: rgba(255,255,255,0.06);  }
.panel.theme-dark .settings-actions { background: rgba(255,255,255,0.04);  }
.panel.theme-dark .warning-banner, .panel.theme-dark .inline-confirm { background: rgba(255, 149, 0, 0.16); color: #ffd180;  }
.panel.theme-dark .mode-segment { background: rgba(255,255,255,0.08);  }
.panel.theme-dark .mode-segment-btn { color: #aeaeb2;  }
.panel.theme-dark .mode-segment-btn--active { background: rgba(255,255,255,0.14); color: #ffffff;  }
.panel.theme-dark .renderer-section { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.08);  }
.panel.theme-dark .renderer-block, .panel.theme-dark .renderer-row-value { color: #f5f5f7;  }
.panel.theme-dark .renderer-row { border-color: rgba(255,255,255,0.06);  }
.panel.theme-dark .renderer-chip { background: rgba(255,255,255,0.08); color: #f5f5f7;  }
.panel.theme-dark .renderer-chip--accent { background: rgba(10,132,255,0.16); color: #4aa6ff;  }
.panel.theme-dark .palette-chip { border-color: rgba(255,255,255,0.12);  }
.panel.theme-dark .stepper-dot { background: rgba(255,255,255,0.18);  }
.panel.theme-dark .stepper-line { background: rgba(255,255,255,0.08);  }
.panel.theme-dark .stepper-step--current .stepper-dot { background: #0a84ff; box-shadow: 0 0 0 4px rgba(10,132,255,0.22);  }
.panel.theme-dark .stepper-step--done .stepper-dot { background: #34c759;  }
.panel.theme-dark .stepper-step--pending .stepper-label { color: #6e6e72;  }
.panel.theme-dark .stepper-label { color: #aeaeb2;  }
.panel.theme-dark .stepper-step--current .stepper-label, .panel.theme-dark .stepper-step--done .stepper-label { color: #f5f5f7;  }
.panel.theme-dark .result-mode { background: rgba(10,132,255,0.16); color: #4aa6ff;  }
`;let se=null;function ye(t){const r="img2prompt-stale-toast";let n=document.getElementById(r);n||(n=document.createElement("div"),n.id=r,n.style.cssText=["position:fixed","left:50%","top:32px","transform:translateX(-50%)","z-index:2147483647","padding:10px 16px","background:rgba(28,28,30,0.92)","color:#fff","font:500 13px/1.4 -apple-system,BlinkMacSystemFont,system-ui,sans-serif","border-radius:999px","box-shadow:0 6px 24px rgba(0,0,0,0.25)","pointer-events:none","backdrop-filter:blur(16px) saturate(180%)","-webkit-backdrop-filter:blur(16px) saturate(180%)"].join(";"),document.documentElement.appendChild(n)),n.textContent=t,se!=null&&window.clearTimeout(se),se=window.setTimeout(()=>n?.remove(),3200)}const Ht="img2prompt-overlay-host",Ut="img2prompt-panel-host";let Y=null,C=null,K=null,L=null,J=null,ae=null,G=null;function Ft(t,r){if(C)return;C=document.createElement("div"),C.id=Ht,C.style.all="initial";const n=C.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=ot,n.appendChild(s);const a=document.createElement("div");n.appendChild(a),document.documentElement.appendChild(C),Y=ke(a),Y.render(c.createElement(rt,{excludeHost:C,mode:t,lang:r,onComplete:i=>{const o=xe({type:v.SELECTION_COMPLETE,rect:i,dpr:window.devicePixelRatio||1,pageUrl:location.href,mode:t});je(),o||(ye(z("error.stale",r)),Ie())},onCancel:()=>{xe({type:v.SELECTION_CANCEL}),je(),te()?oe({}):ye(z("error.stale",r))}}))}function je(){Y&&(Y.unmount(),Y=null),C&&C.parentNode&&C.parentNode.removeChild(C),C=null}function Bt(){if(L)return;L=document.createElement("div"),L.id=Ut,L.style.all="initial";const t=L.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=Dt,t.appendChild(r),J=document.createElement("div"),t.appendChild(J),document.documentElement.appendChild(L),K=ke(J)}function Ie(){K&&(K.unmount(),K=null),L&&L.parentNode&&L.parentNode.removeChild(L),L=null,J=null,G=null,ae=null}function oe(t){Bt(),K&&(t.incoming!==void 0&&(ae=t.incoming),K.render(c.createElement(Mt,{initialView:{kind:"launcher"},incoming:ae,onClose:Ie,registerCloser:r=>{G=r}})))}function Kt(){G&&(G(),G=null)}async function Wt(){try{const r=(await chrome.storage.sync.get("mode")).mode;if(we(r))return r}catch{}return ve}async function Yt(){const[t,r]=await Promise.all([Wt(),tt()]);Kt(),Ft(t,r)}chrome.runtime.onMessage.addListener(t=>{const r=t;if(!(!r||typeof r!="object")){if(console.log("[img2prompt][content] received",r.type),r.type===v.START_SELECTION){Yt();return}if(r.type===v.PANEL_OPEN){oe({});return}if(r.type===v.LOADING||r.type===v.RESULT||r.type===v.ERROR){oe({incoming:t});return}}});export{Wt as resolveModeForSelection};
